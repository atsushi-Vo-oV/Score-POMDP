"""Catalog historical experiment sources and run supported Python experiments safely."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CATALOG = {
    'original': 'recovered_cbo_svgd_30000',
    'comparison-2d': 'comparison_2d_30000',
    'wave-2d': 'wave_comparison_30000',
    'wave-2d-slow': 'wave_slow_comparison_30000',
    'wave-2d-common-eta': 'wave_common_eta_001',
    'wave-2d-imq': 'wave_svgd_imq_001',
    'wave-2d-five-figure': 'wave_all_five_001',
    'wave-20d': 'wave_20d',
    'wave-100d': 'wave_100d_near_far',
    'torus-100d': 'torus_100d',
    'rastrigin': 'highdim_rastrigin',
    'history-diffusion': 'highdim_history_diffusion',
    'force-scaling': 'highdim_force_scaling',
}
RUNNABLE = {'wave-20d', 'torus-100d'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('list', help='List archived experiments')
    run = sub.add_parser('run', help='Run a supported experiment in a new folder')
    run.add_argument('experiment', choices=sorted(RUNNABLE))
    args = parser.parse_args()
    if args.command == 'list':
        for key, path in CATALOG.items():
            print(f'{key:23} {"run supported" if key in RUNNABLE else "source archive"}  sources/{path}')
        return
    source = ROOT / 'sources' / CATALOG[args.experiment] / 'experiment.py'
    if not source.exists():
        raise SystemExit(f'Missing experiment source: {source}')
    runs = ROOT / 'runs'; runs.mkdir(exist_ok=True)
    destination = Path(tempfile.mkdtemp(prefix=args.experiment + '-', dir=runs))
    script = destination / 'experiment.py'; shutil.copy2(source, script)
    shutil.copy2(source.parent / 'README.txt', destination / 'README.txt')
    env = os.environ.copy()
    bundled_plotting = ROOT.parent.parent / 'work' / 'plotting_packages'
    if bundled_plotting.exists():
        env['PYTHONPATH'] = str(bundled_plotting) + os.pathsep + env.get('PYTHONPATH', '')
    print(f'Output: {destination}', flush=True)
    subprocess.run([sys.executable, str(script)], env=env, check=True)
    print(f'Completed: {destination}')

if __name__ == '__main__':
    main()
