import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import sys, json, zipfile
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'work' / 'plotting_packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

ROOT = Path(__file__).resolve().parent
N, D, STEPS, GAP, ETA, TAU = 64, 10, 30000, 500, .01, .15
grid = np.linspace(0, 2*np.pi, 64)
freq = np.arange(1, 11, dtype=float)
amps = .7 / freq
target = np.sin(np.outer(grid, freq)) @ amps
rng = np.random.default_rng(20261104)
initial = np.concatenate([rng.uniform(0, .3, (N,D)), freq + rng.normal(0,.2,(N,D))],axis=1)
names = ['ULA', 'PSO', 'SVGD RBF', 'SVGD IMQ', 'CBO']
colors = ['#1f77b4','#ff7f0e','#2ca02c','#9467bd','#d62728']

def evaluate(q):
    a, w = q[:,:D], q[:,D:]
    z = w[:,:,None]*grid
    s = np.sin(z)
    residual = np.einsum('nd,ndt->nt', a, s, optimize=True)-target
    loss = np.mean(residual**2,axis=1)/2
    ga = np.einsum('nt,ndt->nd',residual,s,optimize=True)/len(grid)
    gw = np.einsum('nt,ndt,nd->nd',residual,np.cos(z)*grid,a,optimize=True)/len(grid)
    return loss, np.concatenate((ga,gw),axis=1)

def simulate():
    states = np.empty((5,STEPS//GAP+1,N,2*D))
    losses = np.empty((5,STEPS//GAP+1,N))
    for method in range(5):
        q=initial.copy(); v=np.zeros_like(q); pb=q.copy(); pl=np.full(N,np.inf)
        gen=np.random.default_rng(8000+method)
        for step in range(STEPS+1):
            loss, grad = evaluate(q)
            if not np.all(np.isfinite(loss)): raise ValueError(f'nonfinite {names[method]} {step}')
            if step%GAP==0:
                states[method,step//GAP]=q; losses[method,step//GAP]=loss
            if step==STEPS: break
            if method==0:
                q += -ETA*grad + np.sqrt(2*.005*ETA)*gen.normal(size=q.shape)
            elif method==1:
                better=loss<pl; pb[better]=q[better]; pl[better]=loss[better]
                best=pb[np.argmin(pl)]; chi=2/(4.1-2+np.sqrt(4.1**2-4*4.1))
                v=chi*(v+2.05*gen.random(q.shape)*(pb-q)+2.05*gen.random(q.shape)*(best-q))
                q += ETA*v
            elif method in (2,3):
                diff=q[:,None,:]-q[None,:,:]
                d2=np.einsum('ijk,ijk->ij',diff,diff)
                if method==2:
                    k=np.exp(-d2/.36); rep=k/.18
                else:
                    u=1+d2/.18; k=u**-.5; rep=k/(.18*u)
                drift=-(k @ grad)/(TAU*N)+np.einsum('ij,ijd->id',rep,diff)/N
                q += ETA*drift
            else:
                weights=np.exp(-(loss-loss.min())/TAU); center=weights @ q / weights.sum()
                diff=center-q
                q += ETA*.02*diff + .1*np.sqrt(ETA)*np.linalg.norm(diff,axis=1)[:,None]*gen.normal(size=q.shape)
        print(f'{names[method]} done; final best={loss.min():.8g}',flush=True)
    np.savez_compressed(ROOT/'results.npz',states=states,losses=losses,grid=grid,target=target,initial=initial,amps=amps,freq=freq)

def render():
    data=np.load(ROOT/'results.npz'); states=data['states']; losses=data['losses']
    fig,ax=plt.subplots(3,2,figsize=(14,12), constrained_layout=True)
    ax=ax.ravel(); lines=[]
    for m in range(5):
        a=ax[m]; a.plot(grid,target,color='black',lw=2,label='Target')
        current,=a.plot([],[],color=colors[m],lw=2,label='Current best')
        final,=a.plot([],[],color='gray',ls=':',lw=2,label='Final-best particle')
        a.set_title(names[m],fontweight='bold'); a.set_xlim(0,2*np.pi); a.set_ylim(-1.8,1.8)
        a.set_xlabel('x'); a.set_ylabel('y'); a.grid(alpha=.2); a.legend(fontsize=8,loc='upper right')
        text=a.text(.02,.04,'',transform=a.transAxes,fontsize=9,bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
        lines.append((current,final,text))
    a=ax[5]; a.set_title('Best loss by step',fontweight='bold'); a.set_xlabel('Step'); a.set_ylabel('Half MSE'); a.set_yscale('log'); a.set_xlim(0,STEPS); a.grid(alpha=.2)
    ymin=max(losses.min()*.5,1e-10); a.set_ylim(ymin,max(losses.min(axis=2).max()*2, ymin*100))
    plots=[a.plot([],[],color=colors[m],label=names[m])[0] for m in range(5)]; a.legend(fontsize=8)
    fixed=np.argmin(losses[:,-1,:],axis=1)
    images=[]
    for f in range(STEPS//GAP+1):
        for m in range(5):
            i=np.argmin(losses[m,f]); q=states[m,f,i]; z=states[m,f,fixed[m]]
            lines[m][0].set_data(grid,np.sin(np.outer(grid,q[D:]))@q[:D]); lines[m][1].set_data(grid,np.sin(np.outer(grid,z[D:]))@z[:D])
            lines[m][2].set_text(f'Current best loss: {losses[m,f,i]:.5g}')
            plots[m].set_data(np.arange(f+1)*GAP,losses[m,:f+1].min(axis=1))
        fig.suptitle(f'20D wave fitting: 10 amplitudes + 10 frequencies  |  Step {f*GAP:,} / {STEPS:,}',fontsize=15,fontweight='bold')
        fig.canvas.draw(); rgba=np.asarray(fig.canvas.buffer_rgba()); images.append(Image.fromarray(rgba.copy()).convert('P',palette=Image.Palette.ADAPTIVE,colors=128))
    images[0].save(ROOT/'wave_20d_five.gif',save_all=True,append_images=images[1:],duration=150,loop=0,optimize=False)
    fig.savefig(ROOT/'final.png',dpi=120); plt.close(fig)
    summary={names[m]:float(losses[m,-1].min()) for m in range(5)}
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
    with zipfile.ZipFile(ROOT/'wave_20d_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ['experiment.py','results.npz','summary.json','final.png','wave_20d_five.gif','README.txt']: z.write(ROOT/name,name)

if __name__=='__main__':
    if not (ROOT/'results.npz').exists(): simulate()
    render()
