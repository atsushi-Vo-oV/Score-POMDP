20-dimensional wave fitting, one shared-initialization trial.
Model: sum_{k=1}^{10} a_k sin(w_k x); target a_k=0.7/k, w_k=k.
64 training samples x uniformly from 0 to 2*pi, inclusive. Loss = half mean squared error.
64 particles, 30000 steps, snapshots every 500, common eta=0.01.
Initial amplitudes uniform [0,0.3]; frequencies normal around target frequencies with sd 0.2.
Random seed 20261104; method random streams use seeds 8000 to 8004.
ULA, PSO, SVGD RBF, SVGD IMQ, CBO use the previous comparison's coefficients, including fixed kernel scales 0.36 and 0.18 and temperature 0.15.
Current best = minimum current loss among all 64 particles. Dotted gray = trajectory of the particle retrospectively chosen as best at the final step. Black = target.
This is only one trial, with relatively favorable initialization around target frequencies. The common numerical eta does not equalize actual update size or computation. Frequency/amplitude permutations and other symmetries make parameter recovery non-unique. RBF kernel can lose interaction strength in 20D; scales here have not been tuned.
The formal target exp(-L/0.15) is not normalizable over the unbounded parameter domain; ULA and SVGD are used as formal updates, not justified samplers of a probability distribution.
