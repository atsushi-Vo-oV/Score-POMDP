import csv, hashlib, importlib.util, json, pathlib, shutil, zipfile
import numpy as np, pandas as pd

R=pathlib.Path(__file__).resolve().parent
BASE=R.parent/'wave_common_eta_001';OLD=R.parent/'recovered_cbo_svgd_30000'
source=(BASE/'reproduce_wave.py').read_text(encoding='utf-8')
source=source.replace("MODES=['ULA','PSO','SVGD','CBO'];COLORS={'ULA':'#1779b9','PSO':'#e58616','SVGD':'#9851b5','CBO':'#138c79'}","MODES=['RBF','IMQ'];COLORS={'RBF':'#9851b5','IMQ':'#d37b12'}")
source=source.replace("fig=plt.figure(figsize=(18,10),dpi=100,layout='constrained');gs=fig.add_gridspec(2,2);artists={}","fig=plt.figure(figsize=(18,5.5),dpi=100,layout='constrained');gs=fig.add_gridspec(1,2);artists={}")
source=source.replace('Common eta=0.01: ULA / PSO / SVGD / CBO','SVGD kernels: RBF / IMQ, common eta=0.01')
source=source.replace('Wave regression: common eta=0.01 | 64 particles, 48 trials, 30,000 steps','SVGD kernel comparison | common eta=0.01, 64 particles, 48 trials')
(R/'render_helper.py').write_text(source,encoding='utf-8')
spec=importlib.util.spec_from_file_location('render_helper',R/'render_helper.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

# Check the IMQ source derivative independently by finite differences.
for y,x in [(.1,.4),(-1.,.2),(.7,.7)]:
    k=lambda z:(1+(x-z)**2/.18)**-.5
    analytic=(x-y)/.18*(1+(x-y)**2/.18)**-1.5
    assert abs((k(y+1e-6)-k(y-1e-6))/2e-6-analytic)<1e-9
initial=np.loadtxt(R/'initial.csv').reshape(48,64,2)
with np.load(OLD/'snapshots'/'svgd.npz',allow_pickle=False) as z:
    rbf=z['states'][...,:3];assert np.array_equal(z['steps'],m.STEPS)
frame=pd.read_csv(R/'svgd.csv');assert len(frame)==48*61*64
assert np.array_equal(frame.step.to_numpy().reshape(48,61,64)[0,:,0],m.STEPS)
imq=frame[['a','w','loss']].to_numpy().reshape(48,61,64,3)
orig=pd.read_csv(OLD/'summary_30000.csv');orig=orig[orig['mode']=='svgd']
all_data={};final=[]
for mode,states,pathfile in [('RBF',rbf,OLD/'svgd_path.csv'),('IMQ',imq,R/'svgd_path.csv')]:
    assert states.shape==(48,61,64,3) and np.isfinite(states).all()
    init_error=float(np.max(np.abs(states[:,0,:,:2]-initial)));assert init_error<2e-7
    max_err=0
    for trial in states:
        max_err=max(max_err,float(np.max(np.abs(m.wave_loss(trial[...,0].astype(float),trial[...,1].astype(float))-trial[...,2]))))
    assert max_err<2e-6
    path=pd.read_csv(pathfile)[['a','w','loss']].to_numpy().reshape(61,64,3)
    assert np.allclose(path,states[0],rtol=1e-6,atol=5e-7)
    loss=states[...,2].astype(float);w=states[...,1].astype(float);best=loss.min(axis=2)
    hit=(loss<.01)&((abs(w-3)<.15)|(abs(w+3)<.15));rows=[]
    for j,step in enumerate(m.STEPS):
        row={'mode':mode,'step':int(step),'trial_hits_either_sign':int(hit[:,j].any(axis=1).sum()),'particle_fraction_either_sign':float(hit[:,j].mean()),'mean_loss':float(loss[:,j].mean()),'median_trial_best_loss':float(np.median(best[:,j]))}
        if mode=='RBF':
            original=orig.iloc[j];row['trial_hits_either_sign']=int(original.trial_hits_either_sign);row['particle_fraction_either_sign']=float(original.particle_fraction_either_sign);row['mean_loss']=float(original.mean_loss);row['median_trial_best_loss']=float(original.median_trial_best_loss)
        rows.append(row)
    np.savez_compressed(R/f'{mode}_data.npz',states=states,steps=m.STEPS,fields=np.array(['a','w','loss']),trial0_path_float64=path,initial_float64=initial)
    with np.load(R/f'{mode}_data.npz',allow_pickle=False) as z:assert np.array_equal(z['states'],states)
    all_data[mode]={'states':states,'path':path,'best':best,'sampled_best':np.minimum.accumulate(best,axis=1),'hit':hit,'aggregate':rows,'winner':int(np.argmin(path[-1,:,2]))}
    final.append(rows[-1]);print(mode,'initial error',init_error,'loss error',max_err,'final',rows[-1],flush=True)
    pd.DataFrame(rows).to_csv(R/f'{mode}_summary.csv',index=False)
m.plot_curves(all_data);m.animate_wave(all_data)
(R/'wave_ULA_PSO_SVGD_CBO_30000.gif').rename(R/'svgd_rbf_imq_30000.gif')
(R/'wave_loss_comparison.png').rename(R/'svgd_rbf_imq_curves.png')
(R/'wave_loss_comparison.pdf').rename(R/'svgd_rbf_imq_curves.pdf')
(R/'README_ja.txt').write_text('''波の例におけるSVGDカーネル比較\n\n48試行、64粒子、30000更新、500更新ごとに保存。初期値、損失、eta=0.01、スコア係数1/0.15は同一。RBFは復元済みの元データ、IMQのみ同じ元コードのカーネルを差し替えて新規実行。\n\nRBF: k(x,y)=exp(-||x-y||^2/0.36)。\nIMQ: k(x,y)=(1+||x-y||^2/0.18)^(-1/2)。\n両者は同一点でk=1、近傍の距離の2乗に対する傾きも一致。遠距離ではIMQの減衰が遅い。\nIMQのSVGD反発項: (x-y)/0.18 * (1+||x-y||^2/0.18)^(-3/2)。勾配の符号は有限差分で検証。\n\n到達基準は元と同じL<0.01かつwが±3から0.15以内。比較は500更新刻みの記録時点に限る。各時点の最良と記録時点に限る過去最良は別に集計。\nスナップショットはRBFがfloat32、IMQがfloat64。各試行0の動画用経路は両方float64。元データと同じく粒子の無制限のパラメータ平面ではexp(-L/0.15)は正規化不能なので、形式的SVGD更新の比較である。1つのカーネル幅と指数による探索例であり普遍的な性能差ではない。\n\nsvgd_rbf_imq_30000.gif: 共通の試行0。赤丸は最終最良を事後選択して固定追跡、黒×は各時点の最良。\nsvgd_rbf_imq_curves.png: 48試行の集計。帯は25〜75%点。\nRBF_data.npz / IMQ_data.npz: 粒子全記録。\nsvgd_imq.cpp: 今回のIMQ実装。compare_kernels.py: 集計と作図。\n\n参考: Liu & Wang, SVGD https://arxiv.org/abs/1608.04471 ; Corrales et al., RBF/IMQ https://doi.org/10.1093/gji/ggaf096\n''',encoding='utf-8')
(R/'final_summary.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(R/'verification.json').write_text(json.dumps({'passed':True,'kernel_derivative':'central finite differences','same_initial_with_float32_rounding':True,'trials':48,'particles':64,'steps':30000,'snapshot_interval':500},indent=2),encoding='utf-8')
archive=R/'svgd_kernel_comparison_bundle.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(R.iterdir()):
        if p.is_file() and p!=archive and p.suffix not in ('.obj','.csv') or p.name.endswith('_summary.csv'):
            z.write(p,p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('Completed: ZIP verified',flush=True)
