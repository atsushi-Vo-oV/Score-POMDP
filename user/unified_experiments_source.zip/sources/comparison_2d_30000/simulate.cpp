#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
namespace fs=std::filesystem;
constexpr int N=64;
constexpr double PI=3.1415926535897932384626433832795, TEMP=.5, H=.75;
struct V {double x=0,y=0;V operator+(V b)const{return{x+b.x,y+b.y};}V operator-(V b)const{return{x-b.x,y-b.y};}V operator*(double a)const{return{x*a,y*a};}};
static_assert(sizeof(V)==2*sizeof(double));
double sq(V a){return a.x*a.x+a.y*a.y;}
pair<double,V> eval(V p){
 const double c=sqrt(3.)/2,s=.5,z=c*p.x-s*p.y,w=s*p.x+c*p.y;
 const double f=.5*(z*z+w*w+10*(1-cos(2*PI*z))+10*(1-cos(2*PI*w)));
 const double a=z+10*PI*sin(2*PI*z),b=w+10*PI*sin(2*PI*w);
 return {f,{c*a+s*b,-s*a+c*b}};
}
V consensus(const array<V,N>&x,const array<double,N>&loss){
 double least=*min_element(loss.begin(),loss.end()),sum=0;V mean{};
 for(int i=0;i<N;i++){double w=exp(-(loss[i]-least)/TEMP);sum+=w;mean=mean+x[i]*w;}
 return mean*(1/sum);
}
array<V,N> stein(const array<V,N>&x,const array<V,N>&g){
 array<V,N> f{};
 for(int i=0;i<N;i++)f[i]=g[i]*(-1/TEMP);
 for(int i=0;i<N;i++)for(int j=i+1;j<N;j++){
  V d=x[i]-x[j];double k=exp(-sq(d)/(2*H*H));
  f[i]=f[i]+g[j]*(-k/TEMP)+d*(k/(H*H));
  f[j]=f[j]+g[i]*(-k/TEMP)-d*(k/(H*H));
 }
 for(auto &v:f)v=v*(1./N);return f;
}
void selftest(){
 for(V p:vector<V>{{0,0},{.14,-.37},{2.1,3.7},{-4.8,.01}}){
  auto [f,g]=eval(p);if(f<0)throw runtime_error("negative objective");
  const double e=1e-6;
  double dx=(eval({p.x+e,p.y}).first-eval({p.x-e,p.y}).first)/(2*e);
  double dy=(eval({p.x,p.y+e}).first-eval({p.x,p.y-e}).first)/(2*e);
  if(abs(dx-g.x)>2e-7||abs(dy-g.y)>2e-7)throw runtime_error("gradient check failed");
 }
 if(eval({0,0}).first!=0)throw runtime_error("global minimum");
 array<V,N>x{},g{};array<double,N>l{};
 for(int i=0;i<N;i++){x[i]={1,0};g[i]={2,-3};l[i]=10;}
 auto c=consensus(x,l);if(abs(c.x-1)>1e-14||c.y!=0)throw runtime_error("consensus");
 auto s=stein(x,g);for(auto v:s)if(abs(v.x+4)>1e-12||abs(v.y-6)>1e-12)throw runtime_error("Stein score sign");
 g.fill({0,0});for(int i=0;i<N;i++)x[i]={i<N/2?-1.:1.,0};s=stein(x,g);
 if(!(s[0].x<0&&s[N-1].x>0))throw runtime_error("Stein repulsion sign");
 cout<<"PASS: objective, finite-difference gradient, consensus, SVGD attraction/repulsion\n";
}
int main(int argc,char**argv){try{
 if(argc==2&&string(argv[1])=="--selftest"){selftest();return 0;}
 if(argc!=5)throw runtime_error("usage: simulate MODE TRIALS STEPS DIRECTORY");
 string mode=argv[1];int trials=stoi(argv[2]),T=stoi(argv[3]);fs::path root=argv[4];
 if((mode!="ULA"&&mode!="PSO"&&mode!="SVGD"&&mode!="CBO")||trials<1||T<1)throw runtime_error("invalid arguments");
 vector<int> frames={0,1,2,5,10,20,50,100,200,500};for(int t=750;t<=T;t+=250)frames.push_back(t);frames.push_back(T);
 frames.erase(remove_if(frames.begin(),frames.end(),[T](int v){return v>T;}),frames.end());sort(frames.begin(),frames.end());frames.erase(unique(frames.begin(),frames.end()),frames.end());
 fs::create_directories(root);for(string suffix:{".history.f64",".states.f64",".summary.csv"})if(fs::exists(root/(mode+suffix)))throw runtime_error("refusing overwrite");
 ifstream input(root/"initial.f64",ios::binary);if(!input)throw runtime_error("initial file missing");
 ofstream hist(root/(mode+".history.f64"),ios::binary),states(root/(mode+".states.f64"),ios::binary),summary(root/(mode+".summary.csv"));
 summary<<setprecision(17)<<"trial,step,current_best,best_so_far,mean_loss,rms_spread,current_hit,best_hit,best_x,best_y\n";
 auto start=chrono::steady_clock::now();
 for(int tr=0;tr<trials;tr++){
  array<V,N>x{},v{},pbest{},grad{},next{};array<double,N>loss{},ploss{};
  input.read(reinterpret_cast<char*>(x.data()),sizeof(V)*N);if(!input)throw runtime_error("initial file truncated");
  pbest=x;for(int i=0;i<N;i++)ploss[i]=eval(x[i]).first;
  mt19937_64 rng(900000+tr);normal_distribution<double>normal;uniform_real_distribution<double>uniform(0,1);
  double ever=numeric_limits<double>::infinity();size_t frame=0;
  for(int step=0;step<=T;step++){
   double mean=0;for(int i=0;i<N;i++){auto e=eval(x[i]);loss[i]=e.first;grad[i]=e.second;mean+=loss[i]/N;if(!isfinite(loss[i]))throw runtime_error("nonfinite loss");}
   int best=min_element(loss.begin(),loss.end())-loss.begin();ever=min(ever,loss[best]);double values[2]={loss[best],ever};hist.write(reinterpret_cast<char*>(values),sizeof(values));
   if(frame<frames.size()&&step==frames[frame]){states.write(reinterpret_cast<char*>(x.data()),sizeof(V)*N);frame++;}
   if(step%100==0||step==T){V center{};for(auto a:x)center=center+a*(1./N);double variance=0;for(auto a:x)variance+=sq(a-center)/N;
    summary<<tr<<','<<step<<','<<loss[best]<<','<<ever<<','<<mean<<','<<sqrt(variance)<<','<<(loss[best]<.01)<<','<<(ever<.01)<<','<<x[best].x<<','<<x[best].y<<'\n';
   }
   if(step==T)break;
   if(mode=="ULA")for(int i=0;i<N;i++){V noise{normal(rng),normal(rng)};next[i]=x[i]-grad[i]*.001+noise*sqrt(2*TEMP*.001);}
   else if(mode=="SVGD"){auto f=stein(x,grad);for(int i=0;i<N;i++)next[i]=x[i]+f[i]*.001;}
   else if(mode=="CBO"){V c=consensus(x,loss);for(int i=0;i<N;i++){V noise{normal(rng),normal(rng)};next[i]=x[i]+(c-x[i])*.01+noise*(.7*sqrt(.01)*sqrt(sq(x[i]-c)));}}
   else{
    for(int i=0;i<N;i++)if(loss[i]<ploss[i]){ploss[i]=loss[i];pbest[i]=x[i];}
    V global=pbest[min_element(ploss.begin(),ploss.end())-ploss.begin()];
    const double phi=4.1,chi=2/(phi-2+sqrt(phi*phi-4*phi));
    for(int i=0;i<N;i++){V r{uniform(rng),uniform(rng)},s{uniform(rng),uniform(rng)},a=pbest[i]-x[i],b=global-x[i];
     v[i]={(v[i].x+2.05*r.x*a.x+2.05*s.x*b.x)*chi,(v[i].y+2.05*r.y*a.y+2.05*s.y*b.y)*chi};next[i]=x[i]+v[i];
    }
   }
   for(auto a:next)if(!isfinite(a.x)||!isfinite(a.y))throw runtime_error("nonfinite state");x=next;
  }
  hist.flush();states.flush();summary.flush();
  ofstream progress(root/(mode+".progress.json"));progress<<"{\"completed_trials\":"<<tr+1<<",\"trials\":"<<trials<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
  cerr<<mode<<" trial "<<tr+1<<"/"<<trials<<" complete\n";
 }
 if(!hist||!states||!summary)throw runtime_error("output write failed");
 ofstream done(root/(mode+".done.json"));done<<"{\"trials\":"<<trials<<",\"steps\":"<<T<<",\"frames\":"<<frames.size()<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 return 0;
}catch(const exception&e){cerr<<e.what()<<'\n';return 1;}}
