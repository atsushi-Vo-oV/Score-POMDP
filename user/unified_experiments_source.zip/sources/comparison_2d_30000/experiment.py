"""Reproducible 2-D comparison; run compiled simulate.exe, validate, plot, package."""
from __future__ import annotations
import argparse, concurrent.futures, csv, hashlib, json, os, pathlib, platform, subprocess, sys, time, zipfile
import numpy as np

SOURCE = pathlib.Path(__file__).resolve().parent
WORK = SOURCE.parent.parent/'work'
sys.path.insert(0, str(WORK/'plotting_packages'))
os.environ.setdefault('MPLCONFIGDIR', str(WORK/'mplconfig_2d'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.font_manager import FontProperties
from PIL import Image

MODES = ['ULA','PSO','SVGD','CBO']
COLORS = {'ULA':'#1976b9','PSO':'#e58a17','SVGD':'#9852b5','CBO':'#16977c'}
FONT = pathlib.Path('C:/Windows/Fonts/meiryo.ttc')
if FONT.exists():
    prop = FontProperties(fname=str(FONT))
    matplotlib.font_manager.fontManager.addfont(str(FONT))
    plt.rcParams['font.family'] = prop.get_name()
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'savefig.facecolor':'white'})

def write_json(path, value):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    os.replace(tmp,path)

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def objective(x):
    c=np.sqrt(3)/2; s=.5
    z=c*x[...,0]-s*x[...,1];w=s*x[...,0]+c*x[...,1]
    return .5*(z*z+w*w+10*(1-np.cos(2*np.pi*z))+10*(1-np.cos(2*np.pi*w)))

def frames(steps):
    return np.array(sorted(set([v for v in [0,1,2,5,10,20,50,100,200,500] if v<=steps]+list(range(750,steps+1,250))+[steps])),dtype=np.int64)

def compute(root, trials, steps):
    root.mkdir(parents=True,exist_ok=True)
    for mode in MODES:
        if (root/f'{mode}.history.f64').exists():raise RuntimeError(f'{mode} already has data; use --analyze to read it')
    seed=20261030
    initial=np.random.default_rng(seed).uniform(-5.12,5.12,size=(trials,64,2)).astype('<f8')
    initial.tofile(root/'initial.f64')
    config={'objective':'Rotated Rastrigin / 2; Q = rotation by 30 degrees; global minimum (0,0), loss 0','particles':64,'trials':trials,'steps':steps,'initial_seed':seed,'initial_rng':'numpy.default_rng / PCG64','initial_range':[-5.12,5.12],'domain':'R^2, no clipping or boundaries','temperature':.5,'ULA':{'eta':.001,'noise_sqrt_2_T_eta':True},'SVGD':{'epsilon':.001,'rbf_lengthscale':.75,'kernel':'exp(-squared_distance / (2*lengthscale^2))','target':'exp(-f/temperature)'},'CBO':{'dt':.01,'lambda':1.,'sigma':.7,'alpha':2.,'noise':'isotropic; no Heaviside switch; no gradient'},'PSO':{'phi1':2.05,'phi2':2.05,'chi':float(2/(4.1-2+np.sqrt(4.1**2-4*4.1))),'initial_velocity':0,'topology':'synchronous global best','velocity_clipping':False},'method_rng':'mt19937_64(900000 + trial), identical seed numbers across modes','summary_interval':100,'snapshots':frames(steps).tolist(),'history_fields':['current_best','best_so_far'],'success_threshold':.01,'python':platform.python_version(),'numpy':np.__version__,'matplotlib':matplotlib.__version__,'initial_sha256':digest(root/'initial.f64'),'simulate_cpp_sha256':digest(SOURCE/'simulate.cpp'),'simulate_exe_sha256':digest(SOURCE/'simulate.exe')}
    write_json(root/'config.json',config)
    subprocess.run([str(SOURCE/'simulate.exe'),'--selftest'],check=True)
    def task(mode):
        with (root/f'{mode}.log').open('w',encoding='utf-8') as log:
            result=subprocess.run([str(SOURCE/'simulate.exe'),mode,str(trials),str(steps),str(root)],stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if result.returncode:raise RuntimeError(f'{mode} failed; see {mode}.log')
        return mode
    started=time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(task,m):m for m in MODES}
        while futures:
            done,_=concurrent.futures.wait(futures,timeout=15,return_when=concurrent.futures.FIRST_COMPLETED)
            for f in done:
                mode=f.result();del futures[f];print(f'{mode}: all {trials} trials finished',flush=True)
            progress={}
            for mode in MODES:
                p=root/f'{mode}.progress.json'
                try:progress[mode]=json.loads(p.read_text(encoding='utf-8'))
                except (OSError,json.JSONDecodeError):progress[mode]={'completed_trials':0}
            state={'state':'running' if futures else 'computed','completed_trials':sum(p['completed_trials'] for p in progress.values()),'total_trials':trials*4,'elapsed_seconds':round(time.time()-started,2),'methods':progress}
            write_json(root/'status.json',state)
            print(f"Progress {state['completed_trials']}/{trials*4}, {state['elapsed_seconds']:.1f}s",flush=True)

def validate_and_load(root):
    config=json.loads((root/'config.json').read_text(encoding='utf-8'));trials=config['trials'];steps=config['steps'];ss=frames(steps)
    if (root/'initial.f64').exists():
        initial=np.fromfile(root/'initial.f64',dtype='<f8').reshape(trials,64,2)
    else:
        with np.load(root/'ULA_data.npz',allow_pickle=False) as z:initial=z['initial']
    assert hashlib.sha256(initial.astype('<f8').tobytes()).hexdigest()==config['initial_sha256']
    data={};validation={'checks':[],'methods':{},'all_passed':False}
    for mode in MODES:
        done=json.loads((root/f'{mode}.done.json').read_text());assert done['trials']==trials and done['steps']==steps and done['frames']==len(ss)
        raw=(root/f'{mode}.history.f64').exists() and (root/f'{mode}.states.f64').exists()
        if raw:
            history=np.fromfile(root/f'{mode}.history.f64',dtype='<f8').reshape(trials,steps+1,2)
            positions=np.fromfile(root/f'{mode}.states.f64',dtype='<f8').reshape(trials,len(ss),64,2)
        else:
            with np.load(root/f'{mode}_data.npz',allow_pickle=False) as z:
                history=np.stack([z['current_best'],z['best_so_far']],axis=-1);positions=z['positions']
                assert np.array_equal(z['snapshot_steps'],ss)
        assert np.isfinite(history).all() and np.isfinite(positions).all()
        assert np.array_equal(initial,positions[:,0])
        assert np.all(history[:,:,1]>=-1e-13)
        assert np.all(np.diff(history[:,:,1],axis=1)<=1e-13)
        assert np.all(history[:,:,1]<=history[:,:,0]+1e-12)
        recomputed=objective(positions).min(axis=2)
        error=float(np.max(np.abs(recomputed-history[:,ss,0])))
        assert error<5e-12,(mode,error)
        with (root/f'{mode}.summary.csv').open(newline='') as f:records=list(csv.DictReader(f))
        sample_steps=list(range(0,steps+1,100))
        if sample_steps[-1]!=steps:sample_steps.append(steps)
        assert len(records)==trials*len(sample_steps)
        stats={k:np.array([float(r[k]) for r in records]).reshape(trials,len(sample_steps)) for k in ['current_best','best_so_far','mean_loss','rms_spread','current_hit','best_hit','best_x','best_y']}
        assert all(np.isfinite(v).all() for v in stats.values())
        assert np.allclose(stats['current_best'],history[:,sample_steps,0],atol=1e-12,rtol=0)
        assert np.allclose(stats['best_so_far'],history[:,sample_steps,1],atol=1e-12,rtol=0)
        assert np.all(stats['mean_loss']+1e-12>=stats['current_best'])
        if raw:
            np.savez_compressed(root/f'{mode}_data.npz',positions=positions,snapshot_steps=ss,current_best=history[:,:,0],best_so_far=history[:,:,1],initial=initial)
        with np.load(root/f'{mode}_data.npz',allow_pickle=False) as z:
            assert np.array_equal(z['positions'],positions) and np.array_equal(z['initial'],initial)
            assert np.array_equal(z['current_best'],history[:,:,0]) and np.array_equal(z['best_so_far'],history[:,:,1])
        data[mode]={'history':history,'positions':positions,'stats':stats,'sample_steps':np.array(sample_steps),'seconds':done['seconds']}
        validation['methods'][mode]={'trials':trials,'final_step':steps,'snapshot_count':len(ss),'max_recomputed_loss_error':error,'elapsed_seconds':done['seconds'],'data_sha256':digest(root/f'{mode}_data.npz')}
        print(f'{mode}: validation passed, max loss difference {error:.3g}',flush=True)
    validation['checks']=['compiled objective/gradient and SVGD direction self-tests','all methods completed exact requested step count','identical initial positions across all 4 modes','finite values and expected shapes/counts','best-so-far monotone over every update','snapshot losses recomputed independently in numpy','summary records consistent with per-step history']
    validation['all_passed']=True;write_json(root/'verification.json',validation)
    return config,data

def aggregate(root,config,data):
    output=[];final=[]
    for mode in MODES:
        d=data[mode];s=d['stats']
        for j,step in enumerate(d['sample_steps']):
            row={'mode':mode,'step':int(step),'trials':config['trials']}
            for field in ['current_best','best_so_far','mean_loss','rms_spread']:
                v=s[field][:,j]
                row[field+'_median']=float(np.median(v));row[field+'_q25']=float(np.quantile(v,.25));row[field+'_q75']=float(np.quantile(v,.75))
            row['current_success_trials']=int(s['current_hit'][:,j].sum());row['ever_success_trials']=int(s['best_hit'][:,j].sum());output.append(row)
        final.append({'mode':mode,'trials':config['trials'],'step':config['steps'],'current_success_trials':int(s['current_hit'][:,-1].sum()),'ever_success_trials':int(s['best_hit'][:,-1].sum()),'median_current_best':float(np.median(s['current_best'][:,-1])),'median_best_so_far':float(np.median(s['best_so_far'][:,-1])),'median_mean_loss':float(np.median(s['mean_loss'][:,-1])),'median_rms_spread':float(np.median(s['rms_spread'][:,-1])),'runtime_seconds':d['seconds']})
    for name,records in [('aggregate.csv',output),('final_summary.csv',final)]:
        with (root/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    write_json(root/'final_summary.json',final)

def plot_curves(root,config,data):
    fig,axs=plt.subplots(2,2,figsize=(13.8,9.2),constrained_layout=True)
    specs=[('best_so_far','過去を含む最良損失'),('current_best','各時点の最良粒子の損失'),('mean_loss','粒子全体の平均損失'),('rms_spread','粒子群の広がり（RMS距離）')]
    for ax,(field,title) in zip(axs.flat,specs):
        for mode in MODES:
            values=data[mode]['stats'][field];x=data[mode]['sample_steps'];median=np.median(values,axis=0);lo,hi=np.quantile(values,[.25,.75],axis=0)
            ax.plot(x,median,color=COLORS[mode],lw=2,label=mode);ax.fill_between(x,lo,hi,color=COLORS[mode],alpha=.13,lw=0)
        ax.set_title(title);ax.set_xlabel('更新ステップ');ax.set_xscale('symlog',linthresh=100);ax.set_xlim(0,config['steps']);ax.set_xticks([0,100,1000,10000,config['steps']]);ax.set_xticklabels(['0','100','1,000','10,000',f"{config['steps']:,}"])
        ax.set_yscale('symlog',linthresh=.001 if field!='rms_spread' else .0001);ax.set_ylim(bottom=0);ax.grid(alpha=.2)
        if field in ('current_best','best_so_far'):ax.axhline(.01,color='#555555',ls='--',lw=.8,label='到達基準 0.01')
    handles,labels=axs[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=5,frameon=False)
    fig.suptitle(f"2次元・64粒子・{config['steps']:,}ステップ｜線：{config['trials']}試行の中央値、帯：25–75%点",fontsize=15)
    fig.savefig(root/'comparison_curves.png',dpi=160);fig.savefig(root/'comparison_curves.pdf');plt.close(fig)

def landscape(ax,limit=5.5):
    xx=np.linspace(-limit,limit,350);X,Y=np.meshgrid(xx,xx);Z=objective(np.stack([X,Y],axis=-1))
    im=ax.imshow(Z,origin='lower',extent=[-limit,limit,-limit,limit],cmap='YlGnBu_r',vmin=0,vmax=40,alpha=.85)
    ax.contour(X,Y,Z,levels=[1,5,10,20,30],colors='#37495a',linewidths=.35,alpha=.3)
    ax.scatter([0],[0],s=130,marker='*',c='white',edgecolors='black',linewidths=.8,zorder=4)
    ax.set_xlim(-limit,limit);ax.set_ylim(-limit,limit);ax.set_xlabel('x₁');ax.set_ylabel('x₂');return im

def plot_final(root,config,data,ss):
    fig,axs=plt.subplots(1,4,figsize=(15.3,4.5),layout='constrained')
    for ax,mode in zip(axs,MODES):
        im=landscape(ax);p=data[mode]['positions'][0,-1];loss=objective(p);best=int(loss.argmin())
        ax.scatter(p[:,0],p[:,1],s=25,c=COLORS[mode],edgecolors='white',linewidths=.5,zorder=5)
        ax.scatter(p[best,0],p[best,1],s=100,facecolors='none',edgecolors='#d72835',linewidths=1.7,zorder=6)
        outside=int((np.abs(p)>5.5).any(axis=1).sum())
        ax.set_title(f'{mode}\n現在最良 {loss[best]:.3g} / 枠外 {outside}')
    fig.colorbar(im,ax=list(axs),shrink=.78,label='目的関数 f(x)')
    fig.suptitle(f"ステップ {config['steps']:,}｜事前固定した試行0｜白星：最適点、赤丸：現在最良粒子",fontsize=13)
    fig.savefig(root/'final_positions.png',dpi=160);plt.close(fig)

def animate(root,config,data,ss):
    fig,axs=plt.subplots(2,2,figsize=(9,8.8),layout='constrained');scat={};bestscat={};texts={}
    for ax,mode in zip(axs.flat,MODES):
        landscape(ax);ax.set_title(mode,color=COLORS[mode],fontsize=14,fontweight='bold')
        scat[mode]=ax.scatter([],[],s=25,c=COLORS[mode],edgecolors='white',linewidths=.5,zorder=5)
        bestscat[mode]=ax.scatter([],[],s=100,facecolors='none',edgecolors='#d72835',linewidths=1.7,zorder=6)
        texts[mode]=ax.text(.02,.98,'',transform=ax.transAxes,va='top',fontsize=9,bbox={'facecolor':'white','alpha':.92,'edgecolor':'none'},zorder=8)
    heading=fig.suptitle('',fontsize=13)
    fig.supxlabel('試行0を全方式で固定。白星：最適点、赤丸：現在最良。表示時間の間隔は非等間隔。',fontsize=9)
    def update(j):
        step=int(ss[j]);heading.set_text(f'ULA / PSO / SVGD / CBO — ステップ {step:,} / {config["steps"]:,}')
        for mode in MODES:
            p=data[mode]['positions'][0,j];loss=objective(p);idx=int(loss.argmin());scat[mode].set_offsets(p);bestscat[mode].set_offsets(p[idx:idx+1])
            outside=int((np.abs(p)>5.5).any(axis=1).sum())
            texts[mode].set_text(f'現在最良 = {loss[idx]:.3g}\n過去最良 = {data[mode]["history"][0,step,1]:.3g}\n枠外 = {outside}')
        return list(scat.values())+list(bestscat.values())+list(texts.values())+[heading]
    animation=FuncAnimation(fig,update,frames=len(ss),blit=False,interval=100)
    animation.save(root/'particles_comparison.gif',writer=PillowWriter(fps=10),dpi=105)
    update(len(ss)-1);fig.savefig(root/'animation_last_frame.png',dpi=130);plt.close(fig)
    with Image.open(root/'particles_comparison.gif') as im:
        assert im.n_frames==len(ss)
        for j in range(im.n_frames):im.seek(j);im.load()
    print(f'GIF validated: {len(ss)} frames, final step {ss[-1]}',flush=True)

def write_readme(root,config):
    text=f'''2次元の比較例：ULA / PSO / SVGD / CBO

目的関数
  z=Qx、Q=[[sqrt(3)/2,-1/2],[1/2,sqrt(3)/2]]。
  f(x)=1/2 * sum_j [z_j^2 + 10(1-cos(2*pi*z_j))]。
  大域最小はx=(0,0)、f=0。多数の局所的な谷を持つ回転Rastrigin型。
  全空間R^2で計算する。[-5.12,5.12]^2は初期値の範囲のみ。
  同一試行番号では4方式すべて同じ64粒子から開始。
  {config['trials']}試行、各{config['steps']:,}ステップ。結果を見た係数の調整・試行の選別はしていない。

更新則（Zは標準正規ベクトル、r1,r2は成分ごとに独立な一様乱数）
  ULA: x_i <- x_i - eta grad f(x_i) + sqrt(2 T eta) Z_i
    eta=0.001、T=0.5。受理棄却補正のないEuler離散化。
  SVGD: x_i <- x_i + epsilon/N sum_j [ -k(x_j,x_i) grad f(x_j)/T
                                         + k(x_j,x_i)(x_i-x_j)/ell^2 ]
    epsilon=0.001、T=0.5、ell=0.75、k(a,b)=exp(-||a-b||^2/(2 ell^2))。
    固定バンド幅、全粒子の同時更新。Adagradやアニーリングは使わない。
  CBO: c=sum_i exp(-alpha f(x_i)) x_i / sum_i exp(-alpha f(x_i))
       x_i <- x_i + lambda dt(c-x_i) + sigma sqrt(dt)||x_i-c|| Z_i
    alpha=2、lambda=1、sigma=0.7、dt=0.01。
    等方ノイズ・Heaviside切替なしのCBO。勾配は更新に使わない。
  PSO: v_i <- chi [v_i + 2.05 r1*(pbest_i-x_i) + 2.05 r2*(gbest-x_i)]
       x_i <- x_i + v_i
    chi=2/(4.1-2+sqrt(4.1^2-4*4.1))=0.729843788...。
    初速度0。個人・全体の過去最良を使用。速度制限や境界クリップなし。

評価
  current_best: 各時点での64粒子中の最良損失。最良粒子の番号は変わりうる。
  best_so_far: それまでの全ステップ・全粒子中の最良損失。
  mean_loss: 現在の64粒子の平均損失。
  rms_spread: 現在粒子の算術平均からのRMS距離。
  到達基準 f<0.01。current_success_trialsとever_success_trialsを区別。
  線は試行間中央値、帯は25–75%点（信頼区間ではない）。
  PSOのgbestやCBO重心を追加の候補点として評価せず、共通して実粒子の損失を比較。

解釈
  ULA・SVGDはp(x) ∝ exp(-f(x)/0.5)の分布近似に使う方法であり、
  PSO・CBOのように最小点へ全粒子を潰すことが目的ではない。
  この目的関数は全空間で二次成長するため上の目標分布は正規化可能。
  ULAの有限刻みには離散化誤差があり、どちらも分布への収束を検証した実験ではない。
  同じ更新回数で比較するが、計算量・勾配評価数・連続時間は同じではない。
  特にSVGDの粒子間相互作用はO(N^2)。単一課題・係数1設定の例で、一般的順位ではない。

ファイル
  particles_comparison.gif: 試行0の全4方式。試行0は結果を見る前に固定。
    128枚（30,000ステップの場合）。初期の動きは細かく、後半は250ステップ間隔。
    白星=大域最小点、赤丸=その時点の最良粒子、枠外粒子数も表示。
    アニメーションはステップ間隔が不均一なため実時間の速さの比較には使わない。
  comparison_curves.png / .pdf: 4指標の時系列。100ステップ刻み。
  final_positions.png: 同じ試行0の最終位置。
  final_summary.csv / .json: {config['steps']:,}ステップ時点の比較集計。
  aggregate.csv: 100ステップ刻みの集計と四分位点。
  MODE_data.npz: 全{config['trials']}試行の記録位置、記録時刻、全ステップのcurrent_bestとbest_so_far。
    positions形状=[試行,記録時刻,64,2]。位置はfloat64。NPZはallow_pickle=Falseで読める。
  MODE.summary.csv: 試行別の100ステップ刻みの指標。
  config.json / verification.json: 設定・ハッシュ・検証結果。
  simulate.cpp / simulate.exe: C++17計算コードと今回のWindows実行ファイル。
  experiment.py: 実行・検証・図・動画・パッケージ生成。
    Windows MSVC /O2 /std:c++17 /EHscでビルド。
    Python依存はnumpy,matplotlib,Pillow。再描画: experiment.py --analyze。
    新規実行は既存データを上書きせず別の--directoryを指定。

参考（更新則の根拠。今回の係数を推奨する文献という意味ではない）
  ULA: Durmus & Moulines https://arxiv.org/abs/1507.05021
  SVGD: Liu & Wang (2016) https://arxiv.org/abs/1608.04471
  PSO: Clerc & Kennedy (2002) https://doi.org/10.1109/4235.985692
  CBO: Pinnau et al. https://arxiv.org/abs/1604.05648
  Rastrigin: https://www.sfu.ca/~ssurjano/rastr.html
'''
    (root/'README_ja.txt').write_text(text,encoding='utf-8')

def package(root):
    archive=root/'comparison_2d_30000_bundle.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(root.iterdir()):
            if p.is_file() and p!=archive and p.suffix not in ('.f64','.obj','.tmp'):
                z.write(p,p.name)
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    print(f'ZIP CRC passed: {archive.stat().st_size:,} bytes',flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--trials',type=int,default=48);parser.add_argument('--steps',type=int,default=30000);parser.add_argument('--directory',type=pathlib.Path,default=SOURCE);parser.add_argument('--analyze',action='store_true');parser.add_argument('--no-gif',action='store_true');args=parser.parse_args();root=args.directory.resolve()
    if not args.analyze:compute(root,args.trials,args.steps)
    config,data=validate_and_load(root);aggregate(root,config,data);ss=frames(config['steps']);plot_curves(root,config,data);plot_final(root,config,data,ss)
    if not args.no_gif:animate(root,config,data,ss)
    write_readme(root,config)
    status=json.loads((root/'status.json').read_text(encoding='utf-8'));status['state']='complete';status['verified']=True;write_json(root/'status.json',status)
    package(root)
    print(json.dumps(json.loads((root/'final_summary.json').read_text()),ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
