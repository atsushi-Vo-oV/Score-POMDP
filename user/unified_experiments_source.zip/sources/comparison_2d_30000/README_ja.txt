2次元の比較例：ULA / PSO / SVGD / CBO

目的関数
  z=Qx、Q=[[sqrt(3)/2,-1/2],[1/2,sqrt(3)/2]]。
  f(x)=1/2 * sum_j [z_j^2 + 10(1-cos(2*pi*z_j))]。
  大域最小はx=(0,0)、f=0。多数の局所的な谷を持つ回転Rastrigin型。
  全空間R^2で計算する。[-5.12,5.12]^2は初期値の範囲のみ。
  同一試行番号では4方式すべて同じ64粒子から開始。
  48試行、各30,000ステップ。結果を見た係数の調整・試行の選別はしていない。

更新則（Zは標準正規ベクトル、r1,r2は成分ごとに独立な一様乱数）
  ULA: x_i <- x_i - eta grad f(x_i) + sqrt(2 T eta) Z_i
    eta=0.001、T=0.5。受理棄却補正のないEuler離散化。
  SVGD: x_i <- x_i + epsilon/N sum_j [ -k(x_j,x_i) grad f(x_j)/T
                                         + k(x_j,x_i)(x_i-x_j)/ell^2 ]
    epsilon=0.001、T=0.5、ell=0.75、k(a,b)=exp(-||a-b||^2/(2 ell^2))。
    固定バンド幅、全粒子の同時更新。Adagradやアニーリングは使わない。
  CBO: c=sum_i exp(-alpha f(x_i)) x_i / sum_i exp(-alpha f(x_i))
       x_i <- x_i + lambda dt(c-x_i) + sigma sqrt(dt)||x_i-c|| Z_i
    alpha=2、lambda=1、sigma=0.7、dt=0.01。
    等方ノイズ・Heaviside切替なしのCBO。勾配は更新に使わない。
  PSO: v_i <- chi [v_i + 2.05 r1*(pbest_i-x_i) + 2.05 r2*(gbest-x_i)]
       x_i <- x_i + v_i
    chi=2/(4.1-2+sqrt(4.1^2-4*4.1))=0.729843788...。
    初速度0。個人・全体の過去最良を使用。速度制限や境界クリップなし。

評価
  current_best: 各時点での64粒子中の最良損失。最良粒子の番号は変わりうる。
  best_so_far: それまでの全ステップ・全粒子中の最良損失。
  mean_loss: 現在の64粒子の平均損失。
  rms_spread: 現在粒子の算術平均からのRMS距離。
  到達基準 f<0.01。current_success_trialsとever_success_trialsを区別。
  線は試行間中央値、帯は25–75%点（信頼区間ではない）。
  PSOのgbestやCBO重心を追加の候補点として評価せず、共通して実粒子の損失を比較。

解釈
  ULA・SVGDはp(x) ∝ exp(-f(x)/0.5)の分布近似に使う方法であり、
  PSO・CBOのように最小点へ全粒子を潰すことが目的ではない。
  この目的関数は全空間で二次成長するため上の目標分布は正規化可能。
  ULAの有限刻みには離散化誤差があり、どちらも分布への収束を検証した実験ではない。
  同じ更新回数で比較するが、計算量・勾配評価数・連続時間は同じではない。
  特にSVGDの粒子間相互作用はO(N^2)。単一課題・係数1設定の例で、一般的順位ではない。

ファイル
  particles_comparison.gif: 試行0の全4方式。試行0は結果を見る前に固定。
    128枚（30,000ステップの場合）。初期の動きは細かく、後半は250ステップ間隔。
    白星=大域最小点、赤丸=その時点の最良粒子、枠外粒子数も表示。
    アニメーションはステップ間隔が不均一なため実時間の速さの比較には使わない。
  comparison_curves.png / .pdf: 4指標の時系列。100ステップ刻み。
  final_positions.png: 同じ試行0の最終位置。
  final_summary.csv / .json: 30,000ステップ時点の比較集計。
  aggregate.csv: 100ステップ刻みの集計と四分位点。
  MODE_data.npz: 全48試行の記録位置、記録時刻、全ステップのcurrent_bestとbest_so_far。
    positions形状=[試行,記録時刻,64,2]。位置はfloat64。NPZはallow_pickle=Falseで読める。
  MODE.summary.csv: 試行別の100ステップ刻みの指標。
  config.json / verification.json: 設定・ハッシュ・検証結果。
  simulate.cpp / simulate.exe: C++17計算コードと今回のWindows実行ファイル。
  experiment.py: 実行・検証・図・動画・パッケージ生成。
    Windows MSVC /O2 /std:c++17 /EHscでビルド。
    Python依存はnumpy,matplotlib,Pillow。再描画: experiment.py --analyze。
    新規実行は既存データを上書きせず別の--directoryを指定。

参考（更新則の根拠。今回の係数を推奨する文献という意味ではない）
  ULA: Durmus & Moulines https://arxiv.org/abs/1507.05021
  SVGD: Liu & Wang (2016) https://arxiv.org/abs/1608.04471
  PSO: Clerc & Kennedy (2002) https://doi.org/10.1109/4235.985692
  CBO: Pinnau et al. https://arxiv.org/abs/1604.05648
  Rastrigin: https://www.sfu.ca/~ssurjano/rastr.html
