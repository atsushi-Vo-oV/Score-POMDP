import pathlib,sys,importlib.util,shutil,numpy as np,json,zipfile
r=pathlib.Path.cwd();common=r.parent/'wave_common_eta_001';imq=r.parent/'wave_svgd_imq_001'
s=(common/'reproduce_wave.py').read_text(encoding='utf-8')
s=s.replace("MODES=['ULA','PSO','SVGD','CBO'];COLORS={'ULA':'#1779b9','PSO':'#e58616','SVGD':'#9851b5','CBO':'#138c79'}","MODES=['ULA','PSO','SVGD RBF','SVGD IMQ','CBO'];COLORS={'ULA':'#1779b9','PSO':'#e58616','SVGD RBF':'#9851b5','SVGD IMQ':'#d37b12','CBO':'#138c79'}")
s=s.replace("fig=plt.figure(figsize=(18,10),dpi=100,layout='constrained');gs=fig.add_gridspec(2,2);artists={}","fig=plt.figure(figsize=(18,15),dpi=100,layout='constrained');gs=fig.add_gridspec(3,2);artists={}")
s=s.replace('Common eta=0.01: ULA / PSO / SVGD / CBO','Wave regression: 5 methods, common eta=0.01')
s=s.replace("current,=wx.plot([],[],color='#777777',lw=1,ls='--',alpha=.8,label='Current best',zorder=1)","current,=wx.plot([],[],color=c,lw=1.8,ls='-',label='Current best',zorder=3)")
s=s.replace("fixed,=wx.plot([],[],color=c,lw=1.8,label=f'Final best #{r[\"winner\"]} (fixed)',zorder=3)","fixed,=wx.plot([],[],color='#444444',lw=1.5,ls=':',label=f'Final best #{r[\"winner\"]} (fixed)',zorder=2)")
s=s.replace("now=ax.scatter([],[],s=45,marker='x',c='#222222',linewidths=1.2,zorder=7)","now=ax.scatter([],[],s=65,marker='o',c=c,edgecolors='white',linewidths=1.2,zorder=7)")
s=s.replace("trail,=ax.plot([],[],color='#db2c39',lw=1,alpha=.8,zorder=6)","trail,=ax.plot([],[],color='#db2c39',lw=1,ls=':',alpha=.8,zorder=6)")
s=s.replace('Red circle: final-best particle tracked from the start; black x: current best.','Red circle / dotted line: final-best particle; colored marker / solid line: current best.')
(r/'render_five.py').write_text(s,encoding='utf-8')
spec=importlib.util.spec_from_file_location('render_five',r/'render_five.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files={'ULA':common/'ULA_data.npz','PSO':common/'PSO_data.npz','SVGD RBF':common/'SVGD_data.npz','SVGD IMQ':imq/'IMQ_data.npz','CBO':common/'CBO_data.npz'}
data={};init=None
for mode,p in files.items():
 with np.load(p,allow_pickle=False) as z:
  steps=z['steps'];path=z['trial0_path_float64'];initial=z['initial_float64'];states=z['states']
  assert np.array_equal(steps,m.STEPS) and states.shape==(48,61,64,3) and np.isfinite(states).all()
  if init is None:init=initial.copy()
  else:assert np.array_equal(init,initial)
  assert np.allclose(path,states[0],rtol=1e-6,atol=5e-7)
  err=np.max(np.abs(m.wave_loss(path[...,0],path[...,1])-path[...,2]));assert err<1e-9,(mode,err)
  data[mode]={'path':path,'winner':int(np.argmin(path[-1,:,2]))}
  shutil.copy2(p,r/(mode.replace(' ','_')+'_data.npz'))
  print(mode,'verified',flush=True)
m.animate_wave(data)
(r/'wave_ULA_PSO_SVGD_CBO_30000.gif').replace(r/'wave_five_methods_30000.gif')
(r/'README_ja.txt').write_text('''元の波形回帰を5方式で比較。真値sin(3x)、近似a sin(wx)。64粒子、48試行、30,000更新、500更新刻み。ULA、SVGD RBF、CBOは元の保存結果、PSOとSVGD IMQは新規計算。位置更新に明示的な係数eta=0.01を共通に設定。ただしPSOでは速度に係数を掛けるため、更新速度や演算量が等しい意味ではない。PSOは速度更新を元の設定に戻し位置更新を0.01倍にしている。IMQ k=(1+||x-y||²/0.18)^(-1/2)、RBF k=exp(-||x-y||²/0.36)。アニメーションは共通の試行0、赤丸と点線は最終最良の粒子を事後選択して固定追跡、色付き粒子と実線は各時点の最良。1方式につき左が粒子位置、右が波形。最終時点で基準を満たした試行数はULA48、PSO0、SVGD RBF35、SVGD IMQ36、CBO0。元の無制限な波形パラメータ空間ではexp(-L/T)は正規化不能であり、ULA・SVGDは形式的更新の比較。\n''',encoding='utf-8')
(r/'verification.json').write_text(json.dumps({'passed':True,'methods':list(files),'steps':30000,'snapshots':61,'trials':48,'particles':64,'initial_values_identical':True},indent=2),encoding='utf-8')
with zipfile.ZipFile(r/'wave_five_methods_bundle.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.name!='wave_five_methods_bundle.zip':z.write(p,p.name)
with zipfile.ZipFile(r/'wave_five_methods_bundle.zip') as z:assert z.testzip() is None
print('All five methods rendered and ZIP verified',flush=True)
