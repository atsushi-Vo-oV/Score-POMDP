import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from previous import loss_grad
P=Path(__file__).resolve().parent
results=[];arrays={};validation={}
for m in ['svgd','A']:
 d=np.load(P/'runs'/f'pde_{m}_120_wide.npz');meta=json.loads((P/'runs'/f'pde_{m}_120_wide.json').read_text());old=np.load(P/'reference_t60'/f'pde_{m}_120_wide.npz');diff=d['density'][12]-old['density'][-1]; dx_old=float(old['w'][1]-old['w'][0]);l1_error=float(np.abs(diff).sum()*dx_old*dx_old);max_error=float(np.abs(diff).max());assert l1_error<.01
 q=d['density'];w=d['w'];a=d['a'];dx=float(w[1]-w[0]);ww,aa=np.meshgrid(w,a);frac=np.zeros_like(ww);negative=np.zeros_like(ww)
 for i in range(4):
  for j in range(4):
   u=ww+((j+.5)/4-.5)*dx;v=aa+((i+.5)/4-.5)*dx;L,_=loss_grad(np.stack([v,u],-1));frac+=((abs(u-3)<.15)&(L<.01))/16;negative+=((abs(u+3)<.15)&(L<.01))/16
 pos=(q*frac).sum(axis=(1,2))*dx*dx;neg=(q*negative).sum(axis=(1,2))*dx*dx;loss=(q*d['loss']).sum(axis=(1,2))*dx*dx
 for t,pp,nn,ll in zip(d['times'],pos,neg,loss):results.append({'mode':m,'time':float(t),'positive_mass':float(pp),'negative_mass':float(nn),'either_mass':float(pp+nn),'mean_loss':float(ll)})
 arrays[m]={'q':q,'w':w,'a':a,'times':d['times'],'hit':pos+neg,'loss':loss};validation[m]={'time_60_L1_vs_prior_half_timestep':l1_error,'time_60_max_abs_vs_prior':max_error,'mass_error':meta['max_mass_error'],'cfl':meta['max_cfl_bound'],'min_density':meta['minimum_density'],'edge_mass_at_300':meta['records'][-1]['edge_mass'],'edge_mass_max_recorded':max(x['edge_mass'] for x in meta['records'])}
 assert meta['max_mass_error']<1e-8 and meta['minimum_density']>=-1e-12 and meta['max_cfl_bound']<1
pd.DataFrame(results).to_csv(P/'pde_summary_30000.csv',index=False);(P/'pde_validation.json').write_text(json.dumps(validation,indent=2));print('PDE',json.dumps(validation),flush=True)
fig,axes=plt.subplots(2,2,figsize=(12,7.5),dpi=85,layout='constrained');title=fig.suptitle('Mean-field PDE | time 000/300',fontsize=14,fontweight='bold');artists=[];vmax=max(np.quantile(arrays[m]['q'],.998) for m in arrays);ymax=max(1,100*max(arrays[m]['hit'].max() for m in arrays)*1.1)
for row,(m,label) in enumerate([('svgd','Current SVGD'),('A','A: history SVGD')]):
 d=arrays[m];ax=axes[row,0];im=ax.imshow(d['q'][0],origin='lower',extent=[d['w'][0]-.05,d['w'][-1]+.05,d['a'][0]-.05,d['a'][-1]+.05],cmap='magma',vmin=0,vmax=vmax,aspect='auto');ax.scatter([3,-3],[1,-1],marker='*',c='cyan',s=70,edgecolors='white');ax.set(title=label+': density',xlabel='Frequency w',ylabel='Amplitude a',xlim=(-4.5,7.5),ylim=(-6,6));bx=axes[row,1];line,=bx.plot([],[],c='#2563eb');bx.set(xlim=(0,300),ylim=(0,ymax),xlabel='Time',ylabel='Target mass (%)',title=label+': target mass, ± frequencies');bx.grid(alpha=.2);artists.append((im,line))
fig.supxlabel('Wide domain: 120×120; common color scale. Stars denote equivalent target solutions.',fontsize=8);fig.canvas.draw();fig.set_layout_engine('none');frames=[]
for i in range(61):
 title.set_text(f'Mean-field PDE | time {i*5:03d}/300')
 for m,(im,line) in zip(['svgd','A'],artists):
  d=arrays[m];im.set_data(d['q'][i]);line.set_data(d['times'][:i+1],100*d['hit'][:i+1])
 fig.canvas.draw();rgb=Image.fromarray(np.asarray(fig.canvas.buffer_rgba())[:,:,:3].copy());frames.append(rgb.quantize(colors=128,method=Image.Quantize.FASTOCTREE))
frames[0].save(P/'pde_30000.gif',save_all=True,append_images=frames[1:],duration=[1000]+[160]*59+[2000],loop=0,optimize=False);rgb.save(P/'pde_last.png');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4),layout='constrained');df=pd.DataFrame(results)
for m,label,c in [('svgd','SVGD','#2563eb'),('A','A: history SVGD','#dc2626')]:
 z=df[df['mode']==m];ax[0].plot(z.time,z.either_mass*100,label=label,c=c);ax[1].plot(z.time,z.mean_loss,label=label,c=c)
ax[0].set(ylabel='Target mass (%)',xlabel='Time');ax[1].set(ylabel='Mean loss',xlabel='Time');ax[0].legend();[a.grid(alpha=.2) for a in ax];fig.suptitle('Mean-field numerical approximation through t=300',fontweight='bold');fig.savefig(P/'pde_curves.png',dpi=140);plt.close(fig);print('PDE figures complete',flush=True)
