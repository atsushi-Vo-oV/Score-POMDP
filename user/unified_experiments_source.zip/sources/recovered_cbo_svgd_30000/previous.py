import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,json,sys
R=Path(__file__).resolve().parent
T=6000;dt=.01;lam=.02;kappa=.04;eps=.2;tau=.15;K=100;b=16;trials=48;obs=np.linspace(0,2*np.pi,64);target=np.sin(3*obs)
def loss_grad(z):
 a=z[...,0,None];w=z[...,1,None];phase=w*obs;sn=np.sin(phase);cs=np.cos(phase);res=a*sn-target
 return .5*np.mean(res*res,axis=-1), np.stack([np.mean(res*sn,axis=-1),np.mean(res*a*cs*obs,axis=-1)],axis=-1)
def simulate(n,mode,scenario):
 upper=3.5 if scenario=='broad' else 2.1
 random=np.random.default_rng(20271027);state=np.empty((trials,n,2));state[:,:,0]=random.normal(.8,.1,(trials,n));state[:,:,1]=random.uniform(.7,upper,(trials,n));init=state.copy();mean=np.zeros((trials,2));mass=np.zeros(trials);reservoir=np.zeros((trials,K,2));seen=0
 rngs=[np.random.default_rng(42000+i) for i in range(trials)];rngb=[np.random.default_rng(142000+i) for i in range(trials)]
 mask=np.zeros(n,dtype=bool)
 if mode=='all':mask[:]=True
 if mode=='mixed':mask[::2]=True
 keep={0,1,5,10,25,50,100,200,400,600,800,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000};records=[];path=[]
 for step in range(T+1):
  loss,grad=loss_grad(state)
  if step in keep:records.append({'step':step,'loss':loss.tolist(),'state':state.tolist()})
  if step%100==0:path.append(state[0].copy())
  if step==T:break
  w=np.exp(-loss/tau);bm=w.sum(axis=1);new=mass+bm;mean=mean*(mass/new)[:,None]+(w[:,:,None]*state).sum(axis=1)/new[:,None];mass=new
  counts=np.arange(seen+1,seen+n+1);initial=counts<=K
  for s in range(trials):
   indices=np.empty(n,dtype=int);indices[initial]=counts[initial]-1
   if (~initial).any():indices[~initial]=rngs[s].integers(counts[~initial])
   take=indices<K;reservoir[s,indices[take]]=state[s,take]
  seen+=n
  for s in range(trials):
   idx=rngb[s].choice(min(seen,K),size=min(seen,b),replace=False)
   if mask.any():
    diff=state[s,mask,None,:]-reservoir[s,idx][None,:,:];den=(np.mean(diff**2,axis=-1)+eps**2)**1.5;force=kappa*np.mean(diff/den[:,:,None],axis=1);grad[s,mask]-=force
  state-=dt*(grad+lam*(state-mean[:,None,:]))
  if (step+1)%1500==0:print(scenario,n,mode,'step',step+1,flush=True)
 return {'n':n,'mode':mode,'scenario':scenario,'mask':mask.tolist(),'records':records,'path_first':np.asarray(path).tolist(),'initial':init.tolist()}
def task(params):
 n,scenario=params
 for mode in ['none','mixed','all']:
  out=R/'runs'/f'{scenario}_{n}_{mode}.json'
  if out.exists():continue
  print('START',scenario,n,mode,flush=True);res=simulate(n,mode,scenario);tmp=out.with_suffix('.tmp');tmp.write_text(json.dumps(res));tmp.replace(out);print('DONE',scenario,n,mode,flush=True)
 return params
if __name__=='__main__':
 pairs=[(n,s) for n in [64,32,16,8] for s in ['remote','broad']]
 with ProcessPoolExecutor(max_workers=4) as ex:
  f={ex.submit(task,p):p for p in pairs}
  for x in as_completed(f):x.result()
