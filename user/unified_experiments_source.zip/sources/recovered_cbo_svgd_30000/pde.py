import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,json,sys
from scipy.signal import fftconvolve
from scipy.fft import rfftn,irfftn,next_fast_len
from scipy.special import ndtr
from previous import loss_grad
P=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['A','svgd']
n=int(sys.argv[2]) if len(sys.argv)>2 else 90;dt=float(sys.argv[3]) if len(sys.argv)>3 else .002
wide=len(sys.argv)>4 and sys.argv[4]=='wide';lo,hi=(-4.5,7.5) if wide else (-1.5,4.5);alo,ahi=(-6,6) if wide else (-3,3);end=300.;dx=(hi-lo)/n;edges=np.linspace(lo,hi,n+1);w=(edges[:-1]+edges[1:])/2;ae=np.linspace(alo,ahi,n+1);a=(ae[:-1]+ae[1:])/2;ww,aa=np.meshgrid(w,a);L,grad=loss_grad(np.stack([aa,ww],axis=-1))
wa=np.maximum(0,np.minimum(edges[1:],2.1)-np.maximum(edges[:-1],.7))/1.4;am=ndtr((ae[1:]-.8)/.1)-ndtr((ae[:-1]-.8)/.1);q=am[:,None]*wa[None,:]/dx**2;q/=q.sum()*dx**2
h=.3;delta=.1;eps=.2;kappa=1.0;lam=.02;tau=.15
coord=np.arange(-n+1,n)*dx;dw,da=np.meshgrid(coord,coord);r2=(dw**2+da**2)/2;K=np.exp(-r2/(2*h*h));Kfw=dw*K/(2*h*h);Kfa=da*K/(2*h*h);Hfw=dw/(r2+eps**2)**1.5;Hfa=da/(r2+eps**2)**1.5
fftshape=(next_fast_len(3*n-2),next_fast_len(3*n-2));Kh=rfftn(K,fftshape);Kwh=rfftn(Kfw,fftshape);Kah=rfftn(Kfa,fftshape);crop=(slice(n-1,2*n-1),slice(n-1,2*n-1))
def velocity_fast(rho):
 qr=rfftn(rho,fftshape);qw=rfftn(rho*grad[:,:,1],fftshape);qa=rfftn(rho*grad[:,:,0],fftshape)
 return (irfftn(-qw*Kh/tau+qr*Kwh,fftshape)[crop]*dx**2,irfftn(-qa*Kh/tau+qr*Kah,fftshape)[crop]*dx**2)
# Verify the FFT shortcut against direct scipy convolutions on the initial state.
bw_test,ba_test=velocity_fast(q)
np.testing.assert_allclose(bw_test,-fftconvolve(q*grad[:,:,1],K,mode='same')*dx**2/tau+fftconvolve(q,Kfw,mode='same')*dx**2,atol=1e-10)
np.testing.assert_allclose(ba_test,-fftconvolve(q*grad[:,:,0],K,mode='same')*dx**2/tau+fftconvolve(q,Kfa,mode='same')*dx**2,atol=1e-10)
mass=0.;moment=np.zeros(2);hist=np.zeros_like(q);times=[];records=[];frames=[];maxmass=0.;minimum=1.;max_cfl=0.;stepcount=round(end/dt);checkpoint_steps=set(np.rint(np.arange(0,int(end)+1,5)/dt).astype(int));lastgate=None
# Grid density and scalar summaries every 1 unit of time.
for step in range(stepcount+1):
 if step in checkpoint_steps:
  tt=step*dt;mask=(abs(ww-3)<.15)&(L<.01);records.append({'time':tt,'mean_loss':float((q*L).sum()*dx**2),'target_mass':float(q[mask].sum()*dx**2),'mass':float(q.sum()*dx**2),'mean_w':float((q*ww).sum()*dx**2),'mean_a':float((q*aa).sum()*dx**2),'edge_mass':float((q[:3].sum()+q[-3:].sum()+q[3:-3,:3].sum()+q[3:-3,-3:].sum())*dx**2)});frames.append(q.copy());times.append(tt)
 if step==stepcount:break
 if mode=='A':
  hist+=q*dt;rho=hist/((step+1)*dt)
 else:
  rho=q
 bw,ba=velocity_fast(rho)
 vx=(bw[:,1:]+bw[:,:-1])/2;vy=(ba[1:]+ba[:-1])/2;max_cfl=max(max_cfl,float(dt*(np.max(np.abs(vx))+np.max(np.abs(vy)))/dx))
 fx=np.zeros((n,n+1));fy=np.zeros((n+1,n));fx[:,1:-1]=np.where(vx>=0,vx*q[:,:-1],vx*q[:,1:]);fy[1:-1]=np.where(vy>=0,vy*q[:-1],vy*q[1:]);q=q-dt*((fx[:,1:]-fx[:,:-1])+(fy[1:]-fy[:-1]))/dx
 maxmass=max(maxmass,abs(q.sum()*dx**2-1));minimum=min(minimum,float(q.min()))
 if step%5000==0:print(mode,'grid',n,'step',step,'time',round(step*dt,2),flush=True)
assert np.isfinite(q).all() and minimum>=-1e-12 and maxmass<1e-8 and max_cfl<1
out={'mode':mode,'grid':n,'dt':dt,'dx':dx,'domain_w':[lo,hi],'domain_a':[alo,ahi],'kappa':kappa,'h':h,'gate_delta':delta,'temperature_T':0,'records':records,'max_mass_error':float(maxmass),'minimum_density':minimum,'max_cfl_bound':max_cfl}
suffix='_wide' if wide else ''; (P/'runs'/f'pde_{mode}_{n}{suffix}.json').write_text(json.dumps(out));np.savez_compressed(P/'runs'/f'pde_{mode}_{n}{suffix}.npz',times=times,density=frames,w=w,a=a,loss=L);print('DONE',mode,n,'targetmass',records[-1]['target_mass'],'loss',records[-1]['mean_loss'],flush=True)
