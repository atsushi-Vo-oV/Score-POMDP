import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
P=Path(__file__).resolve().parent
modes=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
labels=['No repulsion','CBO','CBO + gradient','SVGD','LeaderSGD (synchronous)','ULA','1: Fixed coefficients','2: Random coefficients','3: 56+8 mixture','4: Density-dependent D','5: Random gradient + 56/8','A: History-averaged SVGD','6: SVGD x8','B: history SVGD x8','6.1: SVGD x32','B.1: history SVGD x32']
obs=np.linspace(0,2*np.pi,64);target=np.sin(3*obs);w=np.linspace(-5.3,9.0,210);a=np.linspace(-5.7,4.5,150);ww,aa=np.meshgrid(w,a);L=.5*np.mean((aa[:,:,None]*np.sin(ww[:,:,None]*obs)-target)**2,axis=2);xgrid=np.linspace(0,2*np.pi,300)
fig=plt.figure(figsize=(28,14),dpi=80,layout='constrained');title=fig.suptitle('64 particles | all methods | update 0000/30000',fontsize=17,fontweight='bold');outer=fig.add_gridspec(4,4);artists=[];paths=[];best={}
for idx,(mode,label) in enumerate(zip(modes,labels)):
 sub=outer[idx//4,idx%4].subgridspec(1,2,wspace=.08);ax=fig.add_subplot(sub[0,0]);wx=fig.add_subplot(sub[0,1]);df=pd.read_csv(P/f'{mode}_path.csv');assert len(df)==61*64;path=df[['a','w','loss']].to_numpy().reshape(61,64,3);particle=int(np.argmin(path[-1,:,2]));paths.append(path);best[mode]=particle
 ax.contourf(ww,aa,L,levels=[0,.01,.03,.08,.15,.22,.24,.26,.32,.5,1,2],cmap='Blues_r',extend='max');ax.scatter([3,-3],[1,-1],marker='*',s=65,c='#facc15',edgecolors='black',linewidths=.5);points=([ax.scatter([],[],s=14,c=c,edgecolors='white',linewidths=.2,label=l) for c,l in [('#e11d48','SVGD' if mode in ('m6','m61') else 'History SVGD'),('#f59e0b','History repulsion'),('#6b7280','No repulsion / noise')]] if mode in ('m6','B','m61','B1') else ax.scatter([],[],s=12,c='#f59e0b',edgecolors='white',linewidths=.2));sel=ax.scatter([np.nan],[np.nan],s=38,c='#2563eb',edgecolors='white',linewidths=.7);trail,=ax.plot([],[],c='#2563eb',lw=1);ax.set(xlim=(-5.3,9.0),ylim=(-5.7,4.5),title=label,xlabel='Frequency w',ylabel='Amplitude a');ax.legend(fontsize=5,loc='upper left') if mode in ('m6','B','m61','B1') else None;ax.tick_params(labelsize=7);ax.title.set_fontsize(9);ax.xaxis.label.set_size(8);ax.yaxis.label.set_size(8)
 wx.plot(xgrid,np.sin(3*xgrid),c='#111827',lw=1.3,label='Target');wave,=wx.plot([],[],c='#2563eb',lw=1.3,label=f'Final-best #{particle}');wx.set(xlim=(0,2*np.pi),ylim=(-1.8,1.8),title=f'Wave | {label}',xlabel='x',ylabel='Prediction');wx.legend(fontsize=6,loc='upper right');wx.grid(alpha=.12);wx.tick_params(labelsize=7);wx.title.set_fontsize(9);wx.xaxis.label.set_size(8);wx.yaxis.label.set_size(8);artists.append((points,sel,trail,wave))
fig.supxlabel('One matched trial. For each method, the particle with minimum final loss is traced from the start.',fontsize=9);fig.canvas.draw();fig.set_layout_engine('none');frames=[]
for t in range(61):
 title.set_text(f'64 particles | all 16 methods | update {t*500}/30000')
 for path,mode,(points,sel,trail,wave) in zip(paths,modes,artists):
  p=path[t];i=best[mode];[point.set_offsets(p[sl,[1,0]]) for point,sl in zip(points,[slice(0,32 if mode in ('m61','B1') else 8),slice(32 if mode in ('m61','B1') else 8,56),slice(56,64)])] if mode in ('m6','B','m61','B1') else points.set_offsets(p[:,[1,0]]);sel.set_offsets(p[i:i+1,[1,0]]);trail.set_data(path[:t+1,i,1],path[:t+1,i,0]);wave.set_data(xgrid,p[i,0]*np.sin(p[i,1]*xgrid))
 fig.canvas.draw();rgb=Image.fromarray(np.asarray(fig.canvas.buffer_rgba())[:,:,:3].copy());frames.append(rgb.quantize(colors=128,method=Image.Quantize.FASTOCTREE))
frames[0].save(P/'all_methods_30000.gif',save_all=True,append_images=frames[1:],duration=[1000]+[160]*59+[2000],loop=0,optimize=False);rgb.save(P/'wide_last.png')
import json
(P/'wide_best_particles.json').write_text(json.dumps(best,indent=2));print('finished',best,flush=True)
