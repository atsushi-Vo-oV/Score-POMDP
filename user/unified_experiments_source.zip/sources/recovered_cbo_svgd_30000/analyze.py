import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd,json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
modes=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1'];rows=[];groups=[];verify={}
snapshot=P/'snapshots';snapshot.mkdir(exist_ok=True)
for m in modes:
 df=pd.read_csv(P/f'{m}.csv');assert len(df)==48*61*64,(m,len(df));assert df.groupby(['trial','step']).size().eq(64).all();assert np.isfinite(df.select_dtypes('number')).all().all()
 old=pd.read_csv(P.parent/'half_svgd_comparison'/f'{m}.csv');u=df[df.step==6000].sort_values(['trial','particle']);v=old[old.step==6000].sort_values(['trial','particle']);np.testing.assert_allclose(u[['a','w','loss']],v[['a','w','loss']],rtol=0,atol=1e-13);verify[m]={'previous_6000_same':True,'max_abs_diff':float(np.max(np.abs(u[['a','w','loss']].to_numpy()-v[['a','w','loss']].to_numpy())))}
 df=df.sort_values(['trial','step','particle']);arr=df[['a','w','loss','D']].to_numpy(dtype=np.float32).reshape(48,61,64,4);np.savez_compressed(snapshot/f'{m}.npz',states=arr,steps=np.arange(0,30001,500),fields=np.array(['a','w','loss','D']))
 for step,g in df.groupby('step'):
  hit=(g.loss<.01)&((abs(g.w-3)<.15)|(abs(g.w+3)<.15));pos=(g.loss<.01)&(abs(g.w-3)<.15);rows.append({'mode':m,'step':int(step),'trial_hits_either_sign':int(hit.groupby(g.trial).any().sum()),'particle_fraction_either_sign':float(hit.mean()),'trial_hits_positive':int(pos.groupby(g.trial).any().sum()),'mean_loss':float(g.loss.mean()),'median_trial_best_loss':float(g.groupby('trial').loss.min().median())})
  if m in ['m6','B','m61','B1']:
   split=32 if m in ['m61','B1'] else 8
   for name,mask in [('svgd',g.particle<split),('history',(g.particle>=split)&(g.particle<56)),('none',g.particle>=56)]:
    sub=g[mask];h=hit[mask];groups.append({'mode':m,'step':int(step),'group':name,'trials_hit':int(h.groupby(sub.trial).any().sum()),'particle_fraction':float(h.mean()),'mean_loss':float(sub.loss.mean())})
pd.DataFrame(rows).to_csv(P/'summary_30000.csv',index=False);pd.DataFrame(groups).to_csv(P/'groups_30000.csv',index=False);(P/'validation.json').write_text(json.dumps(verify,indent=2));print('summaries and 6000-step validation complete',flush=True)
df=pd.DataFrame(rows);fig,axes=plt.subplots(2,2,figsize=(13,8),sharex=True,layout='constrained');colors=plt.get_cmap('tab10');panels=[(['control','cbo','gcbo','svgd','leader','ula'],(0,0)),(['m1','m2','m3','m4','m5'],(0,1)),(['A','m6','B','m61','B1'],(1,0))];labels={'control':'No repulsion','cbo':'CBO','gcbo':'CBO+gradient','svgd':'SVGD','leader':'LeaderSGD','ula':'ULA','m1':'1: fixed','m2':'2: random','m3':'3: 56+8','m4':'4: density D','m5':'5: gradient random','A':'A: history SVGD','m6':'6: SVGD x8','B':'B: history SVGD x8','m61':'6.1: SVGD x32','B1':'B.1: history SVGD x32'}
for ms,(i,j) in panels:
 ax=axes[i,j]
 for k,m in enumerate(ms):
  d=df[df['mode']==m];ax.plot(d.step,100*d.particle_fraction_either_sign,label=labels[m],c=colors(k))
 ax.legend(fontsize=7);ax.set(ylabel='Target particles (%)');ax.grid(alpha=.2)
ax=axes[1,1]
for k,m in enumerate(['m5','m6','B','m61','B1','svgd']):
 d=df[df['mode']==m];ax.plot(d.step,d.mean_loss,label=labels[m],c=colors(k))
ax.set(ylabel='Mean loss');ax.legend(fontsize=7);ax.grid(alpha=.2)
for a in axes[1]:a.set_xlabel('Update')
fig.suptitle('64 particles × 48 matched trials, up to 30,000 updates',fontweight='bold');fig.savefig(P/'curves_30000.png',dpi=140);plt.close(fig)
