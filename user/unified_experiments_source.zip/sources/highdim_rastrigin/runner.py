"""Run independent, resumable benchmark trials and publish incremental summaries."""
import concurrent.futures, csv, json, os, pathlib, subprocess, sys, time, uuid
from datetime import datetime
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = pathlib.Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
MODES = ['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
COLORS = ['#3d3d3d','#da2c38','#f38336','#3a5cc9','#008d86','#ab59b2','#858000','#1f8b4c','#5696ac','#974242','#d354a6','#574a86','#ed91a7','#93765d','#599c37','#169ba8']
DIMS=(20,100); STEPS=30000; TRIALS=48; INTERVAL=500; WORKERS=4
NOW=lambda:datetime.now().astimezone().isoformat(timespec='seconds')
def atomic_json(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(tmp,path)
def trialdir(d,mode,tr): return RUNS / f'd{d}' / mode / f'trial{tr:02d}'
def completed(d,mode,tr):
    p=trialdir(d,mode,tr)
    if not p.exists():return None
    found=sorted(p.glob(f'*/{mode}_d{d}_trial{tr}.done'))
    return found[-1].parent if found else None
def run_one(job):
    d,mode,tr=job
    if completed(*job):return (job,'existing',None)
    attempt=trialdir(*job)/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    with (attempt/'execution.log').open('w',encoding='utf-8') as log:
        try:
            p=subprocess.run([str(ROOT/'run.exe'),mode,str(d),str(STEPS),str(tr),str(INTERVAL),str(attempt)],stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            return (job,'complete' if p.returncode==0 and completed(*job) else 'failed',p.returncode)
        except Exception as exc:
            log.write(repr(exc));return (job,'failed',str(exc))
def rows(path):
    with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def font(size):
    try:return ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
    except OSError:return ImageFont.load_default()
def aggregate():
    records=[]; groups={}
    for d in DIMS:
        for mode in MODES:
            results=[]
            for tr in range(TRIALS):
                p=completed(d,mode,tr)
                if p:
                    rr=rows(p/f'{mode}_d{d}_trial{tr}.csv')
                    if len(rr)==STEPS//INTERVAL+1:results.append(rr)
            if not results:continue
            data=[]
            for j in range(len(results[0])):
                batch=[r[j] for r in results]
                current=np.array([float(r['best_loss']) for r in batch]);ever=np.array([float(r['best_so_far']) for r in batch])
                row={'dimension':d,'mode':mode,'step':int(batch[0]['step']),'trials':len(batch),'median_current_best':float(np.median(current)), 'q25_current_best':float(np.quantile(current,.25)),'q75_current_best':float(np.quantile(current,.75)), 'median_best_so_far':float(np.median(ever)), 'q25_best_so_far':float(np.quantile(ever,.25)), 'q75_best_so_far':float(np.quantile(ever,.75)), 'success_trials':sum(int(r['success']) for r in batch), 'median_mean_loss':float(np.median([float(r['mean_loss']) for r in batch])), 'median_kernel':float(np.median([float(r['mean_offdiag_kernel']) for r in batch]))}
                records.append(row);data.append(row)
            groups[(d,mode)]=data
    if not records:return
    tmp=ROOT/'summary.partial.csv.tmp'
    with tmp.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    os.replace(tmp,ROOT/'summary.partial.csv')
    for d in DIMS:
        active=[(m,groups[(d,m)]) for m in MODES if (d,m) in groups]
        if not active:continue
        im=Image.new('RGB',(1500,850),'white');draw=ImageDraw.Draw(im);large=font(25);regular=font(17);small=font(14)
        draw.text((45,20),f'Rotated Rastrigin | d={d} | median best-so-far by recorded step',font=large,fill='black')
        label='Final results: 48 completed trials per method.' if len(active)==len(MODES) and all(data[0]['trials']==TRIALS for _,data in active) else 'Partial results: each curve uses the completed trials shown in the legend.'
        draw.text((45,55),label,font=regular,fill='#444444')
        x0,y0,x1,y1=90,110,1120,720
        vals=[max(1e-12,r['median_best_so_far']) for _,data in active for r in data]
        low=math_floor_log(min(vals));high=math_ceil_log(max(vals));high=max(high,low+1)
        for k in range(low,high+1):
            y=y1-(k-low)/(high-low)*(y1-y0);draw.line((x0,y,x1,y),fill='#dddddd');draw.text((15,y-9),f'1e{k}',font=small,fill='#333333')
        draw.line((x0,y0,x0,y1,x1,y1),fill='black',width=2)
        for step in (0,5000,10000,15000,20000,25000,30000):
            x=x0+(x1-x0)*step/STEPS;draw.text((x-17,y1+10),str(step),font=small,fill='#333333')
        for mode,data in active:
            color=COLORS[MODES.index(mode)];coords=[]
            for r in data:
                x=x0+(x1-x0)*r['step']/STEPS;y=y1-(np.log10(max(1e-12,r['median_best_so_far']))-low)/(high-low)*(y1-y0);coords.append((x,y))
            if len(coords)>1:draw.line(coords,fill=color,width=3)
            idx=MODES.index(mode); yy=113+idx*34;draw.line((1150,yy+9,1180,yy+9),fill=color,width=4);draw.text((1190,yy),f'{mode}: n={data[0]["trials"]}',font=regular,fill='black')
        draw.text((440,785),'Update step (recorded every 500)',font=regular,fill='black')
        tmp=ROOT/f'curves_d{d}.tmp.png';im.save(tmp);os.replace(tmp,ROOT/f'curves_d{d}.png')
        # Animation shows the same trial 0 in all modes, with axes fixed across time and modes.
        if not (ROOT/f'particles_d{d}.gif').exists() and all(completed(d,m,0) for m in MODES):make_gif(d)
def math_floor_log(v):return int(np.floor(np.log10(v)))
def math_ceil_log(v):return int(np.ceil(np.log10(v)))
def make_gif(d):
    entries={}
    bound=5.12
    for mode in MODES:
        p=completed(d,mode,0); table=rows(p/f'{mode}_d{d}_trial0_particles.csv');series={}
        for r in table:
            step=int(r['step']);series.setdefault(step,[]).append((float(r['x_projection_1']),float(r['x_projection_2']),float(r['loss'])))
            bound=max(bound,abs(float(r['x_projection_1'])),abs(float(r['x_projection_2'])))
        entries[mode]=series
    bound*=1.03; frames=[]; ft=font(15);header=font(20)
    for step in range(0,STEPS+1,INTERVAL):
        im=Image.new('RGB',(1120,1040),'white');dr=ImageDraw.Draw(im);dr.text((15,8),f'd={d}, trial 0, step {step}; fixed x1/x2 projection; red = current best',font=header,fill='black')
        for idx,mode in enumerate(MODES):
            row,col=divmod(idx,4); left=col*280;top=40+row*250;cx=left+140;cy=top+130;half=95
            dr.rectangle((cx-half,cy-half,cx+half,cy+half),outline='#cccccc');dr.line((cx-half,cy,cx+half,cy),fill='#eeeeee');dr.line((cx,cy-half,cx,cy+half),fill='#eeeeee')
            pts=entries[mode][step];winner=min(range(len(pts)),key=lambda i:pts[i][2])
            dr.text((left+7,top+4),f'{mode}  best={pts[winner][2]:.3g}',font=ft,fill='black')
            for i,(x,y,loss) in enumerate(pts):
                px=cx+half*x/bound;py=cy-half*y/bound;r=4 if i==winner else 2;dr.ellipse((px-r,py-r,px+r,py+r),fill='#df2233' if i==winner else '#3263ad')
        frames.append(im.convert('P',palette=Image.Palette.ADAPTIVE,colors=64))
    tmp=ROOT/f'particles_d{d}.tmp.gif';frames[0].save(tmp,save_all=True,append_images=frames[1:],duration=120,loop=0,optimize=False);os.replace(tmp,ROOT/f'particles_d{d}.gif')
def main():
    RUNS.mkdir(exist_ok=True)
    jobs=[(d,mode,tr) for tr in range(TRIALS) for d in DIMS for mode in MODES]
    pending=[job for job in jobs if not completed(*job)]
    state={'started':NOW(),'updated':NOW(),'state':'running','workers':WORKERS,'total':len(jobs),'completed':len(jobs)-len(pending),'failed':0,'last':None}
    atomic_json(ROOT/'status.json',state)
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures={}
        def refill():
            while len(futures)<WORKERS and pending and not (ROOT/'stop.flag').exists():
                job=pending.pop(0);futures[pool.submit(run_one,job)]=job
        refill()
        while futures:
            done,_=concurrent.futures.wait(futures,return_when=concurrent.futures.FIRST_COMPLETED)
            for fut in done:
                job,what,code=fut.result();del futures[fut]
                state['last']={'dimension':job[0],'mode':job[1],'trial':job[2],'result':what,'exit_code':code}
                state['completed']+=what in ('complete','existing');state['failed']+=what=='failed';state['updated']=NOW();atomic_json(ROOT/'status.json',state)
                if state['completed']<=32 or state['completed']%16==0:
                    try:aggregate()
                    except Exception as exc:(ROOT/'analysis_errors.log').open('a',encoding='utf-8').write(f'{NOW()} {exc!r}\n')
            refill()
    try:aggregate()
    except Exception as exc:(ROOT/'analysis_errors.log').open('a',encoding='utf-8').write(f'{NOW()} {exc!r}\n')
    state['state']='stopped' if (ROOT/'stop.flag').exists() else ('complete' if state['failed']==0 else 'finished_with_errors');state['updated']=NOW();atomic_json(ROOT/'status.json',state)
if __name__=='__main__':main()
