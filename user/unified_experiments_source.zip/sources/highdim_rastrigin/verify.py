import csv, math, pathlib, subprocess, sys, tempfile
import numpy as np

root = pathlib.Path(__file__).resolve().parent
exe = root / 'run.exe'
modes = ['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']

# The independently calculated analytic gradient must agree with finite differences.
rng=np.random.default_rng(71)
for d in (20,100):
    z=rng.normal(size=d)
    loss=lambda v: np.mean(v*v+10*(1-np.cos(2*np.pi*v)))
    grad=(2*z+20*np.pi*np.sin(2*np.pi*z))/d
    for k in (0,d//2,d-1):
        plus=z.copy();minus=z.copy();plus[k]+=1e-6;minus[k]-=1e-6
        assert abs((loss(plus)-loss(minus))/2e-6-grad[k])<1e-7
with tempfile.TemporaryDirectory(prefix='rastrigin_test_',dir=str(root.parent.parent/'work')) as temp:
    for d in (20,100):
        starts=[]
        for mode in modes:
            subprocess.run([str(exe),mode,str(d),'50','0','10',temp],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            path=pathlib.Path(temp)/f'{mode}_d{d}_trial0.csv'
            with path.open(newline='') as f: rows=list(csv.DictReader(f))
            assert len(rows)==6 and [int(r['step']) for r in rows]==list(range(0,51,10))
            assert all(math.isfinite(float(r[k])) for r in rows for k in ('best_loss','best_so_far','mean_loss','median_loss','mean_radius'))
            assert all(float(rows[i]['best_so_far'])>=float(rows[i+1]['best_so_far']) for i in range(5))
            starts.append(float(rows[0]['best_loss']))
            with (pathlib.Path(temp)/f'{mode}_d{d}_trial0_particles.csv').open(newline='') as f: assert sum(1 for _ in csv.DictReader(f))==6*64
            assert path.with_suffix('.done').exists()
        assert max(starts)-min(starts)<1e-12
print('PASS: finite-difference gradient; all 16 modes, both dimensions, common initialization, finite values, monotone best-so-far, record counts')
