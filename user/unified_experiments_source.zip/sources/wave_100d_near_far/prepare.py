from pathlib import Path
import json
import numpy as np

ROOT=Path(__file__).resolve().parent
rng=np.random.default_rng(20261106)
initial=np.concatenate((rng.uniform(0,.3,(64,50)),np.arange(1,51)+rng.normal(0,.2,(64,50))),axis=1)
far=initial.copy(); far[:,50:]+=60
for name,q in [('near',initial),('far',far)]:
    np.savetxt(ROOT/(name+'_initial.txt'),q,fmt='%.17g')
np.savez_compressed(ROOT/'initial.npz',near=initial,far=far)
config=dict(dimensions=100,components=50,particles=64,steps=30000,snapshot_interval=500,trials_per_condition=1,eta=.01,temperature=.15,training_points=256,domain=[0,2*np.pi],target_amplitudes='0.7/k, k=1,...,50',target_frequencies='k, k=1,...,50',initial_amplitudes='Uniform(0,0.3)',near_frequencies='k+Normal(0,0.2)',far_frequencies='near+60',initial_seed=20261106,method_seeds=dict(ULA=8000,PSO=8001,RBF=8002,IMQ=8003,CBO=8004),rbf_kernel='exp(-squared_distance/0.36)',imq_kernel='(1+squared_distance/0.18)^(-1/2)',ula_diffusion=.005,cbo_attraction=.02,cbo_noise=.1,pso_phi=4.1,pso_chi='2/(4.1-2+sqrt(4.1^2-4*4.1))',parameter_stop_limit=1e6)
(ROOT/'config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
