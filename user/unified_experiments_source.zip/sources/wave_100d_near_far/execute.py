from pathlib import Path
import subprocess
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
def run(job):
    scenario,method=job
    tag=scenario+'_'+method
    if (ROOT/(tag+'.done.json')).exists():
        print(tag+' already complete',flush=True);return
    print('Starting '+tag,flush=True)
    with (ROOT/(tag+'.log')).open('w') as f:
        result=subprocess.run([str(ROOT/'run.exe'),str(ROOT),scenario,method,'30000'],stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    if result.returncode: raise RuntimeError(tag+' failed; see log')
    print(tag+' '+(ROOT/(tag+'.done.json')).read_text().strip(),flush=True)
if __name__=='__main__':
    jobs=[(s,m) for m in ['ULA','PSO','RBF','IMQ','CBO'] for s in ['near','far']]
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(run,jobs))
