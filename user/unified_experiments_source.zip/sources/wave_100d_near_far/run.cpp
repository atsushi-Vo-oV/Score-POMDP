#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <string>
#include <vector>
using namespace std;
constexpr int K=50,D=100,N=64,M=256,P=56,GAP=500;
constexpr double ETA=.01,TAU=.15,LIMIT=1e6;
const double PI=acos(-1.0);
inline double sq(double x){return x*x;}
using V=array<double,D>;
using Population=array<V,N>;
array<double,M> target,grid;
void setup(){for(int j=0;j<M;j++){grid[j]=2*PI*j/(M-1);for(int k=0;k<K;k++)target[j]+=.7/(k+1)*sin((k+1)*grid[j]);}}
// Trigonometric recurrence on the uniform training grid. Padding allows SIMD
// across frequencies. The objective is identical to direct sine evaluation.
double evaluate(const V& q,V& g,bool gradient){
 alignas(32) double sb[M][P],cb[M][P],s[P]{},c[P]{},sd[P]{},cd[P]{},a[P]{},res[M],ga[P]{},gw[P]{};
 for(int k=0;k<P;k++){c[k]=1;if(k<K){sd[k]=sin(q[K+k]*2*PI/(M-1));cd[k]=cos(q[K+k]*2*PI/(M-1));a[k]=q[k];}else cd[k]=1;}
 double loss=0;
 for(int j=0;j<M;j++){
  double prediction=0;
  for(int k=0;k<P;k++){sb[j][k]=s[k];cb[j][k]=c[k];prediction+=a[k]*s[k];}
  res[j]=prediction-target[j];loss+=res[j]*res[j];
  for(int k=0;k<P;k++){double next=s[k]*cd[k]+c[k]*sd[k];c[k]=c[k]*cd[k]-s[k]*sd[k];s[k]=next;}
 }
 if(gradient){
  for(int j=0;j<M;j++)for(int k=0;k<P;k++){ga[k]+=res[j]*sb[j][k];gw[k]+=res[j]*grid[j]*cb[j][k];}
  for(int k=0;k<K;k++){g[k]=ga[k]/M;g[K+k]=gw[k]*a[k]/M;}
 }
 return loss/(2*M);
}
double direct(const V&q){double loss=0;for(int j=0;j<M;j++){double y=0;for(int k=0;k<K;k++)y+=q[k]*sin(q[K+k]*grid[j]);loss+=(y-target[j])*(y-target[j]);}return loss/(2*M);}
int main(int argc,char**argv){try{
 setup();
 if(argc==2&&string(argv[1])=="--selftest"){
  mt19937_64 gen(20261106);uniform_real_distribution<double>u(-1,1);double le=0,ge=0;
  for(int test=0;test<8;test++){V q{},g{};for(int k=0;k<K;k++){q[k]=test==0?.7/(k+1):.3*u(gen);q[K+k]=test==0?k+1:k+1+(test%2?60:0)+.2*u(gen);}double l=evaluate(q,g,true);le=max(le,abs(l-direct(q)));
   for(int d=0;d<D;d++){double h=1e-5;V plus=q,minus=q;plus[d]+=h;minus[d]-=h;double numerical=(direct(plus)-direct(minus))/(2*h);ge=max(ge,abs(numerical-g[d]));}
  }
  cout<<setprecision(17)<<"loss_max_abs_error="<<le<<" gradient_max_abs_error="<<ge<<endl;
  return le<1e-10&&ge<1e-7?0:3;
 }
 if(argc<4)throw runtime_error("usage: run.exe OUTPUT_DIR near|far METHOD [steps]");
 filesystem::path root=argv[1];string scenario=argv[2],method=argv[3];int T=argc>4?stoi(argv[4]):30000;
 if(T<1||T%GAP)throw runtime_error("steps must be positive multiple of 500");
 Population q{},g{},velocity{},personal{};array<double,N>loss{},personal_loss{};personal_loss.fill(INFINITY);
 ifstream initial(root/(scenario+"_initial.txt"));for(auto&p:q)for(double&v:p)initial>>v;if(!initial)throw runtime_error("missing initial data");personal=q;
 string tag=scenario+"_"+method;
 if(filesystem::exists(root/(tag+".done.json")))throw runtime_error("existing completed run; refusing overwrite");
 ofstream states(root/(tag+".f64"),ios::binary),metrics(root/(tag+"_metrics.csv"));metrics<<"step,current_best,mean_loss,max_abs_parameter,mean_offdiag_kernel,mean_radius\n"<<setprecision(17);
 mt19937_64 rng(method=="ULA"?8000:method=="PSO"?8001:method=="RBF"?8002:method=="IMQ"?8003:8004);normal_distribution<double>normal(0,1);uniform_real_distribution<double>uniform(0,1);
 auto start=chrono::steady_clock::now();int last=0,frames=0;string status="completed";bool need_grad=method=="ULA"||method=="RBF"||method=="IMQ";
 for(int step=0;step<=T;step++){
  double magnitude=0;for(auto&p:q)for(double v:p)magnitude=max(magnitude,abs(v));
  if(!isfinite(magnitude)||magnitude>LIMIT){status="stopped_parameter_limit";last=step;break;}
  for(int i=0;i<N;i++){loss[i]=evaluate(q[i],g[i],need_grad);if(!isfinite(loss[i]))throw runtime_error("nonfinite loss");}
  if(step%GAP==0){
   double mean=0,radius=0,kernel=0;V center{};for(int i=0;i<N;i++){mean+=loss[i]/N;for(int d=0;d<D;d++)center[d]+=q[i][d]/N;states.write(reinterpret_cast<char*>(q[i].data()),D*sizeof(double));states.write(reinterpret_cast<char*>(&loss[i]),sizeof(double));}
   for(int i=0;i<N;i++){double r2=0;for(int d=0;d<D;d++)r2+=sq(q[i][d]-center[d]);radius+=sqrt(r2)/N;}
   if(method=="RBF"||method=="IMQ"){for(int i=0;i<N;i++)for(int j=0;j<N;j++)if(i!=j){double r2=0;for(int d=0;d<D;d++)r2+=sq(q[i][d]-q[j][d]);kernel+=method=="RBF"?exp(-r2/.36):1/sqrt(1+r2/.18);}kernel/=N*(N-1);}
   metrics<<step<<','<<*min_element(loss.begin(),loss.end())<<','<<mean<<','<<magnitude<<','<<kernel<<','<<radius<<'\n';frames++;states.flush();metrics.flush();
  }
  last=step;if(step==T)break;
  if(method=="ULA")for(int i=0;i<N;i++)for(int d=0;d<D;d++)q[i][d]+=-ETA*g[i][d]+sqrt(2*.005*ETA)*normal(rng);
  else if(method=="PSO"){
   for(int i=0;i<N;i++)if(loss[i]<personal_loss[i]){personal_loss[i]=loss[i];personal[i]=q[i];}
   V best=personal[min_element(personal_loss.begin(),personal_loss.end())-personal_loss.begin()];double chi=2/(4.1-2+sqrt(4.1*4.1-4*4.1));
   for(int i=0;i<N;i++)for(int d=0;d<D;d++){velocity[i][d]=chi*(velocity[i][d]+2.05*uniform(rng)*(personal[i][d]-q[i][d])+2.05*uniform(rng)*(best[d]-q[i][d]));q[i][d]+=ETA*velocity[i][d];}
  }else if(method=="RBF"||method=="IMQ"){
   Population drift{};
   for(int i=0;i<N;i++)for(int j=0;j<N;j++){double r2=0;for(int d=0;d<D;d++)r2+=sq(q[i][d]-q[j][d]);double u=1+r2/.18,weight=method=="RBF"?exp(-r2/.36):1/sqrt(u),rep=method=="RBF"?weight/.18:weight/(.18*u);
    for(int d=0;d<D;d++)drift[i][d]+=(-weight*g[j][d]/TAU+rep*(q[i][d]-q[j][d]))/N;
   }
   for(int i=0;i<N;i++)for(int d=0;d<D;d++)q[i][d]+=ETA*drift[i][d];
  }else if(method=="CBO"){
   V center{};double total=0,minimum=*min_element(loss.begin(),loss.end());for(int i=0;i<N;i++){double w=exp(-(loss[i]-minimum)/TAU);total+=w;for(int d=0;d<D;d++)center[d]+=w*q[i][d];}for(double&v:center)v/=total;
   for(int i=0;i<N;i++){double r2=0;for(int d=0;d<D;d++)r2+=sq(q[i][d]-center[d]);double noise=.1*sqrt(ETA*r2);for(int d=0;d<D;d++)q[i][d]+=ETA*.02*(center[d]-q[i][d])+noise*normal(rng);}
  }else throw runtime_error("unknown method");
  if((step+1)%5000==0)cout<<tag<<" "<<step+1<<"/"<<T<<endl;
 }
 states.close();metrics.close();if(!states||!metrics)throw runtime_error("failed writing output");
 ofstream done(root/(tag+".done.json"));done<<setprecision(17)<<"{\"status\":\""<<status<<"\",\"last_step\":"<<last<<",\"frames\":"<<frames<<",\"parameter_limit\":"<<LIMIT<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";
 cout<<tag<<" "<<status<<" at "<<last<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 return 0;
}catch(const exception&e){cerr<<e.what()<<endl;return 2;}}
