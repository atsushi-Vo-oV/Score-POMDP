import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import sys,json,zipfile,csv
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'work'/'plotting_packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

METHODS=['ULA','PSO','RBF','IMQ','CBO']
LABELS=['ULA','PSO','SVGD RBF','SVGD IMQ','CBO']
COLORS=['#1f77b4','#ff7f0e','#2ca02c','#9467bd','#d62728']
SCENARIOS=['near','far']
TRAIN_X=np.linspace(0,2*np.pi,256)
VIEW_X=np.linspace(0,2*np.pi,2049)
# Held-out grid is interleaved, has no training endpoints, and is not used for optimization.
TEST_X=2*np.pi*(np.arange(2048)+.5)/2048
FREQ=np.arange(1,51); AMPS=.7/FREQ
def wave(q,x): return np.sin(x[:,None]*q[50:])@q[:50]
def target(x): return np.sin(x[:,None]*FREQ)@AMPS

def collect():
    info={}; report=[]; max_loss_error=0.; initial=np.load(ROOT/'initial.npz'); payload={}
    for s in SCENARIOS:
        for m in METHODS:
            tag=s+'_'+m; status=json.loads((ROOT/(tag+'.done.json')).read_text())
            raw=np.fromfile(ROOT/(tag+'.f64'),dtype=np.float64).reshape(status['frames'],64,101)
            metrics=np.genfromtxt(ROOT/(tag+'_metrics.csv'),delimiter=',',names=True)
            assert len(raw)==len(metrics) and np.all(np.isfinite(raw))
            assert np.array_equal(raw[0,:,:100],initial[s])
            assert status['status']!='completed' or (status['last_step']==30000 and len(raw)==61)
            # Independent direct trigonometric loss check, including saved high-amplitude states.
            err=0.; rel=0.
            for f in {0,len(raw)//2,len(raw)-1}:
                for i in [0,int(np.argmin(raw[f,:,-1])),63]:
                    expected=np.mean((wave(raw[f,i,:100],TRAIN_X)-target(TRAIN_X))**2)/2
                    err=max(err,abs(expected-raw[f,i,-1]));rel=max(rel,abs(expected-raw[f,i,-1])/max(1.,abs(expected)))
            assert rel<1e-6,(tag,err,rel)
            max_loss_error=max(max_loss_error,rel)
            info[tag]=dict(raw=raw,status=status,metrics=metrics)
            payload[tag]=raw
            best=int(np.argmin(raw[-1,:,-1]));q=raw[-1,best,:100]
            completed=status['status']=='completed'
            row=dict(condition=s,method=m,status=status['status'],stop_or_final_step=status['last_step'],last_saved_step=int(metrics['step'][-1]),initial_best_train_half_mse=float(raw[0,:,-1].min()),final_train_half_mse=float(raw[-1,best,-1]) if completed else None,final_test_half_mse=float(np.mean((wave(q,TEST_X)-target(TEST_X))**2)/2) if completed else None,last_saved_best_half_mse=float(raw[-1,best,-1]),initial_mean_offdiag_kernel=float(metrics['mean_offdiag_kernel'][0]) if m in ['RBF','IMQ'] else None,max_relative_loss_check_error=rel)
            report.append(row)
    # A translation preserves inter-particle distances; both scenarios use the same random streams.
    assert np.max(abs(initial['far'][:,:50]-initial['near'][:,:50]))==0
    assert np.allclose(initial['far'][:,50:]-initial['near'][:,50:],60)
    np.savez_compressed(ROOT/'results.npz',**payload,train_x=TRAIN_X,test_x=TEST_X,target_amps=AMPS,target_freq=FREQ)
    (ROOT/'summary.json').write_text(json.dumps(report,indent=2))
    with (ROOT/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(report[0]));writer.writeheader();writer.writerows(report)
    (ROOT/'verification.json').write_text(json.dumps(dict(initials_identical_across_methods=True,paired_frequency_shift=60,max_relative_saved_loss_error=max_loss_error,all_completed_methods_have_61_frames=True),indent=2))
    return info

def render(info):
    fig,axes=plt.subplots(6,2,figsize=(14,19),layout='constrained')
    curves={}; paths={}; limits=[]
    for col,s in enumerate(SCENARIOS):
        for row,m in enumerate(METHODS):
            tag=s+'_'+m; record=info[tag]; raw=record['raw']; fcount=len(raw)
            current=[]; tracked=[]; chosen=np.argmin(raw[-1,:,-1]) if record['status']['status']=='completed' else None
            for f in range(fcount):
                q=raw[f,np.argmin(raw[f,:,-1]),:100]
                current.append(wave(q,VIEW_X) if np.max(abs(q[50:]))<512 else None)
                tracked.append(wave(raw[f,chosen,:100],VIEW_X) if chosen is not None else None)
                if m!='CBO' and current[-1] is not None:limits.append(float(np.max(abs(current[-1]))))
            paths[tag]=(current,tracked)
            ax=axes[row,col]
            ax.plot(VIEW_X,target(VIEW_X),color='black',lw=1.4,label='Target')
            line,=ax.plot([],[],color=COLORS[row],lw=1.4,label='Current best')
            dotted,=ax.plot([],[],color='#777777',ls=':',lw=1.6,label='Final-best particle')
            label=ax.text(.015,.035,'',transform=ax.transAxes,fontsize=8,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
            ax.set_title(LABELS[row]+' | '+('Near initialization' if s=='near' else 'Far initialization (+60)'),fontsize=11,fontweight='bold')
            ax.set_xlim(0,2*np.pi);ax.set_xlabel('x',fontsize=9);ax.set_ylabel('y',fontsize=9);ax.grid(alpha=.2);ax.tick_params(labelsize=8)
            if row==0:ax.legend(loc='upper right',fontsize=7)
            curves[tag]=(line,dotted,label)
        ax=axes[5,col]
        ax.set_title('Current best training loss',fontsize=11,fontweight='bold');ax.set_xlabel('Step');ax.set_ylabel('Half MSE (log scale)');ax.set_yscale('log');ax.set_xlim(0,30000);ax.grid(alpha=.2)
        lower=min(float(info[s+'_'+m]['raw'][:,:,-1].min()) for m in METHODS)
        upper=max(float(info[s+'_'+m]['raw'][:,:,-1].min(axis=1).max()) for m in METHODS)
        ax.set_ylim(max(lower*.5,1e-8),upper*2)
        for i,m in enumerate(METHODS):
            line,=ax.plot([],[],color=COLORS[i],label=LABELS[i],lw=1.5);curves[s+'_'+m+'_loss']=line
        ax.legend(fontsize=7,ncol=3)
    limit=max(1.5,min(max(limits)*1.05,6.))
    for row in range(5):
        for col in range(2):axes[row,col].set_ylim(-limit,limit)
    images=[]
    for f in range(61):
        visible=[]
        for s in SCENARIOS:
            for m in METHODS[:-1]:
                current,tracked=paths[s+'_'+m]
                if f<len(current):
                    visible.extend(float(np.max(abs(y))) for y in [current[f],tracked[f]] if y is not None)
        limit=max(1.5,max(visible)*1.05)
        for row in range(5):
            for col in range(2):axes[row,col].set_ylim(-limit,limit)
        for s in SCENARIOS:
            for m in METHODS:
                tag=s+'_'+m;raw=info[tag]['raw'];status=info[tag]['status'];line,dotted,label=curves[tag]
                if f<len(raw):
                    current,tracked=paths[tag]; y=current[f]; z=tracked[f]
                    if y is not None and np.max(abs(y))<=limit:
                        line.set_data(VIEW_X,y);note=''
                    else:
                        line.set_data([],[]);note=' | Wave exceeds display range'
                    dotted.set_data(VIEW_X,z) if z is not None else dotted.set_data([],[])
                    label.set_text(f'Best loss: {raw[f,:,-1].min():.4g}'+note)
                else:
                    line.set_data([],[]);dotted.set_data([],[])
                    label.set_text(f'Stopped at step {status["last_step"]:,}: |parameter| > 1e6')
                n=min(f+1,len(raw));curves[tag+'_loss'].set_data(np.arange(n)*500,raw[:n,:,-1].min(axis=1))
        fig.suptitle(f'100D wave fitting: 50 amplitudes + 50 frequencies | Step {f*500:,} / 30,000\n64 particles | Common eta = 0.01 | One paired trial',fontsize=14,fontweight='bold')
        fig.canvas.draw();im=Image.fromarray(np.asarray(fig.canvas.buffer_rgba()).copy()).convert('P',palette=Image.Palette.ADAPTIVE,colors=128);images.append(im)
        if f in [0,2,60]:fig.savefig(ROOT/f'frame_{f*500:05d}.png',dpi=110)
    images[0].save(ROOT/'wave_100d_near_far.gif',save_all=True,append_images=images[1:],duration=180,loop=0,optimize=False)
    plt.close(fig)
    with Image.open(ROOT/'wave_100d_near_far.gif') as im: assert im.n_frames==61

def package():
    files=['run.cpp','build.cmd','prepare.py','execute.py','report.py','README_ja.txt','config.json','initial.npz','near_initial.txt','far_initial.txt','results.npz','summary.json','summary.csv','verification.json','implementation_validation.json','wave_100d_near_far.gif','frame_00000.png','frame_01000.png','frame_30000.png']
    files += [p.name for p in ROOT.glob('*.done.json')]+[p.name for p in ROOT.glob('*_metrics.csv')]
    with zipfile.ZipFile(ROOT/'wave_100d_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in files:z.write(ROOT/name,name)
    with zipfile.ZipFile(ROOT/'wave_100d_bundle.zip') as z:assert z.testzip() is None

if __name__=='__main__':
    info=collect();render(info);package();print('Report, animation, verification, and ZIP complete.',flush=True)
