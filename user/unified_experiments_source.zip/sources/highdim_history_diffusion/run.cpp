#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numeric>
#include <random>
#include <string>
#include <vector>
using namespace std;
namespace fs = std::filesystem;
constexpr int N=64, K=100, S=16;
constexpr double ETA=.01, TAU=.15, EPS=.2, PI=3.14159265358979323846;
using Vec=vector<double>;
double sqdist(const Vec& a,const Vec& b){double v=0;for(size_t k=0;k<a.size();++k){double q=a[k]-b[k];v+=q*q;}return v;}
pair<double,Vec> evaluate(const Vec& z){double loss=0;Vec g(z.size());for(size_t k=0;k<z.size();++k){double t=z[k];loss+=t*t+10*(1-cos(2*PI*t));g[k]=(2*t+20*PI*sin(2*PI*t))/z.size();}return {loss/z.size(),g};}
bool oneof(const string& s,initializer_list<const char*> opts){for(auto x:opts)if(s==x)return true;return false;}
int main(int argc,char**argv){
 if(argc!=11){cerr<<"usage: run MODE DIM STEPS TRIAL RECORD_INTERVAL OUTPUT_DIR KERNEL HISTORY ADDITIVE CBO\n";return 1;}
 string mode=argv[1]; int d=stoi(argv[2]),T=stoi(argv[3]),tr=stoi(argv[4]),interval=stoi(argv[5]);fs::path dir=argv[6];string variant=argv[7],history_rule=argv[8],additive_rule=argv[9],cbo_rule=argv[10];
 if(d<2||T<1||tr<0||interval<1||!oneof(mode,{"control","cbo","gcbo","svgd","leader","ula","m1","m2","m3","m4","m5","A","m6","B","m61","B1"}))return 1;
 if(variant!="baseline"&&variant!="sqrt_d"&&variant!="median0")return 1;
 if(history_rule!="original"&&history_rule!="dim")return 1;
 if(additive_rule!="original"&&additive_rule!="total")return 1;
 if(cbo_rule!="isotropic"&&cbo_rule!="normalized"&&cbo_rule!="coordinate")return 1;
 const double q2=double(d)/2, q=sqrt(q2);
 double sigma=variant=="sqrt_d"?.3*sqrt(double(d)):.3;
 double kernel_den=variant=="sqrt_d"?.36*d:.36, kernel_grad_den=variant=="sqrt_d"?.18*d:.18;
 fs::create_directories(dir); string stem=mode+"_d"+to_string(d)+"_trial"+to_string(tr);fs::path trace=dir/(stem+".csv"),positions=dir/(stem+"_particles.csv");
 if(fs::exists(trace)||fs::exists(positions)){cerr<<"output exists; refusing to overwrite\n";return 3;}
 ofstream out(trace),pos(positions);out<<setprecision(17);pos<<setprecision(17);
 out<<"step,best_loss,best_particle,best_so_far,mean_loss,median_loss,success,mean_radius,mean_offdiag_kernel,sigma,mean_gradient_norm,mean_consensus_norm,mean_svgd_self_score_norm,mean_svgd_other_score_norm,mean_svgd_current_repulsion_norm,mean_svgd_history_score_norm,mean_svgd_history_repulsion_norm,mean_history_repulsion_norm,mean_total_drift_norm,mean_noise_step_rms,active_svgd_current,active_svgd_history,active_history_repulsion\n";pos<<"step,particle,x_projection_1,x_projection_2,loss\n";
 // Q is a reproducible orthogonal matrix generated independently for each dimension.
 mt19937_64 qrng(20261027+d);normal_distribution<double> qnorm;vector<Vec> Q(d,Vec(d));
 for(int col=0;col<d;col++){
  for(int row=0;row<d;row++)Q[row][col]=qnorm(qrng);
  for(int prev=0;prev<col;prev++){double dot=0;for(int row=0;row<d;row++)dot+=Q[row][col]*Q[row][prev];for(int row=0;row<d;row++)Q[row][col]-=dot*Q[row][prev];}
  double norm=0;for(int row=0;row<d;row++)norm+=Q[row][col]*Q[row][col];norm=sqrt(norm);if(norm<1e-12)return 4;for(int row=0;row<d;row++)Q[row][col]/=norm;
 }
 // Evolve z=Qx: rotations preserve pair distances and isotropic noise. The fixed
 // projection below reconstructs the first two coordinates of x=Q^T z.
 mt19937_64 init(120000+tr),cr(800000+tr),rr(42000+tr),rb(142000+tr),nr(240000+tr),gr(880000+tr);uniform_real_distribution<double> u(0,1);normal_distribution<double> normal;
 vector<Vec>x(N,Vec(d)),g(N,Vec(d)),next=x,reservoir(K,Vec(d));array<double,N>L{},D{},lam{},kap{},gamma{};
 for(int i=0;i<N;i++){Vec original(d);for(double &v:original)v=10.24*u(init)-5.12;for(int j=0;j<d;j++)for(int k=0;k<d;k++)x[i][j]+=Q[j][k]*original[k];}
 if(variant=="median0"){
  vector<double> distances;distances.reserve(N*(N-1)/2);
  for(int i=0;i<N;i++)for(int j=i+1;j<N;j++)distances.push_back(sqrt(sqdist(x[i],x[j])));
  sort(distances.begin(),distances.end());size_t mid=distances.size()/2;
  sigma=(distances[mid-1]+distances[mid])/4; // median distance / 2, fixed throughout this trial
  if(!isfinite(sigma)||sigma<=0)return 6;
  kernel_den=4*sigma*sigma;kernel_grad_den=2*sigma*sigma;
 }
 for(int i=0;i<N;i++){
  lam[i]=oneof(mode,{"m1","control"})?.02:.01+.02*u(cr);
  kap[i]=mode=="m1"?.04:oneof(mode,{"m2","m3","m4","m5","m6","B","m61","B1"})?.02+.04*u(cr):0;
  D[i]=oneof(mode,{"m1","control"})?0:.015*u(cr);
  if(oneof(mode,{"m3","m4","m5","m6","B","m61","B1"})&&i>=56){kap[i]=0;if(mode!="m3"||i==56)D[i]=0;}
 }
 for(int i=0;i<N;i++)gamma[i]=(oneof(mode,{"m5","m6","B","m61","B1"})&&i<56)?.5+u(gr):1;
 int ns=(mode=="m6"||mode=="B")?8:(mode=="m61"||mode=="B1")?32:0;
 for(int i=0;i<ns;i++){D[i]=0;lam[i]=0;kap[i]=0;gamma[i]=1;}
 if(oneof(mode,{"cbo","gcbo","leader","svgd","A","ula"}))for(int i=0;i<N;i++){lam[i]=oneof(mode,{"cbo","gcbo","leader"})?.02:0;D[i]=mode=="ula"?.005:0;}
 bool has_history=oneof(mode,{"m1","m2","m3","m4","m5","m6","B","m61","B1","A","control"});
 long long seen=0;double mass=0,history_min=numeric_limits<double>::infinity(),bestever=numeric_limits<double>::infinity();Vec moment(d,0);
 auto started=chrono::steady_clock::now();
 for(int step=0;step<=T;step++){
  for(int i=0;i<N;i++){auto e=evaluate(x[i]);L[i]=e.first;g[i]=move(e.second);if(!isfinite(L[i])){cerr<<"nonfinite at "<<step;return 2;}}
  int bi=min_element(L.begin(),L.end())-L.begin();bestever=min(bestever,L[bi]);
  bool keep=step%interval==0||step==T;
  array<double,9> normsum{};double noise_rms_sum=0;int current_count=0,history_count=0,history_rep_count=0;
  if(mode=="m4")for(int i=0;i<N;i++){double density=0;for(int j=0;j<N;j++)if(i!=j)density+=exp(-sqdist(x[i],x[j])/kernel_den);density/=63;D[i]=.015*density/(density+.2);}
  Vec leader(d,0);double W=0;double current_min=L[bi];for(int i=0;i<N;i++){double w=exp(-(L[i]-current_min)/TAU);W+=w;for(int k=0;k<d;k++)leader[k]+=w*x[i][k];}for(double &v:leader)v/=W;
  if(has_history){
   if(current_min<history_min){double factor=isfinite(history_min)?exp(-(history_min-current_min)/TAU):0;mass*=factor;for(double &v:moment)v*=factor;history_min=current_min;}
   for(int i=0;i<N;i++){double w=exp(-(L[i]-history_min)/TAU);mass+=w;for(int k=0;k<d;k++)moment[k]+=x[i][k]*w;seen++;if(seen<=K)reservoir[seen-1]=x[i];else{uniform_int_distribution<long long> pick(0,seen-1);long long j=pick(rr);if(j<K)reservoir[j]=x[i];}}
   for(int k=0;k<d;k++)leader[k]=moment[k]/mass;
  }
  if(mode=="leader")leader=x[bi];
  array<int,S> sample{};vector<Vec> sg(S,Vec(d));
  if(has_history&&mode!="control"){int count=int(min(seen,(long long)K));array<int,K> a; iota(a.begin(),a.end(),0);for(int j=0;j<S;j++){uniform_int_distribution<int> pick(j,count-1);swap(a[j],a[pick(rb)]);sample[j]=a[j];}}
  if(oneof(mode,{"A","B","B1"}))for(int j=0;j<S;j++)sg[j]=evaluate(reservoir[sample[j]]).second;
  for(int i=0;i<N;i++){
   Vec drift(d,0);double dc=0;
   // Components are norms of net drift vectors per particle (before multiplying by ETA).
   // They are gathered only at recorded steps and do not alter the dynamics or RNG.
   vector<Vec> terms;if(keep)terms.assign(8,Vec(d,0));
   if(mode=="cbo"||mode=="gcbo"){for(int k=0;k<d;k++){drift[k]=.02*(leader[k]-x[i][k])-(mode=="gcbo"?g[i][k]:0);if(keep){terms[0][k]=mode=="gcbo"?-g[i][k]:0;terms[1][k]=.02*(leader[k]-x[i][k]);}}dc=.1*sqrt(sqdist(x[i],leader));if(cbo_rule=="normalized")dc/=q;}
   else if(mode=="ula"){for(int k=0;k<d;k++){drift[k]=-g[i][k];if(keep)terms[0][k]=-g[i][k];}dc=sqrt(.01);if(additive_rule=="total")dc/=q;}
   else if(mode=="leader"){for(int k=0;k<d;k++){drift[k]=-g[i][k]+.02*(leader[k]-x[i][k]);if(keep){terms[0][k]=-g[i][k];terms[1][k]=.02*(leader[k]-x[i][k]);}}}
   else if(mode=="A"||(mode=="B"&&i<8)||(mode=="B1"&&i<32)){
    history_count++;
    for(int j=0;j<S;j++){auto &y=reservoir[sample[j]];double kernel=exp(-sqdist(x[i],y)/kernel_den);for(int k=0;k<d;k++){double score=-sg[j][k]*kernel/TAU,rep=(x[i][k]-y[k])*kernel/kernel_grad_den;drift[k]+=(score+rep)/S;if(keep){terms[5][k]+=score/S;terms[6][k]+=rep/S;}}}
   }else if(mode=="svgd"||(mode=="m6"&&i<8)||(mode=="m61"&&i<32)){
    current_count++;
    for(int j=0;j<N;j++){double kernel=exp(-sqdist(x[i],x[j])/kernel_den);for(int k=0;k<d;k++){double score=-g[j][k]*kernel/TAU,rep=(x[i][k]-x[j][k])*kernel/kernel_grad_den;drift[k]+=(score+rep)/N;if(keep){terms[j==i?2:3][k]+=score/N;terms[4][k]+=rep/N;}}}
   }else{
    for(int k=0;k<d;k++){drift[k]=-gamma[i]*g[i][k]+lam[i]*(leader[k]-x[i][k]);if(keep){terms[0][k]=-gamma[i]*g[i][k];terms[1][k]=lam[i]*(leader[k]-x[i][k]);}}
    if(kap[i]>0){history_rep_count++;for(int a=0;a<S;a++){auto &y=reservoir[sample[a]];double scale=history_rule=="dim"?(kap[i]/S*q2/pow(sqdist(x[i],y)/2+EPS*EPS*q2,1.5)):(kap[i]/S/pow(sqdist(x[i],y)/2+EPS*EPS,1.5));for(int k=0;k<d;k++){double v=(x[i][k]-y[k])*scale;drift[k]+=v;if(keep)terms[7][k]+=v;}}}
    dc=sqrt(2*D[i]);if(additive_rule=="total")dc/=q;
   }
   bool coordinate_noise=oneof(mode,{"cbo","gcbo"})&&cbo_rule=="coordinate";
   if(keep){for(int component=0;component<8;component++){double norm=0;for(double v:terms[component])norm+=v*v;normsum[component]+=sqrt(norm)/N;}double totalnorm=0;for(double v:drift)totalnorm+=v*v;normsum[8]+=sqrt(totalnorm)/N;
    noise_rms_sum+=(coordinate_noise?(.1*sqrt(2*ETA*sqdist(x[i],leader))):(sqrt(ETA*d)*dc))/N;
   }
   if(step<T)for(int k=0;k<d;k++){double noise_coeff=coordinate_noise?.1*sqrt(2.0)*(x[i][k]-leader[k]):dc;next[i][k]=x[i][k]+ETA*drift[k]+sqrt(ETA)*noise_coeff*normal(nr);if(!isfinite(next[i][k])){cerr<<"nonfinite at "<<step;return 2;}}
  }
  if(keep){array<double,N> sorted=L;sort(sorted.begin(),sorted.end());double mean=accumulate(L.begin(),L.end(),0.0)/N;Vec center(d,0);for(auto &v:x)for(int k=0;k<d;k++)center[k]+=v[k]/N;double radius=0;for(auto &v:x)radius+=sqdist(v,center)/N;
   double kernelmean=0;for(int i=0;i<N;i++)for(int j=0;j<N;j++)if(i!=j)kernelmean+=exp(-sqdist(x[i],x[j])/kernel_den);kernelmean/=(N*(N-1));
   out<<step<<','<<L[bi]<<','<<bi<<','<<bestever<<','<<mean<<','<<(sorted[31]+sorted[32])/2<<','<<(bestever<.01)<<','<<sqrt(radius)<<','<<kernelmean<<','<<sigma;for(double v:normsum)out<<','<<v;out<<','<<noise_rms_sum<<','<<current_count<<','<<history_count<<','<<history_rep_count<<'\n';
   for(int i=0;i<N;i++){double px=0,py=0;for(int k=0;k<d;k++){px+=Q[k][0]*x[i][k];py+=Q[k][1]*x[i][k];}pos<<step<<','<<i<<','<<px<<','<<py<<','<<L[i]<<'\n';}out.flush();pos.flush();
  }
  if(step==T)break;
  x.swap(next);
 }
 if(!out||!pos){cerr<<"write failure";return 5;}out.close();pos.close();ofstream done(dir/(stem+".done"));done<<"completed\n";done.close();
 cerr<<stem<<" complete "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<" sec\n";
}
