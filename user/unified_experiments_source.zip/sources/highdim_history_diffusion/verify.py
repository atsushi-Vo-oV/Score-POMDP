import csv,math,pathlib,subprocess,tempfile

ROOT=pathlib.Path(__file__).resolve().parent
OLD=ROOT.parent/'highdim_force_scaling'/'run.exe'
EXE=ROOT/'run.exe'
MODES=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
def read(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def run(exe,mode,d,directory,extra):
    args=[str(exe),mode,str(d),'100','0','50',str(directory)]+extra
    subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return read(directory/f'{mode}_d{d}_trial0.csv')
work=ROOT.parent.parent/'work'
with tempfile.TemporaryDirectory(prefix='history_diffusion_verify_',dir=str(work)) as tmp:
    p=pathlib.Path(tmp)
    for d in (20,100):
        for mode in MODES:
            old=run(OLD,mode,d,p/str(d)/mode/'old',['median0'])
            new=run(EXE,mode,d,p/str(d)/mode/'new',['median0','original','original','isotropic'])
            for a,b in zip(old,new):
                for k in a:
                    assert math.isclose(float(a[k]),float(b[k]),rel_tol=1e-12,abs_tol=1e-12),(d,mode,k,a[k],b[k])
                assert math.isfinite(float(b['mean_noise_step_rms'])) and float(b['mean_noise_step_rms'])>=0
    for mode in ('m1','m4','m5','ula','cbo','gcbo'):
        old=run(EXE,mode,2,p/'d2'/mode/'original',['median0','original','original','isotropic'])
        new=run(EXE,mode,2,p/'d2'/mode/'dim',['median0','dim','total','normalized'])
        for a,b in zip(old,new):
            for k in a:assert math.isclose(float(a[k]),float(b[k]),rel_tol=1e-12,abs_tol=1e-12),(mode,k,a[k],b[k])
    for d in (20,100):
        def first(mode,rep,add,cbo,label):return run(EXE,mode,d,p/str(d)/'checks'/label,['median0',rep,add,cbo])[0]
        ula=first('ula','original','original','isotropic','ula0');ulat=first('ula','original','total','isotropic','ulat')
        assert math.isclose(float(ula['mean_noise_step_rms']),.01*math.sqrt(d),rel_tol=1e-12)
        assert math.isclose(float(ulat['mean_noise_step_rms']),.01*math.sqrt(2),rel_tol=1e-12)
        cbo=first('cbo','original','original','isotropic','cbo0');cbon=first('cbo','original','original','normalized','cbon');cboc=first('cbo','original','original','coordinate','cboc')
        assert math.isclose(float(cbo['mean_noise_step_rms'])/math.sqrt(d/2),float(cbon['mean_noise_step_rms']),rel_tol=1e-12)
        assert math.isclose(float(cbon['mean_noise_step_rms']),float(cboc['mean_noise_step_rms']),rel_tol=1e-12)
        h0=first('m1','original','original','isotropic','h0');hd=first('m1','dim','original','isotropic','hd')
        assert float(hd['mean_history_repulsion_norm'])>float(h0['mean_history_repulsion_norm'])*(.9*d/2)
print('PASS: baseline trajectory, d=2 preservation, sqrt(d) noise scaling, matched CBO noise energy, history scaling')
