"""Small, reproducible diagnostic runs; separate from the main 48-trial study."""
import csv,json,pathlib,subprocess
from datetime import datetime

ROOT=pathlib.Path(__file__).resolve().parent
CONDITIONS={
 'm1':[('original','original','isotropic'),('dim','original','isotropic')],
 'm5':[('original','original','isotropic'),('dim','original','isotropic'),('original','total','isotropic'),('dim','total','isotropic')],
 'ula':[('original','original','isotropic'),('original','total','isotropic')],
 'cbo':[('original','original','isotropic'),('original','original','normalized'),('original','original','coordinate')],
}
def main():
    records=[]
    for d in (20,100):
        for mode,conditions in CONDITIONS.items():
            for hist,add,cbo in conditions:
                variant=f'history-{hist}_add-{add}_cbo-{cbo}'
                target=ROOT/'pilot'/f'd{d}'/mode/variant
                target.mkdir(parents=True,exist_ok=True)
                marker=target/f'{mode}_d{d}_trial0.done'
                if not marker.exists():
                    log=target/'execution.log'
                    with log.open('w',encoding='utf-8') as f:
                        p=subprocess.run([str(ROOT/'run.exe'),mode,str(d),'1000','0','500',str(target),'median0',hist,add,cbo],stdout=f,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    if p.returncode!=0:raise RuntimeError(f'Failed {d} {mode} {variant}: {p.returncode}; see {log}')
                with (target/f'{mode}_d{d}_trial0.csv').open(newline='') as f:
                    for r in csv.DictReader(f):
                        records.append({'dimension':d,'mode':mode,'history':hist,'additive':add,'cbo_noise':cbo,**r})
    with (ROOT/'pilot_summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    (ROOT/'pilot_status.json').write_text(json.dumps({'state':'complete','trials':sum(len(c) for c in CONDITIONS.values())*2,'trial_index':0,'steps':1000,'updated':datetime.now().astimezone().isoformat(timespec='seconds')},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('pilot complete:',len(records),'records from',sum(len(c) for c in CONDITIONS.values())*2,'runs')
if __name__=='__main__':main()
