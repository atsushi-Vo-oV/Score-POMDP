履歴反発・拡散の次元調整：検証用コード

これは highdim_force_scaling の実行中の比較とは独立した検証用の実装。
その比較のコード・設定・結果には変更を加えていない。

引数:
  run MODE DIM STEPS TRIAL INTERVAL OUTPUT KERNEL HISTORY ADDITIVE CBO
  KERNEL   : baseline / sqrt_d / median0 （元・0.3sqrt(d)・初期距離中央値/2）
  HISTORY  : original / dim
  ADDITIVE : original / total
  CBO      : isotropic / normalized / coordinate
  必ず新規の出力フォルダを指定する。同じファイル名への上書きは拒否する。

履歴反発の次元調整（今回の設計案）:
  d0=2, q=sqrt(d/d0), Delta=x-Y とすると
    F_original = kappa*Delta/(||Delta||^2/2+epsilon^2)^(3/2)
    F_dim      = kappa*q^2*Delta/(||Delta||^2/2+q^2*epsilon^2)^(3/2).
  これは Delta/q を元の力の式に入れることと等しく、d=2では元の式に一致。
  距離がepsilonに比べ十分大きければ、同じ粒子配置で元の約d/2倍となる。
  高次元における距離~sqrt(d)のもとでは、1組の力のノルムの減少を補う
  意図だが、総反発の打ち消しや力の比率を保つ保証はない。収束の保証を
  既存研究から直接移した方法ではなく、今回の実験の比較候補。

加法拡散の次元調整:
  元: sqrt(2*D*eta)*Z、Z~N(0,I_d)。1粒子の1回の拡散変位のRMSは
      sqrt(2*D*eta*d)。Dは各座標の拡散係数である。
  total: D_d=D*2/d。d=2で元の式に一致し、全座標の合計変位のRMSを
      比較する基準次元2と同じにする。これは比較目的の選択であり、
      常に最適という意味ではない。SVGD等で拡散が0なら0のまま。

CBOの拡散:
  isotropic: 0.1*sqrt(eta)*||x-c||*Z （従来通り）
  normalized: isotropicをsqrt(2/d)倍（d=2と同じ合計拡散エネルギー）。
  coordinate: 0.1*sqrt(2*eta)*(x-c)⊙Z。
    方向別のCBO拡散を参考にした条件。係数sqrt(2)は normalized と
    合計拡散エネルギーを一致させるための今回の較正で、原論文の係数を
    そのまま主張するものではない。座標に依存するので回転不変ではない。
    回転Rastriginでは計算座標 z=Qx で成分別のノイズを掛ける。
    この座標ではRastriginの各項が分離するため、元のx座標で成分別
    ノイズを掛ける場合とは別条件。回転後の分離性が結果に影響しうる。
    全成分に同じ数値で非ゼロを保つ等方拡散とは共分散構造が変わる。
  ADDITIVEはULAやモデル2〜6等の加法拡散に適用し、CBOのノイズには適用しない。

出力CSVの mean_noise_step_rms は、各粒子について乱数を取る前の
  sqrt(E[||拡散による1回の変位||^2 | 現在状態]) を計算し、64粒子で平均。
  実現したノイズのノルムの平均そのものではない。拡散以外のドリフトは
  前回同様にetaを掛ける前の値。比較する際にはドリフトにetaを掛ける。
  最終記録stepでは、次の更新に用いると仮定したノイズの理論RMSを記録し、
  実際の次の状態更新は行わない。

検証:
  verify.pyで16方式・20/100次元の従来挙動、d=2での補正前後の一致、
  ULAの拡散RMS、CBOの2種類の補正のRMS一致、履歴反発の補正を確認する。
  完全な長時間の比較実験ではなく、実装検証と短時間パイロットである。
  pilot_summary.csvには20/100次元、モデル1・モデル5・ULA・CBOの
  22条件、各1試行、1000更新、500更新刻みの値を収録する。
  pilot_status.jsonおよびpilot/内の個別ファイルに完了状態と各試行を保存。
  粒子ごとの係数や初期値の偏りの影響が大きいため、性能に関する結論には
  複数試行・長時間の独立比較が必要。

参考文献:
  Carrillo, Jin, Li, Zhu (2020), A consensus-based global optimization method
    for high dimensional machine learning problems, https://arxiv.org/abs/1909.09249
  Fornasier, Klock, Riedl (2024), Convergence of Anisotropic Consensus-Based
    Optimization in Mean-Field Law, https://arxiv.org/abs/2111.08136
  Xu, Korba, Slepcev (2022), Accurate Quantization of Measures via Interacting
    Particle-based Optimization, https://proceedings.mlr.press/v162/xu22d.html
  Pillai, Stuart, Thiery (2012), Optimal scaling and diffusion limits for the
    Langevin algorithm in high dimensions, https://arxiv.org/abs/1103.0542
