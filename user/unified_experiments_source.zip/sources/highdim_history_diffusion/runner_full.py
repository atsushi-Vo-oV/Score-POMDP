"""Paired full comparison of history, additive diffusion, and CBO noise choices."""
import concurrent.futures,csv,hashlib,json,os,pathlib,subprocess,time,uuid
from datetime import datetime
import numpy as np
from PIL import Image,ImageDraw,ImageFont

PROJECT=pathlib.Path(__file__).resolve().parent
ROOT=PROJECT/'full'; EXE=PROJECT/'run.exe'; RUNS=ROOT/'runs'
MODES=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
HISTORY_MODES={'m1','m2','m3','m4','m5','m6','B','m61','B1'}
ADDITIVE_MODES={'ula','m2','m3','m4','m5','m6','B','m61','B1'}
CBO_MODES={'cbo','gcbo'}
CASES=('original','history','diffusion','combined')
CBO_EXTRA=('cbo_normalized','cbo_coordinate')
DIMS=(20,100);TRIALS=48;STEPS=30000;INTERVAL=500;WORKERS=2
METRICS=['mean_offdiag_kernel','mean_gradient_norm','mean_consensus_norm','mean_svgd_self_score_norm','mean_svgd_other_score_norm','mean_svgd_current_repulsion_norm','mean_svgd_history_score_norm','mean_svgd_history_repulsion_norm','mean_history_repulsion_norm','mean_total_drift_norm','mean_noise_step_rms']
COLORS=['#3d3d3d','#da2c38','#f38336','#3a5cc9','#008d86','#ab59b2','#858000','#1f8b4c','#5696ac','#974242','#d354a6','#574a86','#ed91a7','#93765d','#599c37','#169ba8']
NOW=lambda:datetime.now().astimezone().isoformat(timespec='seconds')
def atomic_json(p,obj):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(tmp,p)
def spec(mode,case):
    h='dim' if mode in HISTORY_MODES and case in ('history','combined') else 'original'
    a='total' if mode in ADDITIVE_MODES and case in ('diffusion','combined') else 'original'
    c={'cbo_normalized':'normalized','cbo_coordinate':'coordinate'}.get(case,'isotropic') if mode in CBO_MODES else 'isotropic'
    return h,a,c
def choices(mode):return CASES+CBO_EXTRA if mode in CBO_MODES else CASES
def experiment_dir(d,mode,tr,h,a,c):return RUNS/f'd{d}'/mode/f'h-{h}_a-{a}_c-{c}'/f'trial{tr:02d}'
def done_path(job):
    d,mode,tr,h,a,c=job;p=experiment_dir(*job)
    if not p.exists():return None
    found=sorted(p.glob(f'*/{mode}_d{d}_trial{tr}.done'))
    return found[-1].parent if found else None
def build_jobs():
    seen=set();jobs=[]
    for tr in range(TRIALS):
        for d in DIMS:
            for mode in MODES:
                for case in choices(mode):
                    job=(d,mode,tr,*spec(mode,case))
                    if job not in seen:seen.add(job);jobs.append(job)
    return jobs
def run_one(job):
    d,mode,tr,h,a,c=job
    if done_path(job):return job,'existing',None
    attempt=experiment_dir(*job)/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    with (attempt/'execution.log').open('w',encoding='utf-8') as log:
        try:
            p=subprocess.run([str(EXE),mode,str(d),str(STEPS),str(tr),str(INTERVAL),str(attempt),'median0',h,a,c],stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            return job,('complete' if p.returncode==0 and done_path(job) else 'failed'),p.returncode
        except Exception as exc:log.write(repr(exc));return job,'failed',str(exc)
def rows(path):
    with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def font(size):
    try:return ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
    except OSError:return ImageFont.load_default()
def aggregate():
    records=[];groups={};cache={}
    for d in DIMS:
        for mode in MODES:
            for case in choices(mode):
                h,a,c=spec(mode,case);physical=(d,mode,h,a,c)
                if physical not in cache:
                    results=[]
                    for tr in range(TRIALS):
                        p=done_path((d,mode,tr,h,a,c))
                        if p:
                            rr=rows(p/f'{mode}_d{d}_trial{tr}.csv')
                            if len(rr)==STEPS//INTERVAL+1:results.append(rr)
                    cache[physical]=results
                results=cache[physical]
                if not results:continue
                series=[]
                for j in range(len(results[0])):
                    batch=[r[j] for r in results]
                    current=np.array([float(r['best_loss']) for r in batch]);ever=np.array([float(r['best_so_far']) for r in batch]);width=np.array([float(r['sigma']) for r in batch])
                    row={'dimension':d,'mode':mode,'case':case,'effective_history':h,'effective_additive':a,'effective_cbo':c,'step':int(batch[0]['step']),'trials':len(batch),'median_sigma':float(np.median(width)),'median_current_best':float(np.median(current)),'q25_current_best':float(np.quantile(current,.25)),'q75_current_best':float(np.quantile(current,.75)),'median_best_so_far':float(np.median(ever)),'q25_best_so_far':float(np.quantile(ever,.25)),'q75_best_so_far':float(np.quantile(ever,.75)),'success_trials':sum(int(r['success']) for r in batch)}
                    for k in METRICS:row['median_'+k]=float(np.median([float(r[k]) for r in batch]))
                    for k in ('active_svgd_current','active_svgd_history','active_history_repulsion'):row[k]=int(batch[0][k])
                    records.append(row);series.append(row)
                groups[(d,mode,case)]=series
    if not records:return
    tmp=ROOT/'summary.partial.csv.tmp'
    with tmp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    os.replace(tmp,ROOT/'summary.partial.csv')
    for d in DIMS:
        if any((d,m,c) in groups for m in MODES for c in CASES):plot_loss(d,groups)
        if any((d,m,c) in groups for m in CBO_MODES for c in ('original',)+CBO_EXTRA):plot_cbo(d,groups)
def plot_loss(d,groups):
    img=Image.new('RGB',(1800,1450),'white');dr=ImageDraw.Draw(img);large=font(23);small=font(14);tiny=font(11)
    dr.text((25,12),f'd={d}: best-so-far loss; median across completed paired trials',font=large,fill='black')
    vals=[max(1e-12,r['median_best_so_far']) for m in MODES for c in CASES for r in groups.get((d,m,c),[])]
    lo=int(np.floor(np.log10(min(vals))));hi=int(np.ceil(np.log10(max(vals))));hi=max(hi,lo+1)
    for panel,case in enumerate(CASES):
        col=panel%2;row=panel//2;x0=65+col*725;x1=x0+650;y0=100+row*645;y1=y0+525
        dr.text((x0,y0-30),case,font=large,fill='black');dr.rectangle((x0,y0,x1,y1),outline='black')
        for e in range(lo,hi+1):
            y=y1-(e-lo)/(hi-lo)*(y1-y0);dr.line((x0,y,x1,y),fill='#dddddd');dr.text((x0-42,y-7),f'1e{e}',font=tiny,fill='black')
        for mode in MODES:
            data=groups.get((d,mode,case))
            if not data:continue
            pts=[(x0+(x1-x0)*r['step']/STEPS,y1-(np.log10(max(1e-12,r['median_best_so_far']))-lo)/(hi-lo)*(y1-y0)) for r in data]
            if len(pts)>1:dr.line(pts,fill=COLORS[MODES.index(mode)],width=2)
        dr.text((x0,y1+7),'0',font=tiny,fill='black');dr.text((x1-45,y1+7),str(STEPS),font=tiny,fill='black')
    for i,mode in enumerate(MODES):
        y=110+i*35;dr.line((1520,y+7,1550,y+7),fill=COLORS[i],width=3);dr.text((1560,y),mode,font=small,fill='black')
    dr.text((25,1410),'Trial counts and quartiles are in summary.partial.csv. Identical settings share data.',font=small,fill='black')
    tmp=ROOT/f'loss_compare_d{d}.tmp.png';img.save(tmp);os.replace(tmp,ROOT/f'loss_compare_d{d}.png')
def plot_cbo(d,groups):
    cases=('original',)+CBO_EXTRA;colors=['#444444','#1869c7','#d94b3d'];img=Image.new('RGB',(1200,700),'white');dr=ImageDraw.Draw(img);large=font(22);small=font(15)
    dr.text((25,15),f'd={d}: CBO noise options; median best-so-far loss',font=large,fill='black')
    vals=[max(1e-12,r['median_best_so_far']) for m in ('cbo','gcbo') for case in cases for r in groups.get((d,m,case),[])]
    lo=int(np.floor(np.log10(min(vals))));hi=int(np.ceil(np.log10(max(vals))));hi=max(hi,lo+1)
    for panel,mode in enumerate(('cbo','gcbo')):
        x0=65+panel*530;x1=x0+460;y0=100;y1=560;dr.text((x0,y0-28),mode,font=large,fill='black');dr.rectangle((x0,y0,x1,y1),outline='black')
        for e in range(lo,hi+1):
            y=y1-(e-lo)/(hi-lo)*(y1-y0);dr.line((x0,y,x1,y),fill='#dddddd');dr.text((x0-42,y-8),f'1e{e}',font=small,fill='black')
        for i,case in enumerate(cases):
            data=groups.get((d,mode,case))
            if not data:continue
            pts=[(x0+(x1-x0)*r['step']/STEPS,y1-(np.log10(max(1e-12,r['median_best_so_far']))-lo)/(hi-lo)*(y1-y0)) for r in data]
            if len(pts)>1:dr.line(pts,fill=colors[i],width=3)
    for i,case in enumerate(cases):dr.line((70+i*360,620,100+i*360,620),fill=colors[i],width=3);dr.text((110+i*360,610),case,font=small,fill='black')
    tmp=ROOT/f'cbo_compare_d{d}.tmp.png';img.save(tmp);os.replace(tmp,ROOT/f'cbo_compare_d{d}.png')
def main():
    ROOT.mkdir(parents=True,exist_ok=True);RUNS.mkdir(exist_ok=True)
    digest=hashlib.sha256(EXE.read_bytes()).hexdigest();source_hash=hashlib.sha256((PROJECT/'run.cpp').read_bytes()).hexdigest()
    jobs=build_jobs();manifest={'dimensions':list(DIMS),'modes':MODES,'trials':TRIALS,'steps':STEPS,'interval':INTERVAL,'kernel':'median0','logical_cases':list(CASES),'cbo_extra':list(CBO_EXTRA),'unique_runs':len(jobs),'executable_sha256':digest,'source_sha256':source_hash}
    path=ROOT/'manifest.json'
    if path.exists():
        existing=json.loads(path.read_text(encoding='utf-8'))
        if existing!=manifest:raise RuntimeError('Configuration or executable changed; use a new output directory')
    else:atomic_json(path,manifest)
    pending=[job for job in jobs if not done_path(job)]
    state={'started':NOW(),'updated':NOW(),'state':'running','workers':WORKERS,'total_unique':len(jobs),'completed_unique':len(jobs)-len(pending),'failed':0,'active':[],'last':None}
    atomic_json(ROOT/'status.json',state)
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures={}
        def refresh():
            state['active']=[{'dimension':j[0],'mode':j[1],'trial':j[2],'history':j[3],'additive':j[4],'cbo':j[5]} for j in futures.values()]
            state['updated']=NOW();atomic_json(ROOT/'status.json',state)
        def refill():
            while len(futures)<WORKERS and pending and not (ROOT/'stop.flag').exists():
                job=pending.pop(0);futures[pool.submit(run_one,job)]=job
        refill();refresh()
        while futures:
            done,_=concurrent.futures.wait(futures,timeout=30,return_when=concurrent.futures.FIRST_COMPLETED)
            for fut in done:
                job,what,code=fut.result();del futures[fut]
                state['last']={'dimension':job[0],'mode':job[1],'trial':job[2],'history':job[3],'additive':job[4],'cbo':job[5],'result':what,'exit_code':code}
                state['completed_unique']+=what in ('complete','existing');state['failed']+=what=='failed'
                if state['completed_unique']<=12 or state['completed_unique']%48==0:
                    try:aggregate()
                    except Exception as exc:
                        with (ROOT/'analysis_errors.log').open('a',encoding='utf-8') as f:f.write(f'{NOW()} {exc!r}\n')
            refill();refresh()
    analysis_ok=True
    try:aggregate()
    except Exception as exc:
        analysis_ok=False
        with (ROOT/'analysis_errors.log').open('a',encoding='utf-8') as f:f.write(f'{NOW()} {exc!r}\n')
    analysis_ok=analysis_ok and (ROOT/'summary.partial.csv').exists()
    state['state']='stopped' if (ROOT/'stop.flag').exists() else ('complete' if state['failed']==0 and analysis_ok else 'finished_with_errors');state['active']=[];state['updated']=NOW();atomic_json(ROOT/'status.json',state)
    if state['state']=='complete':
        import shutil
        shutil.copy2(ROOT/'summary.partial.csv',ROOT/'summary.csv')
if __name__=='__main__':main()
