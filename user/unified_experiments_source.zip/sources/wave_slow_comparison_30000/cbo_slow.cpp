#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <string>
#include <vector>
using namespace std;
const double PI=acos(-1.0), eta=.0001, tau=.15, eps=.2; const int N=64,T=30000,TR=48;
struct V {double a,w; V operator+(V b)const{return {a+b.a,w+b.w};} V operator-(V b)const{return {a-b.a,w-b.w};} V operator*(double b)const{return {a*b,w*b};}};
double norm2(V a){return a.a*a.a+a.w*a.w;}
pair<double,double> cs(double z){
 z=remainder(z,2*PI); const double n=64, mid=31.5; double dz=2*PI/63;
 if(fabs(z)<1e-4){double s=0,d=0;for(int j=0;j<64;j++){s+=cos(j*z);d-=j*dz*sin(j*z);} return {s,d};}
 double A=sin(n*z/2),B=cos(mid*z),C=sin(z/2);
 double s=A*B/C, deriv=((n/2*cos(n*z/2)*B-mid*A*sin(mid*z))/C-A*B*.5*cos(z/2)/(C*C))*dz;return {s,deriv};
}
pair<double,V> eval(V x){double dz=2*PI/63;auto cm=cs((x.w-3)*dz),cp=cs((x.w+3)*dz),c2=cs(2*x.w*dz);double s2=(64-c2.first)/2, cross=(cm.first-cp.first)/2,ds2=-c2.second,dcross=(cm.second-cp.second)/2;return {(x.a*x.a*s2-2*x.a*cross+31.5)/128,{(x.a*s2-cross)/64,(x.a*x.a*ds2-2*x.a*dcross)/128}};}
int main(int argc,char**argv){string mode=argv[1],dir=argv[2]; ifstream in(dir+"/initial.csv");vector<array<V,N>> initial(TR); for(auto &trial:initial)for(auto &x:trial)in>>x.a>>x.w; if(!in){cerr<<"bad initial";return 1;}
 ofstream out(dir+"/"+mode+".csv"),path(dir+"/"+mode+"_path.csv"),coef(dir+"/"+mode+"_coeff.csv");out<<"trial,step,particle,a,w,loss,D,lambda,kappa\n";path<<"step,particle,a,w,loss,D\n";coef<<"trial,particle,D,lambda,kappa,gradient_scale\n";out<<setprecision(17);path<<setprecision(17);coef<<setprecision(17);
 auto start=chrono::steady_clock::now();
 for(int tr=0;tr<TR;tr++){
  array<V,N> x=initial[tr],g;array<double,N> L,D,lam,kap,gamma;mt19937_64 cr(800000+tr),rr(42000+tr),rb(142000+tr),nr(240000+tr);uniform_real_distribution<double>u(0,1);normal_distribution<double>normal(0,1);mt19937_64 gr(880000+tr);vector<V> reservoir(100);long long seen=0;double mass=0;V moment{0,0};
  for(int i=0;i<N;i++){lam[i]=(mode=="m1"||mode=="control")?.02:.01+.02*u(cr);kap[i]=(mode=="m1")?.04:(mode=="m2"||mode=="m3"||mode=="m4"||mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1")?.02+.04*u(cr):0;D[i]=mode=="m1"||mode=="control"?0:.015*u(cr);if(mode=="m3"||mode=="m4"||mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1"){if(i>=56)kap[i]=0;if(mode=="m3"&&i==56)D[i]=0;if((mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1")&&i>=56)D[i]=0;}}
  for(int i=0;i<N;i++)gamma[i]=((mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1")&&i<56)? .5+u(gr):1;
  if(mode=="m6"||mode=="B"||mode=="m61"||mode=="B1")for(int i=0;i<((mode=="m61"||mode=="B1")?32:8);i++){D[i]=0;lam[i]=0;kap[i]=0;gamma[i]=1;}
  if(mode=="cbo"||mode=="gcbo"||mode=="leader"||mode=="svgd"||mode=="A"||mode=="ula")for(int i=0;i<N;i++){lam[i]=(mode=="cbo"||mode=="gcbo"||mode=="leader")?.02:0;D[i]=(mode=="ula")?.005:0;}
  for(int i=0;i<N;i++)coef<<tr<<','<<i<<','<<D[i]<<','<<lam[i]<<','<<kap[i]<<','<<gamma[i]<<'\n';
  for(int step=0;step<=T;step++){
   for(int i=0;i<N;i++){auto e=eval(x[i]);L[i]=e.first;g[i]=e.second;}
   if(mode=="m4")for(int i=0;i<N;i++){double density=0;for(int j=0;j<N;j++)if(i!=j)density+=exp(-norm2(x[i]-x[j])/.36);density/=63;D[i]=.015*density/(density+.2);}
   if(mode=="cbo"||mode=="gcbo"){V c{0,0};double total=0;for(int j=0;j<N;j++){double weight=exp(-L[j]/tau);c=c+x[j]*weight;total+=weight;}c=c*(1/total);for(int i=0;i<N;i++)D[i]=.005*norm2(x[i]-c);}
   bool keep=step%500==0; if(keep) for(int i=0;i<N;i++)out<<tr<<','<<step<<','<<i<<','<<x[i].a<<','<<x[i].w<<','<<L[i]<<','<<D[i]<<','<<lam[i]<<','<<kap[i]<<'\n';
   if(tr==0&&step%500==0)for(int i=0;i<N;i++)path<<step<<','<<i<<','<<x[i].a<<','<<x[i].w<<','<<L[i]<<','<<D[i]<<'\n';
   if(step==T)break;
   V leader{0,0};double W=0;for(int i=0;i<N;i++){double weight=exp(-L[i]/tau);leader=leader+x[i]*weight;W+=weight;}leader=leader*(1/W);
   if(mode=="m1"||mode=="m2"||mode=="m3"||mode=="m4"||mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1"||mode=="A"||mode=="control"){
    for(int i=0;i<N;i++){double w=exp(-L[i]/tau);moment=moment+x[i]*w;mass+=w;seen++; if(seen<=100)reservoir[seen-1]=x[i];else {uniform_int_distribution<long long>uindex(0,seen-1);auto j=uindex(rr);if(j<100)reservoir[j]=x[i];}}
    leader=moment*(1/mass);
   }
   if(mode=="leader"){int best=min_element(L.begin(),L.end())-L.begin();leader=x[best];}
   int sample[16];if(mode=="m1"||mode=="m2"||mode=="m3"||mode=="m4"||mode=="m5"||mode=="m6"||mode=="B"||mode=="m61"||mode=="B1"||mode=="A"){int count=min(seen,100LL),arr[100];for(int i=0;i<count;i++)arr[i]=i;for(int i=0;i<16;i++){uniform_int_distribution<int>uindex(i,count-1);int j=uindex(rb);swap(arr[i],arr[j]);sample[i]=arr[i];}}
   V samplegrad[16];if(mode=="A"||mode=="B"||mode=="B1")for(int j=0;j<16;j++)samplegrad[j]=eval(reservoir[sample[j]]).second;
   array<V,N> next;
   for(int i=0;i<N;i++){
    V drift{0,0};double dc=0;
    if(mode=="cbo"||mode=="gcbo"){drift=(leader-x[i])*.02;if(mode=="gcbo")drift=drift-g[i];dc=.1*sqrt(norm2(x[i]-leader));}
    else if(mode=="ula"){drift=g[i]*(-1);dc=sqrt(2*.005);}
    else if(mode=="leader"){drift=g[i]*(-1)+(leader-x[i])*.02;}
    else if(mode=="A"||(mode=="B"&&i<8)||(mode=="B1"&&i<32)){
     for(int j=0;j<16;j++){V y=reservoir[sample[j]];V diff=x[i]-y;double K=exp(-norm2(diff)/.36);V yg=samplegrad[j];drift=drift+(yg*(-1/tau)*K+diff*(K/.18))*(1.0/16);}
    }
    else if(mode=="svgd"||(mode=="m6"&&i<8)||(mode=="m61"&&i<32)){
     for(int j=0;j<N;j++){V diff=x[i]-x[j];double K=exp(-norm2(diff)/(.36));drift=drift+(g[j]*(-1/tau)*K+diff*(K/.18))*(1.0/N);}
    }else{
     drift=g[i]*(-gamma[i])+(leader-x[i])*lam[i];
     if(kap[i]>0){V f{0,0};for(int a=0;a<16;a++){V d=x[i]-reservoir[sample[a]];double den=pow(norm2(d)/2+eps*eps,1.5);f=f+d*(1/den);}drift=drift+f*(kap[i]/16);}
     dc=sqrt(2*D[i]);
    }
    V noise{normal(nr),normal(nr)};next[i]=x[i]+drift*eta+noise*(dc*sqrt(eta));
    if(!isfinite(next[i].a)||!isfinite(next[i].w)){cerr<<"unstable "<<mode<<' '<<tr<<' '<<step<<endl;return 2;}
   }
   x=next;
  }
  if(tr%8==0)cerr<<mode<<" trial "<<tr<<"/48\n";
 }
 cerr<<mode<<" completed "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" s\n";
}
