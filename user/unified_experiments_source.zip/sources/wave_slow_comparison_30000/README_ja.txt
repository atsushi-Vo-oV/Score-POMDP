元の「波の例」の再現 + PSO比較（30,000更新）

課題
  真値 y=sin(3x)、近似 y_hat=a sin(wx)。探索空間は2次元の(a,w)。
  xは0から2*piの64点。損失 L(a,w)=1/(2*64) sum_j(a sin(w*x_j)-sin(3*x_j))^2。
  訓練と評価は同じ64点であり、汎化性能を比較するものではない。
  各方式64粒子、48試行、30,000更新、500更新ごと61時点を記録。

データの継承
  ULA・SVGDは、復元ZIPに保存されていた30,000更新の実データをそのまま使用。
  CBOとPSOは、ユーザーの要望に合わせ速度を変更して再計算した。
  4方式とも同じinitial.csvの各試行64粒子から開始。
  initial.csvの振幅は約0.411–1.216、周波数は約0.701–2.100。
  ULA・SVGDのスナップショットはfloat32。動画用の試行0経路は元精度float64。
  CBO・PSOの新規スナップショット・経路はfloat64。
  ULA・SVGDの集計値は元のfloat64集計CSVを継承。CBOは再計算したfloat64集計。
  source_manifest.jsonに元ファイルとコピーのSHA-256を記録。

ULA・SVGDの更新式（eta=0.01）と変更後のCBO
  ULA: x_i <- x_i - eta grad L(x_i) + sqrt(2*0.005*eta) Z_i。
  SVGD: x_i <- x_i + eta/N sum_j[-k(x_j,x_i) grad L(x_j)/0.15
                                       + k(x_j,x_i)(x_i-x_j)/0.18]。
    k(x_j,x_i)=exp(-||x_i-x_j||^2/0.36)。固定カーネル幅0.3。
  CBO: eta=0.0001（元は0.01）。c=sum_i exp(-L(x_i)/0.15)x_i / sum_i exp(-L(x_i)/0.15)。
       x_i <- x_i + eta*0.02*(c-x_i) + 0.1*sqrt(eta)*||x_i-c|| Z_i。
  元のULA・SVGD実装はsource_archive/run.cpp、変更したCBOはcbo_slow.cpp。

今回追加したPSO
  v_candidate=chi[v_i + 2.05*r1*(pbest_i-x_i) + 2.05*r2*(gbest-x_i)]。
  v_i <- 0.99*v_i + 0.01*v_candidate、x_i <- x_i+0.01*v_i。
  chi=2/(4.1-2+sqrt(4.1^2-4*4.1))=0.729843788...。
  r1,r2は成分ごと独立な一様乱数。個人・全体の過去最良、同期gbest、初速度0。
  速度制限・境界クリップは使用しない。乱数はmt19937_64(900000+試行番号)。
  速度の変更は試運転を見て選択。これにより結果も変わるため元のPSOと直接同一条件ではない。

図と動画
  wave_ULA_PSO_SVGD_CBO_30000.gif: 各方式の左側が(w,a)の位置、右側が波形。
    図中の文字は英語。全方式で事前固定した試行0を使用。
    赤丸は30,000更新後に最良だった粒子を事後的に選び、同じ粒子を最初から追跡。
    黒×と灰破線は各時点の最良粒子（時刻によって粒子番号が変わる）。
    黒実線は真値、色付き実線は固定追跡粒子の近似波形。星は基準解(1,3),(-1,-3)。
    画面の外に出た粒子数も表示。61フレームを全てデコードして確認している。
  wave_loss_comparison.png/.pdf: 48試行の損失と到達試行数。
  wave_final.png: 最終時点の粒子・波形。
  aggregate.csv: 500更新ごとの比較集計。final_summary.csv/.json:最終時点。
  MODE_data.npz: states=[48試行,61時点,64粒子,3変数(a,w,loss)]、
    steps、fields、試行0のfloat64経路、共通初期値を保存。allow_pickle=Falseで読める。
  source_archive/: 元のULA・SVGDと、再計算したCBOのスナップショット・経路・集計。
  pso_wave.cpp/.exe: PSOの計算コード/Windows実行ファイル。
  reproduce_wave.py: 検証・集計・描画・パッケージ化の処理。依存はnumpy,matplotlib,Pillow。

評価と限界
  到達は元と同じくL<0.01、かつ|w-3|<0.15または|w+3|<0.15。
  current_hit_trialsはその時点で到達粒子を含む試行数。累積数とは区別する。
  recorded_ever_hit_trialsと過去最良は、保存された500更新刻みの61時点だけを対象。
  その間の未保存ステップでの到達や最良値は、元のULA・SVGDでは復元できない。
  25–75%帯は試行間四分位であり、信頼区間ではない。
  波形損失のexp(-L/T)は無制限の(a,w)平面で正規化不能なので、ULA・SVGDを
  正しい確率分布からのサンプリングとして検証した例ではない。形式的更新の比較。
  ULAとSVGDは元から異なる拡散/温度設定を引き継ぐ。
  同じ更新回数であっても演算量や連続時間は同じではない。
  単一課題・係数1設定の比較であり、一般的な優劣を示すものではない。
  64点での波形には周波数エイリアスによる別の同値解もありうる。上の到達基準は±3を評価する。

PSO参考: Clerc & Kennedy (2002), https://doi.org/10.1109/4235.985692
