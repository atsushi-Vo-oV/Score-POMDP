import csv, math, pathlib, subprocess, tempfile

ROOT=pathlib.Path(__file__).resolve().parent
ORIGINAL=ROOT.parent/'highdim_rastrigin'/'run.exe'
EXE=ROOT/'run.exe'
MODES=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
FORCES=['mean_gradient_norm','mean_consensus_norm','mean_svgd_self_score_norm','mean_svgd_other_score_norm','mean_svgd_current_repulsion_norm','mean_svgd_history_score_norm','mean_svgd_history_repulsion_norm','mean_history_repulsion_norm','mean_total_drift_norm']
def read(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def run(exe,mode,d,dir,variant=None):
    args=[str(exe),mode,str(d),'100','0','50',str(dir)]
    if variant:args.append(variant)
    subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return read(dir/f'{mode}_d{d}_trial0.csv')
work=ROOT.parent.parent/'work'
with tempfile.TemporaryDirectory(prefix='force_verify_',dir=str(work)) as tmp:
    t=pathlib.Path(tmp)
    for d in (20,100):
        sigma=.3*math.sqrt(d);den=4*sigma*sigma
        # Independent finite difference for the actual RBF gradient.
        x,y=1.2,-.7;f=lambda a:math.exp(-(x-a)**2/den)
        numeric=(f(y+1e-6)-f(y-1e-6))/2e-6
        assert abs(numeric-2*(x-y)*f(y)/den)<1e-8
        for mode in MODES:
            dirs=[t/str(d)/mode/v for v in ('original','baseline','sqrt_d','median0')]
            old=run(ORIGINAL,mode,d,dirs[0]);base=run(EXE,mode,d,dirs[1],'baseline');scaled=run(EXE,mode,d,dirs[2],'sqrt_d');median=run(EXE,mode,d,dirs[3],'median0')
            for a,b in zip(old,base):
                for k in ('best_loss','best_so_far','mean_loss','median_loss','mean_radius','mean_offdiag_kernel'):
                    assert math.isclose(float(a[k]),float(b[k]),rel_tol=1e-12,abs_tol=1e-12),(d,mode,k,a[k],b[k])
            for variant,table in [('baseline',base),('sqrt_d',scaled),('median0',median)]:
                assert len(table)==3 and int(table[-1]['step'])==100
                expected=.3 if variant=='baseline' else (sigma if variant=='sqrt_d' else float(table[0]['sigma']))
                assert expected>0 and all(math.isclose(float(r['sigma']),expected,rel_tol=1e-14) for r in table)
                assert all(math.isfinite(float(r[k])) and float(r[k])>=0 for r in table for k in FORCES)
                assert all(float(r['best_so_far'])<=float(r['best_loss'])+1e-12 for r in table)
            assert math.isclose(float(base[0]['best_loss']),float(scaled[0]['best_loss']),rel_tol=1e-14)
            assert math.isclose(float(base[0]['best_loss']),float(median[0]['best_loss']),rel_tol=1e-14)
            assert .1<float(median[0]['mean_offdiag_kernel'])<.8
            if mode=='control':control_gradient=float(base[0]['mean_gradient_norm'])
            if mode=='svgd':
                assert math.isclose(float(base[0]['mean_svgd_self_score_norm']),control_gradient/(64*.15),rel_tol=1e-12)
                assert math.isclose(float(scaled[0]['mean_svgd_self_score_norm']),control_gradient/(64*.15),rel_tol=1e-12)
                assert math.isclose(float(median[0]['mean_svgd_self_score_norm']),control_gradient/(64*.15),rel_tol=1e-12)
                for r in scaled:
                    assert int(r['active_svgd_current'])==64 and int(r['active_svgd_history'])==0
                    assert float(r['mean_total_drift_norm'])<=sum(float(r[k]) for k in ('mean_svgd_self_score_norm','mean_svgd_other_score_norm','mean_svgd_current_repulsion_norm'))+1e-12
            if mode=='A':assert all(int(r['active_svgd_history'])==64 for r in scaled)
            if mode=='control':assert all(float(r['mean_history_repulsion_norm'])==0 and float(r['mean_svgd_current_repulsion_norm'])==0 for r in scaled)
    # In 2D the two saved coordinates determine full Euclidean distance, so the
    # width can be independently recovered from the initial particle snapshot.
    p=t/'median2d';run(EXE,'svgd',2,p,'median0')
    particles=[r for r in read(p/'svgd_d2_trial0_particles.csv') if r['step']=='0']
    ds=sorted(math.hypot(float(a['x_projection_1'])-float(b['x_projection_1']),float(a['x_projection_2'])-float(b['x_projection_2'])) for i,a in enumerate(particles) for b in particles[i+1:])
    expected=(ds[len(ds)//2-1]+ds[len(ds)//2])/4
    measured=float(read(p/'svgd_d2_trial0.csv')[0]['sigma'])
    assert math.isclose(measured,expected,rel_tol=1e-12),(measured,expected)
print('PASS: RBF derivative; 16 modes x 2 dimensions x 3 widths; unchanged baseline; force metrics; median-width reconstruction')
