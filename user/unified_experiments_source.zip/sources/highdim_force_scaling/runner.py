"""Run paired width experiments; preserve each completed trial and its diagnostics."""
import concurrent.futures,csv,json,os,pathlib,subprocess,uuid
from datetime import datetime
import numpy as np
from PIL import Image,ImageDraw,ImageFont

ROOT=pathlib.Path(__file__).resolve().parent
RUNS=ROOT/'runs'
MODES=['control','cbo','gcbo','svgd','leader','ula','m1','m2','m3','m4','m5','A','m6','B','m61','B1']
VARIANTS=('baseline','sqrt_d','median0'); DIMS=(20,100); STEPS=30000; TRIALS=48; INTERVAL=500; WORKERS=4
FORCES=['mean_gradient_norm','mean_consensus_norm','mean_svgd_self_score_norm','mean_svgd_other_score_norm','mean_svgd_current_repulsion_norm','mean_svgd_history_score_norm','mean_svgd_history_repulsion_norm','mean_history_repulsion_norm','mean_total_drift_norm']
COLORS=['#444444','#db8b00','#7d64aa','#3c6ad7','#cf3150','#398e9e','#d060ad','#3b994e','#777777']
NOW=lambda:datetime.now().astimezone().isoformat(timespec='seconds')
def atomic_json(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(tmp,path)
def trialdir(variant,d,mode,tr):return RUNS/variant/f'd{d}'/mode/f'trial{tr:02d}'
def complete(variant,d,mode,tr):
    p=trialdir(variant,d,mode,tr)
    if not p.exists():return None
    markers=sorted(p.glob(f'*/{mode}_d{d}_trial{tr}.done'))
    return markers[-1].parent if markers else None
def run_one(job):
    variant,d,mode,tr=job
    if complete(*job):return job,'existing',None
    attempt=trialdir(*job)/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    with (attempt/'execution.log').open('w',encoding='utf-8') as log:
        try:
            p=subprocess.run([str(ROOT/'run.exe'),mode,str(d),str(STEPS),str(tr),str(INTERVAL),str(attempt),variant],stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            return job,('complete' if p.returncode==0 and complete(*job) else 'failed'),p.returncode
        except Exception as exc:log.write(repr(exc));return job,'failed',str(exc)
def readcsv(p):
    with p.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def font(size):
    try:return ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
    except OSError:return ImageFont.load_default()
def aggregate():
    records=[];groups={}
    for variant in VARIANTS:
        for d in DIMS:
            for mode in MODES:
                results=[]
                for tr in range(TRIALS):
                    path=complete(variant,d,mode,tr)
                    if path:
                        rr=readcsv(path/f'{mode}_d{d}_trial{tr}.csv')
                        if len(rr)==STEPS//INTERVAL+1:results.append(rr)
                if not results:continue
                group=[]
                for j in range(len(results[0])):
                    batch=[r[j] for r in results]
                    current=np.array([float(r['best_loss']) for r in batch]);ever=np.array([float(r['best_so_far']) for r in batch])
                    widths=np.array([float(r['sigma']) for r in batch])
                    row={'variant':variant,'dimension':d,'mode':mode,'step':int(batch[0]['step']),'trials':len(batch),'sigma':float(np.median(widths)),'q25_sigma':float(np.quantile(widths,.25)),'q75_sigma':float(np.quantile(widths,.75)),'median_current_best':float(np.median(current)),'q25_current_best':float(np.quantile(current,.25)),'q75_current_best':float(np.quantile(current,.75)),'median_best_so_far':float(np.median(ever)),'q25_best_so_far':float(np.quantile(ever,.25)),'q75_best_so_far':float(np.quantile(ever,.75)),'success_trials':sum(int(r['success']) for r in batch),'median_kernel':float(np.median([float(r['mean_offdiag_kernel']) for r in batch]))}
                    for key in FORCES:row['median_'+key]=float(np.median([float(r[key]) for r in batch]))
                    for key in ('active_svgd_current','active_svgd_history','active_history_repulsion'):row[key]=int(batch[0][key])
                    records.append(row);group.append(row)
                groups[(variant,d,mode)]=group
    if not records:return
    tmp=ROOT/'summary.partial.csv.tmp'
    with tmp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    os.replace(tmp,ROOT/'summary.partial.csv')
    for variant in VARIANTS:
        for d in DIMS:
            active=[(m,groups[(variant,d,m)]) for m in MODES if (variant,d,m) in groups]
            if active:make_force_plot(variant,d,active)
            if not (ROOT/f'particles_{variant}_d{d}.gif').exists() and all(complete(variant,d,m,0) for m in MODES):make_gif(variant,d)
    for d in DIMS:
        if any((variant,d,mode) in groups for variant in VARIANTS for mode in MODES):make_loss_plot(d,groups)
def make_loss_plot(d,groups):
    colors=['#3d3d3d','#da2c38','#f38336','#3a5cc9','#008d86','#ab59b2','#858000','#1f8b4c','#5696ac','#974242','#d354a6','#574a86','#ed91a7','#93765d','#599c37','#169ba8']
    img=Image.new('RGB',(2400,810),'white');draw=ImageDraw.Draw(img);large=font(24);regular=font(14);small=font(12)
    draw.text((25,15),f'd={d}: median best-so-far loss by kernel-width condition',font=large,fill='black')
    data_all=[row for variant in VARIANTS for m in MODES for row in groups.get((variant,d,m),[])]
    vals=[max(1e-12,r['median_best_so_far']) for r in data_all];low=int(np.floor(np.log10(min(vals))));high=int(np.ceil(np.log10(max(vals))));high=max(high,low+1)
    for panel,variant in enumerate(VARIANTS):
        x0=75+panel*690;x1=x0+620;y0=95;y1=675;draw.text((x0,y0-30),variant,font=large,fill='black')
        draw.rectangle((x0,y0,x1,y1),outline='black')
        for exponent in range(low,high+1):
            y=y1-(exponent-low)/(high-low)*(y1-y0);draw.line((x0,y,x1,y),fill='#dddddd');draw.text((x0-42,y-7),f'1e{exponent}',font=small,fill='black')
        for mode in MODES:
            group=groups.get((variant,d,mode))
            if not group:continue
            pts=[(x0+(x1-x0)*r['step']/STEPS,y1-(np.log10(max(1e-12,r['median_best_so_far']))-low)/(high-low)*(y1-y0)) for r in group]
            if len(pts)>1:draw.line(pts,fill=colors[MODES.index(mode)],width=2)
        draw.text((x0,y1+10),'0',font=small,fill='black');draw.text((x1-45,y1+10),str(STEPS),font=small,fill='black')
    for i,mode in enumerate(MODES):
        y=98+i*32;draw.line((2150,y+8,2176,y+8),fill=colors[i],width=3);draw.text((2182,y),mode,font=regular,fill='black')
    draw.text((750,755),'Update step; per-mode trial counts and quartiles are in summary.partial.csv',font=regular,fill='black')
    tmp=ROOT/f'loss_compare_d{d}.tmp.png';img.save(tmp);os.replace(tmp,ROOT/f'loss_compare_d{d}.png')
def make_force_plot(variant,d,active):
    # A separate panel per method, log scaling separately per panel; absent/zero terms are omitted.
    img=Image.new('RGB',(1600,1540),'white');draw=ImageDraw.Draw(img);title=font(22);f=font(14);small=font(11)
    draw.text((25,12),f'{variant}, d={d}: median net force magnitude per particle (before step size)',font=title,fill='black')
    short=['own grad','consensus','SVGD self','SVGD other','SVGD repel','history score','history SVGD repel','history repel','total drift']
    for k,label in enumerate(short):
        x=20+(k%5)*310;y=48+(k//5)*22;draw.line((x,y+7,x+25,y+7),fill=COLORS[k],width=3);draw.text((x+30,y),label,font=f,fill='black')
    lookup=dict(active)
    for idx,mode in enumerate(MODES):
        col=idx%4;row=idx//4;x0=col*400+45;x1=x0+320;y0=110+row*350;y1=y0+275
        draw.rectangle((x0,y0,x1,y1),outline='#999999');data=lookup.get(mode)
        draw.text((x0,y0-21),f'{mode}  n={data[0]["trials"] if data else 0}',font=f,fill='black')
        if not data:continue
        values=[r['median_'+key] for r in data for key in FORCES if r['median_'+key]>1e-300]
        if not values:continue
        low=int(np.floor(np.log10(min(values))));high=int(np.ceil(np.log10(max(values))));low=max(low,high-24);high=max(high,low+1)
        for k in range(5):
            y=y0+k*(y1-y0)/4;draw.line((x0,y,x1,y),fill='#eeeeee');val=high-k*(high-low)/4;draw.text((x0-38,y-5),f'{val:.1f}',font=small,fill='#444444')
        for k,key in enumerate(FORCES):
            points=[]
            for r in data:
                val=r['median_'+key]
                if val>0:
                    ly=max(low,np.log10(val));points.append((x0+(x1-x0)*r['step']/STEPS,y1-(ly-low)*(y1-y0)/(high-low)))
            if len(points)>1:draw.line(points,fill=COLORS[k],width=2)
        draw.text((x0,y1+4),'0',font=small,fill='black');draw.text((x1-42,y1+4),str(STEPS),font=small,fill='black')
    draw.text((25,1520),'Y labels: log10 magnitude; averages include particles where a term is inactive (zero).',font=f,fill='black')
    tmp=ROOT/f'forces_{variant}_d{d}.tmp.png';img.save(tmp);os.replace(tmp,ROOT/f'forces_{variant}_d{d}.png')
def make_gif(variant,d):
    entries={};bound=5.12
    for mode in MODES:
        p=complete(variant,d,mode,0);table=readcsv(p/f'{mode}_d{d}_trial0_particles.csv');series={}
        for r in table:
            step=int(r['step']);x=float(r['x_projection_1']);y=float(r['x_projection_2']);series.setdefault(step,[]).append((x,y,float(r['loss'])));bound=max(bound,abs(x),abs(y))
        entries[mode]=series
    bound*=1.03;frames=[];f=font(15);head=font(20)
    for step in range(0,STEPS+1,INTERVAL):
        im=Image.new('RGB',(1120,1040),'white');dr=ImageDraw.Draw(im);dr.text((15,8),f'{variant}, d={d}, trial 0, step {step}; x1/x2; red=current best',font=head,fill='black')
        for idx,mode in enumerate(MODES):
            row,col=divmod(idx,4);left=col*280;top=40+row*250;cx=left+140;cy=top+130;half=95
            dr.rectangle((cx-half,cy-half,cx+half,cy+half),outline='#cccccc');pts=entries[mode][step];winner=min(range(len(pts)),key=lambda i:pts[i][2]);dr.text((left+7,top+4),f'{mode}  best={pts[winner][2]:.3g}',font=f,fill='black')
            for i,(x,y,loss) in enumerate(pts):
                px=cx+half*x/bound;py=cy-half*y/bound;r=4 if i==winner else 2;dr.ellipse((px-r,py-r,px+r,py+r),fill='#df2233' if i==winner else '#3263ad')
        frames.append(im.convert('P',palette=Image.Palette.ADAPTIVE,colors=64))
    tmp=ROOT/f'particles_{variant}_d{d}.tmp.gif';frames[0].save(tmp,save_all=True,append_images=frames[1:],duration=120,loop=0,optimize=False);os.replace(tmp,ROOT/f'particles_{variant}_d{d}.gif')
def main():
    RUNS.mkdir(exist_ok=True)
    # Pair each mode/seed/dimension so that early partial results remain directly comparable.
    jobs=[(v,d,m,tr) for tr in range(TRIALS) for d in DIMS for m in MODES for v in VARIANTS]
    pending=[job for job in jobs if not complete(*job)]
    state={'started':NOW(),'updated':NOW(),'state':'running','workers':WORKERS,'total':len(jobs),'completed':len(jobs)-len(pending),'failed':0,'last':None}
    atomic_json(ROOT/'status.json',state)
    with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
        futures={}
        def refill():
            while len(futures)<WORKERS and pending and not (ROOT/'stop.flag').exists():
                job=pending.pop(0);futures[pool.submit(run_one,job)]=job
        refill()
        while futures:
            done,_=concurrent.futures.wait(futures,return_when=concurrent.futures.FIRST_COMPLETED)
            for fut in done:
                job,what,code=fut.result();del futures[fut]
                state['last']={'variant':job[0],'dimension':job[1],'mode':job[2],'trial':job[3],'result':what,'exit_code':code}
                state['completed']+=what in ('complete','existing');state['failed']+=what=='failed';state['updated']=NOW();atomic_json(ROOT/'status.json',state)
                if state['completed']<=16 or state['completed']%16==0:
                    try:aggregate()
                    except Exception as exc:
                        with (ROOT/'analysis_errors.log').open('a',encoding='utf-8') as f:f.write(f'{NOW()} {exc!r}\n')
            refill()
    try:aggregate()
    except Exception as exc:
        with (ROOT/'analysis_errors.log').open('a',encoding='utf-8') as f:f.write(f'{NOW()} {exc!r}\n')
    state['state']='stopped' if (ROOT/'stop.flag').exists() else ('complete' if state['failed']==0 else 'finished_with_errors');state['updated']=NOW();atomic_json(ROOT/'status.json',state)
    if state['state']=='complete':
        import shutil
        shutil.copy2(ROOT/'summary.partial.csv',ROOT/'summary.csv')
if __name__=='__main__':main()
