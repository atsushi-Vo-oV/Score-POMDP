import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,zipfile
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'work'/'plotting_packages'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
P=Path(__file__).resolve().parent
n,d,T,gap=64,100,30000,500
eta,tau=.01,.15
rng=np.random.default_rng(20261106)
truth=rng.uniform(-np.pi,np.pi,d)
init=np.array([(truth+rng.normal(0,.25,(n,d))+np.pi)%(2*np.pi)-np.pi,rng.uniform(-np.pi,np.pi,(n,d))])
steps=np.arange(0,T+1,gap)
states=np.zeros((2,len(steps),n,d)); losses=np.zeros((2,len(steps),n)); kernelstats=np.zeros((2,len(steps),2)); widths=[]
upper=np.triu_indices(n,1)
for case in range(2):
 q=init[case].copy(); c=np.cos(q);s=np.sin(q); dist=np.maximum(0,d-(c@c.T+s@s.T)); h2=float(np.median(dist[upper])/np.log(2)); widths.append(h2)
 for t in range(T+1):
  delta=q-truth; loss=.02*np.sum(1-np.cos(delta),axis=1); score=-.02*np.sin(delta)/tau
  c=np.cos(q);s=np.sin(q); dist=np.maximum(0,d-(c@c.T+s@s.T)); K=np.exp(-dist/h2)
  if t%gap==0:
   f=t//gap; states[case,f]=q; losses[case,f]=loss; kernelstats[case,f]=[np.median(K[upper]),np.mean(K[upper]<1e-6)]
  if t==T: break
  rep=(s*(K@c)-c*(K@s))/h2
  q=(q+eta*(K@score+rep)/n+np.pi)%(2*np.pi)-np.pi
 print(('near','far')[case], 'done',loss.min(),flush=True)
np.savez_compressed(P/'results.npz',states=states,losses=losses,kernelstats=kernelstats,truth=truth,h2=widths,steps=steps)
grid=2*np.pi*np.arange(256)/256; freqs=np.arange(1,d+1); basis=np.outer(grid,freqs); target=.2*np.sin(basis+truth).sum(axis=1)
fig,ax=plt.subplots(2,2,figsize=(13,8),constrained_layout=True); colors=['#287bb8','#e67c22']; lines=[]
fixed=np.argmin(losses[:,-1],axis=1)
for i in range(2):
 a=ax[i,0]; a.plot(grid,target,color='black',label='Target',lw=1.4); now,=a.plot([],[],color=colors[i],label='Current best'); final,=a.plot([],[],color='gray',ls=':',lw=2,label='Final-best particle'); a.set_title(('Near initialization','Far initialization')[i]); a.set_xlim(0,2*np.pi); a.set_ylim(-8,8); a.grid(alpha=.2); a.legend(fontsize=8); a.set_xlabel('x'); a.set_ylabel('y'); info=a.text(.02,.05,'',transform=a.transAxes,bbox={'facecolor':'white','alpha':.8}); lines.append((now,final,info))
a=ax[0,1]; a.set_yscale('log'); a.set_xlim(0,T); a.set_ylim(max(1e-8,losses.min()/2),losses.min(axis=2).max()*2); a.set_title('Current best half-MSE'); a.grid(alpha=.2); a.set_xlabel('Step'); lp=[a.plot([],[],color=colors[i],label=('Near','Far')[i])[0] for i in range(2)]; a.legend()
a=ax[1,1]; a.set_title('Median kernel value (distinct particles)'); a.set_xlim(0,T); a.set_ylim(0,1); a.grid(alpha=.2); a.set_xlabel('Step'); kp=[a.plot([],[],color=colors[i],label=('Near','Far')[i])[0] for i in range(2)]; a.legend()
frames=[]
for f in range(len(steps)):
 for i in range(2):
  best=np.argmin(losses[i,f]); q=states[i,f,best]; z=states[i,f,fixed[i]]
  lines[i][0].set_data(grid,.2*np.sin(basis+q).sum(axis=1)); lines[i][1].set_data(grid,.2*np.sin(basis+z).sum(axis=1)); lines[i][2].set_text('Current loss: %.5g'%losses[i,f,best]); lp[i].set_data(steps[:f+1],losses[i,:f+1].min(axis=1)); kp[i].set_data(steps[:f+1],kernelstats[i,:f+1,0])
 fig.suptitle('100D torus SVGD | %s / 30,000 steps'%format(steps[f],','),fontweight='bold',fontsize=15); fig.canvas.draw(); frames.append(Image.fromarray(np.asarray(fig.canvas.buffer_rgba()).copy()).convert('P',palette=Image.Palette.ADAPTIVE,colors=128))
frames[0].save(P/'torus_100d.gif',save_all=True,append_images=frames[1:],duration=150,loop=0,optimize=False);fig.savefig(P/'final.png',dpi=120);plt.close(fig)
report={'h_squared':widths,'final_best_loss':losses[:,-1].min(axis=1).tolist(),'initial_best_loss':losses[:,0].min(axis=1).tolist(),'initial_final_median_kernel':kernelstats[:,[0,-1],0].tolist()};(P/'summary.json').write_text(json.dumps(report,indent=2))
with zipfile.ZipFile(P/'bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['experiment.py','README.txt','results.npz','summary.json','final.png','torus_100d.gif']: z.write(P/name,name)
