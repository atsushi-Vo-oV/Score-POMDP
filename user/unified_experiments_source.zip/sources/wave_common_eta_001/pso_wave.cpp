#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;namespace fs=std::filesystem;
constexpr int N=64;const double PI=acos(-1.0);
struct V{double a,w;V operator+(V b)const{return{a+b.a,w+b.w};}V operator-(V b)const{return{a-b.a,w-b.w};}};
double cosine_sum(double z){z=remainder(z,2*PI);if(abs(z)<1e-4){double s=0;for(int j=0;j<64;j++)s+=cos(j*z);return s;}return sin(32*z)*cos(31.5*z)/sin(z/2);}
double loss(V x){double dz=2*PI/63,s2=(64-cosine_sum(2*x.w*dz))/2,cross=(cosine_sum((x.w-3)*dz)-cosine_sum((x.w+3)*dz))/2;return max(0.,(x.a*x.a*s2-2*x.a*cross+31.5)/128);}
double direct(V p){double s=0;for(int j=0;j<64;j++){double x=j*2*PI/63,e=p.a*sin(p.w*x)-sin(3*x);s+=e*e;}return s/128;}
int main(int argc,char**argv){try{
 if(argc==2&&string(argv[1])=="--selftest"){
  for(auto p:vector<V>{{1,3},{-1,-3},{.4,0},{1,3.000001},{.8,1.2},{2.3,-7.8},{1,66}})if(abs(loss(p)-direct(p))>1e-10)throw runtime_error("analytic wave loss differs from direct 64-point regression");
  cout<<"PASS: original wave objective equals direct 64-point half-MSE\n";return 0;
 }
 if(argc!=4)throw runtime_error("usage: pso_wave DIRECTORY TRIALS STEPS");fs::path root=argv[1];int trials=stoi(argv[2]),T=stoi(argv[3]);if(trials<1||T<1||T%500)throw runtime_error("invalid trial/step count");
 if(fs::exists(root/"PSO.states.f64"))throw runtime_error("refusing overwrite");
 ifstream input(root/"initial.csv");ofstream states(root/"PSO.states.f64",ios::binary),path(root/"PSO_path.csv"),summ(root/"PSO_trials.csv");
 path<<setprecision(17)<<"step,particle,a,w,loss\n";summ<<setprecision(17)<<"trial,step,current_best,mean_loss,hit,hit_fraction\n";
 auto start=chrono::steady_clock::now();const double phi=4.1,chi=2/(phi-2+sqrt(phi*phi-4*phi));
 for(int tr=0;tr<trials;tr++){
  array<V,N>x{},velocity{},pbest{};array<double,N>L{},pbloss{};
  for(auto &p:x)input>>p.a>>p.w;if(!input)throw runtime_error("initial data missing");pbest=x;for(int i=0;i<N;i++)pbloss[i]=loss(x[i]);
  mt19937_64 rng(900000+tr);uniform_real_distribution<double>u(0,1);
  for(int step=0;step<=T;step++){
   for(int i=0;i<N;i++){L[i]=loss(x[i]);if(!isfinite(L[i]))throw runtime_error("nonfinite loss");}
   if(step%500==0){double mean=0;int hits=0;for(int i=0;i<N;i++){double data[3]={x[i].a,x[i].w,L[i]};states.write(reinterpret_cast<char*>(data),sizeof(data));mean+=L[i]/N;hits+=(L[i]<.01&&(abs(x[i].w-3)<.15||abs(x[i].w+3)<.15));if(tr==0)path<<step<<','<<i<<','<<x[i].a<<','<<x[i].w<<','<<L[i]<<'\n';}
    summ<<tr<<','<<step<<','<<*min_element(L.begin(),L.end())<<','<<mean<<','<<(hits>0)<<','<<double(hits)/N<<'\n';
   }
   if(step==T)break;
   for(int i=0;i<N;i++)if(L[i]<pbloss[i]){pbloss[i]=L[i];pbest[i]=x[i];}
   V best=pbest[min_element(pbloss.begin(),pbloss.end())-pbloss.begin()];
   for(int i=0;i<N;i++){double r1=u(rng),r2=u(rng),s1=u(rng),s2=u(rng);V p=pbest[i]-x[i],g=best-x[i];velocity[i]={(velocity[i].a+2.05*r1*p.a+2.05*r2*g.a)*chi,(velocity[i].w+2.05*s1*p.w+2.05*s2*g.w)*chi};x[i]=x[i]+V{0.01*velocity[i].a,0.01*velocity[i].w};if(!isfinite(x[i].a)||!isfinite(x[i].w))throw runtime_error("nonfinite particle");}
  }
  states.flush();path.flush();summ.flush();cerr<<"PSO "<<tr+1<<'/'<<trials<<" trials complete\n";
 }
 if(!states||!path||!summ)throw runtime_error("failed to write output");ofstream done(root/"PSO.done.json");done<<"{\"trials\":"<<trials<<",\"steps\":"<<T<<",\"snapshots\":"<<T/500+1<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}\n";return 0;
}catch(const exception&e){cerr<<e.what()<<'\n';return 1;}}
