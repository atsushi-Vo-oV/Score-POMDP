"""Rebuild the original sine-wave example and add PSO using matched initialization."""
from __future__ import annotations
import csv, hashlib, json, os, pathlib, sys, zipfile
import numpy as np

ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parent.parent/'work'
sys.path.insert(0,str(WORK/'plotting_packages'))
os.environ.setdefault('MPLCONFIGDIR',str(WORK/'mplconfig_wave'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from PIL import Image

font=pathlib.Path('C:/Windows/Fonts/meiryo.ttc')
if font.exists():
    matplotlib.font_manager.fontManager.addfont(str(font))
    plt.rcParams['font.family']=FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False})
MODES=['ULA','PSO','SVGD','CBO'];COLORS={'ULA':'#1779b9','PSO':'#e58616','SVGD':'#9851b5','CBO':'#138c79'}
STEPS=np.arange(0,30001,500,dtype=np.int64)
OBS=np.linspace(0,2*np.pi,64);TARGET=np.sin(3*OBS)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_csv(p):
    with p.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def save_json(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def wave_loss(a,w):return .5*np.mean((a[...,None]*np.sin(w[...,None]*OBS)-TARGET)**2,axis=-1)
def verify_and_load():
    manifest=json.loads((ROOT/'source_manifest.json').read_text())
    for name,meta in manifest.items():
        p=ROOT/'initial.csv' if name=='initial.csv' else ROOT/'source_archive'/name
        assert sha(p)==meta['sha256'],name
    initial=np.loadtxt(ROOT/'initial.csv').reshape(48,64,2)
    original=load_csv(ROOT/'source_archive'/'summary_30000.csv')
    results={};checks={}
    for mode in MODES:
        if mode=='PSO':
            done=json.loads((ROOT/'PSO.done.json').read_text());assert done['trials']==48 and done['steps']==30000 and done['snapshots']==61
            psofile=ROOT/'PSO.states.f64'
            if psofile.exists():states=np.fromfile(psofile,dtype='<f8').reshape(48,61,64,3)
            else:
                with np.load(ROOT/'PSO_data.npz',allow_pickle=False) as z:states=z['states']
            pathrows=load_csv(ROOT/'PSO_path.csv')
        else:
            with np.load(ROOT/'source_archive'/'snapshots'/f'{mode.lower()}.npz',allow_pickle=False) as z:
                assert np.array_equal(z['steps'],STEPS);states=z['states'][...,:3]
            pathrows=load_csv(ROOT/'source_archive'/f'{mode.lower()}_path.csv')
        assert states.shape==(48,61,64,3) and np.isfinite(states).all()
        init_error=float(np.max(np.abs(states[:,0,:,:2]-initial)))
        assert init_error<2e-7,(mode,init_error)
        maximum=0
        for trial in states:
            difference=np.abs(wave_loss(trial[...,0].astype(float),trial[...,1].astype(float))-trial[...,2])
            maximum=max(maximum,float(difference.max()))
        assert maximum<(2e-6 if mode!='PSO' else 1e-9),(mode,maximum)
        assert len(pathrows)==61*64
        path=np.array([[float(r[k]) for k in ('a','w','loss')] for r in pathrows]).reshape(61,64,3)
        assert np.allclose(path,states[0],atol=5e-7,rtol=1e-6)
        path_error=float(np.max(np.abs(wave_loss(path[...,0],path[...,1])-path[...,2])))
        assert path_error<1e-9,(mode,path_error)
        loss=states[...,2].astype(float);a=states[...,0].astype(float);w=states[...,1].astype(float)
        best=loss.min(axis=2);sampled_best=np.minimum.accumulate(best,axis=1)
        hit=(loss<.01)&((np.abs(w-3)<.15)|(np.abs(w+3)<.15))
        if mode=='PSO':
            rows=[{'mode':mode,'step':int(step),'trial_hits_either_sign':int(hit[:,j].any(axis=1).sum()),'particle_fraction_either_sign':float(hit[:,j].mean()),'trial_hits_positive':int(((loss[:,j]<.01)&(np.abs(w[:,j]-3)<.15)).any(axis=1).sum()),'mean_loss':float(loss[:,j].mean()),'median_trial_best_loss':float(np.median(best[:,j]))} for j,step in enumerate(STEPS)]
        else:
            rows=[r for r in original if r['mode']==mode.lower()]
            assert [int(r['step']) for r in rows]==STEPS.tolist()
            # Original aggregates were computed before float32 snapshot rounding.
            assert np.max(np.abs(np.array([float(r['mean_loss']) for r in rows])-loss.mean(axis=(0,2))))<1e-7
            assert all(int(r['trial_hits_either_sign'])==int(hit[:,j].any(axis=1).sum()) for j,r in enumerate(rows))
        winner=int(np.argmin(path[-1,:,2]))
        np.savez_compressed(ROOT/f'{mode}_data.npz',states=states,steps=STEPS,fields=np.array(['a','w','loss']),trial0_path_float64=path,initial_float64=initial)
        with np.load(ROOT/f'{mode}_data.npz',allow_pickle=False) as z:assert np.array_equal(z['states'],states)
        results[mode]={'states':states,'path':path,'best':best,'sampled_best':sampled_best,'hit':hit,'aggregate':rows,'winner':winner}
        checks[mode]={'source':'new PSO simulation' if mode=='PSO' else 'original archived run, unchanged','shape':list(states.shape),'snapshot_dtype':str(states.dtype),'initial_max_abs_error':init_error,'max_loss_recomputed_from_snapshots_error':maximum,'max_trial0_float64_path_loss_error':path_error,'fixed_final_best_particle':winner,'data_sha256':sha(ROOT/f'{mode}_data.npz')}
        print(mode,'verified:',checks[mode],flush=True)
    save_json(ROOT/'verification.json',{'all_passed':True,'steps':30000,'trials':48,'particles':64,'record_interval':500,'methods':checks,'notes':'Original aggregates retained at float64 precision. Original snapshots are float32; PSO snapshots and all trial-0 paths are float64.'})
    return results

def aggregate(results):
    rows=[];final=[]
    for mode in MODES:
        data=results[mode]
        for j,step in enumerate(STEPS):
            old=data['aggregate'][j]
            row={'mode':mode,'step':int(step),'trials':48,'current_hit_trials':int(old['trial_hits_either_sign']),'current_hit_particle_fraction':float(old['particle_fraction_either_sign']),'mean_loss':float(old['mean_loss']),'median_current_best':float(old['median_trial_best_loss']),'q25_current_best':float(np.quantile(data['best'][:,j],.25)),'q75_current_best':float(np.quantile(data['best'][:,j],.75)),'median_recorded_best_so_far':float(np.median(data['sampled_best'][:,j])),'recorded_ever_hit_trials':int(data['hit'][:,:j+1].any(axis=(1,2)).sum())}
            rows.append(row)
        final.append(rows[-1])
    for name,values in [('aggregate.csv',rows),('final_summary.csv',final)]:
        with (ROOT/name).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)
    save_json(ROOT/'final_summary.json',final)
    return final

def plot_curves(results):
    fig,axes=plt.subplots(2,2,figsize=(13.7,9),layout='constrained')
    for mode in MODES:
        r=results[mode];rows=r['aggregate'];best=r['best'];c=COLORS[mode]
        med=np.array([float(x['median_trial_best_loss']) for x in rows]);lo,hi=np.quantile(best,[.25,.75],axis=0)
        axes[0,0].plot(STEPS,med,color=c,lw=2,label=mode);axes[0,0].fill_between(STEPS,lo,hi,color=c,alpha=.12,lw=0)
        axes[0,1].plot(STEPS,np.median(r['sampled_best'],axis=0),color=c,lw=2)
        axes[1,0].plot(STEPS,[float(x['mean_loss']) for x in rows],color=c,lw=2)
        axes[1,1].plot(STEPS,[int(x['trial_hits_either_sign']) for x in rows],color=c,lw=2)
    titles=['Current best loss (median; band: 25th–75th percentile)','Best loss over recorded snapshots (median)','Mean loss across all particles and trials','Trials meeting the criterion at each snapshot']
    for ax,title in zip(axes.flat,titles):
        ax.set_title(title);ax.set_xlim(0,30000);ax.set_xlabel('Update step');ax.grid(alpha=.2)
    for ax in axes[0]:ax.set_yscale('symlog',linthresh=1e-5);ax.set_ylim(bottom=0);ax.axhline(.01,color='#555',ls='--',lw=.8)
    axes[1,0].set_ylim(bottom=0);axes[1,1].set_ylim(-1,49);axes[1,1].set_yticks([0,12,24,36,48])
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=4,frameon=False)
    fig.suptitle('Wave regression: common eta=0.01 | 64 particles, 48 trials, 30,000 steps',fontsize=14)
    fig.savefig(ROOT/'wave_loss_comparison.png',dpi=160);fig.savefig(ROOT/'wave_loss_comparison.pdf');plt.close(fig)

def animate_wave(results):
    w=np.linspace(-5.3,9,260);a=np.linspace(-5.7,4.5,190);W,A=np.meshgrid(w,a)
    L=wave_loss(A,W);grid=np.linspace(0,2*np.pi,400)
    maxamp=1.6
    for r in results.values():
        path=r['path'];ids=path[:,:,2].argmin(axis=1)
        maxamp=max(maxamp,float(np.abs(path[:,r['winner'],0]).max()),float(np.abs(path[np.arange(61),ids,0]).max()))
    maxamp*=1.08
    fig=plt.figure(figsize=(18,10),dpi=100,layout='constrained');gs=fig.add_gridspec(2,2);artists={}
    title=fig.suptitle('',fontsize=15)
    for i,mode in enumerate(MODES):
        sub=gs[i//2,i%2].subgridspec(1,2,wspace=.12);ax=fig.add_subplot(sub[0,0]);wx=fig.add_subplot(sub[0,1]);c=COLORS[mode];r=results[mode]
        bg=ax.contourf(W,A,L,levels=[0,.01,.03,.08,.15,.22,.24,.26,.32,.5,1,2],cmap='Blues_r',extend='max')
        ax.scatter([3,-3],[1,-1],marker='*',s=100,c='#ffdb4d',edgecolors='black',lw=.6,zorder=4)
        points=ax.scatter([],[],s=23,c=c,edgecolors='white',lw=.4,zorder=5)
        selected=ax.scatter([],[],s=80,facecolors='none',edgecolors='#db2c39',lw=1.8,zorder=7)
        trail,=ax.plot([],[],color='#db2c39',lw=1,alpha=.8,zorder=6)
        now=ax.scatter([],[],s=45,marker='x',c='#222222',linewidths=1.2,zorder=7)
        text=ax.text(.02,.98,'',transform=ax.transAxes,va='top',fontsize=9,bbox={'facecolor':'white','alpha':.9,'edgecolor':'none'},zorder=8)
        ax.set(xlim=(-5.3,9),ylim=(-5.7,4.5),xlabel='Frequency w',ylabel='Amplitude a',title=mode);ax.title.set_color(c);ax.title.set_fontweight('bold')
        wx.plot(grid,np.sin(3*grid),color='#111827',lw=1.5,label='Target sin(3x)',zorder=2)
        current,=wx.plot([],[],color='#777777',lw=1,ls='--',alpha=.8,label='Current best',zorder=1)
        fixed,=wx.plot([],[],color=c,lw=1.8,label=f'Final best #{r["winner"]} (fixed)',zorder=3)
        wx.set(xlim=(0,2*np.pi),ylim=(-maxamp,maxamp),xlabel='Input x',ylabel='Waveform');wx.grid(alpha=.18);wx.legend(fontsize=8,loc='upper right')
        artists[mode]=(points,selected,trail,now,text,current,fixed)
    fig.supxlabel('Same trial 0. Red circle: final-best particle tracked from the start; black x: current best. Snapshots every 500 steps.',fontsize=10)
    def update(j):
        title.set_text(f'Common eta=0.01: ULA / PSO / SVGD / CBO | Step {int(STEPS[j]):,} / 30,000')
        for mode in MODES:
            r=results[mode];path=r['path'];p=path[j];winner=r['winner'];best=int(p[:,2].argmin());pts,sel,tr,now,txt,current,fixed=artists[mode]
            pts.set_offsets(p[:,[1,0]]);sel.set_offsets(p[winner:winner+1,[1,0]]);now.set_offsets(p[best:best+1,[1,0]])
            tr.set_data(path[:j+1,winner,1],path[:j+1,winner,0]);fixed.set_data(grid,p[winner,0]*np.sin(p[winner,1]*grid));current.set_data(grid,p[best,0]*np.sin(p[best,1]*grid))
            outside=int(((p[:,1]<-5.3)|(p[:,1]>9)|(p[:,0]<-5.7)|(p[:,0]>4.5)).sum())
            txt.set_text(f'Current best L={p[best,2]:.4g}\nTracked L={p[winner,2]:.4g}\nOutside view: {outside}')
    update(0);fig.canvas.draw();fig.set_layout_engine('none');frames=[]
    for j in range(61):
        update(j);fig.canvas.draw();rgb=Image.fromarray(np.asarray(fig.canvas.buffer_rgba())[...,:3].copy())
        frames.append(rgb.quantize(colors=128,method=Image.Quantize.FASTOCTREE))
        if j==0:rgb.save(ROOT/'wave_initial.png')
        if j==60:fig.savefig(ROOT/'wave_final.png',dpi=150)
    frames[0].save(ROOT/'wave_ULA_PSO_SVGD_CBO_30000.gif',save_all=True,append_images=frames[1:],duration=[1000]+[160]*59+[2000],loop=0,optimize=False)
    plt.close(fig)
    with Image.open(ROOT/'wave_ULA_PSO_SVGD_CBO_30000.gif') as im:
        assert im.n_frames==61
        for j in range(im.n_frames):im.seek(j);im.load()
    save_json(ROOT/'tracked_particles.json',{m:int(results[m]['winner']) for m in MODES})
    print('Verified GIF: 61 frames, final step 30000',flush=True)

def write_readme(final):
    readme='''元の「波の例」+ PSO：共通位置更新係数 eta=0.01（30,000更新）

課題
  真値 y=sin(3x)、近似 y_hat=a sin(wx)。探索空間は2次元の(a,w)。
  xは0から2*piの64点。損失 L(a,w)=1/(2*64) sum_j(a sin(w*x_j)-sin(3*x_j))^2。
  訓練と評価は同じ64点であり、汎化性能を比較するものではない。
  各方式64粒子、48試行、30,000更新、500更新ごと61時点を記録。

データの継承
  ULA・SVGD・CBOは、復元ZIPに保存されていた30,000更新の実データをそのまま使用。
  今回これら3方式を乱数から再実行した結果ではない。前回結果を正確に再構成している。
  PSOだけを新規計算。同じinitial.csvの各試行64粒子から開始。
  initial.csvの振幅は約0.411–1.216、周波数は約0.701–2.100。
  既存3方式のスナップショットはfloat32。動画用の試行0経路は元精度float64。
  PSOの新規スナップショット・経路はfloat64。
  元3方式の集計値は元のfloat64集計CSVを継承し、丸めた位置から置き換えていない。
  source_manifest.jsonに元ファイルとコピーのSHA-256を記録。

元の更新式（eta=0.01）
  ULA: x_i <- x_i - eta grad L(x_i) + sqrt(2*0.005*eta) Z_i。
  SVGD: x_i <- x_i + eta/N sum_j[-k(x_j,x_i) grad L(x_j)/0.15
                                       + k(x_j,x_i)(x_i-x_j)/0.18]。
    k(x_j,x_i)=exp(-||x_i-x_j||^2/0.36)。固定カーネル幅0.3。
  CBO: c=sum_i exp(-L(x_i)/0.15)x_i / sum_i exp(-L(x_i)/0.15)。
       x_i <- x_i + eta*0.02*(c-x_i) + 0.1*sqrt(eta)*||x_i-c|| Z_i。
  元実装の正確なコードはsource_archive/run.cpp。

今回追加したPSO
  v_i <- chi[v_i + 2.05*r1*(pbest_i-x_i) + 2.05*r2*(gbest-x_i)]、x_i <- x_i+0.01*v_i。
  chi=2/(4.1-2+sqrt(4.1^2-4*4.1))=0.729843788...。
  r1,r2は成分ごと独立な一様乱数。個人・全体の過去最良、同期gbest、初速度0。
  速度制限・境界クリップは使用しない。乱数はmt19937_64(900000+試行番号)。
  位置更新係数0.01はULA・SVGD・CBOと揃えたもの。PSOの元の慣性・加速係数を維持。

図と動画
  wave_ULA_PSO_SVGD_CBO_30000.gif: 各方式の左側が(w,a)の位置、右側が波形。
    図中の文字は英語。全方式で事前固定した試行0を使用。
    赤丸は30,000更新後に最良だった粒子を事後的に選び、同じ粒子を最初から追跡。
    黒×と灰破線は各時点の最良粒子（時刻によって粒子番号が変わる）。
    黒実線は真値、色付き実線は固定追跡粒子の近似波形。星は基準解(1,3),(-1,-3)。
    画面の外に出た粒子数も表示。61フレームを全てデコードして確認している。
  wave_loss_comparison.png/.pdf: 48試行の損失と到達試行数。
  wave_final.png: 最終時点の粒子・波形。
  aggregate.csv: 500更新ごとの比較集計。final_summary.csv/.json:最終時点。
  MODE_data.npz: states=[48試行,61時点,64粒子,3変数(a,w,loss)]、
    steps、fields、試行0のfloat64経路、共通初期値を保存。allow_pickle=Falseで読める。
  source_archive/: 元の3方式のスナップショット・経路・集計・コード・説明。
  pso_wave.cpp/.exe: PSOの計算コード/Windows実行ファイル。
  reproduce_wave.py: 検証・集計・描画・パッケージ化の処理。依存はnumpy,matplotlib,Pillow。

評価と限界
  到達は元と同じくL<0.01、かつ|w-3|<0.15または|w+3|<0.15。
  current_hit_trialsはその時点で到達粒子を含む試行数。累積数とは区別する。
  recorded_ever_hit_trialsと過去最良は、保存された500更新刻みの61時点だけを対象。
  その間の未保存ステップでの到達や最良値は、元3方式では復元できない。
  25–75%帯は試行間四分位であり、信頼区間ではない。
  波形損失のexp(-L/T)は無制限の(a,w)平面で正規化不能なので、ULA・SVGDを
  正しい確率分布からのサンプリングとして検証した例ではない。形式的更新の比較。
  ULAとSVGDは元から異なる拡散/温度設定を引き継ぐ。
  4方式の位置更新に明示的なeta=0.01を使うが、PSOは速度に掛け、他はドリフトに掛ける。
  同じ数値でも更新量・物理時間・演算量・各手法の適切な学習率が同じとは限らない。
  ノイズ、温度、PSOの加速・慣性、SVGDカーネルなどは手法固有の値で統一していない。
  単一課題・係数1設定の比較であり、一般的な優劣を示すものではない。
  64点での波形には周波数エイリアスによる別の同値解もありうる。上の到達基準は±3を評価する。

PSO参考: Clerc & Kennedy (2002), https://doi.org/10.1109/4235.985692
'''
    (ROOT/'README_ja.txt').write_text(readme,encoding='utf-8')

def package():
    archive=ROOT/'wave_comparison_30000_bundle.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and p!=archive and p.suffix not in ('.f64','.obj','.tmp','.pyc') and '__pycache__' not in p.parts:z.write(p,p.relative_to(ROOT))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    print('ZIP CRC verified',archive.stat().st_size,flush=True)

def main():
    results=verify_and_load();final=aggregate(results);plot_curves(results);animate_wave(results);write_readme(final)
    save_json(ROOT/'status.json',{'state':'complete','verified':True,'steps':30000,'trials':48,'particles':64,'archived_methods':['ULA','SVGD','CBO'],'new_method':'PSO'})
    package();print(json.dumps(final,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
